/*
 * Equipe de Medidas
 * 
 */

package br.edu.ifsp.medidacerta.medida.models.rcq;

import br.edu.ifsp.medidacerta.medida.models.Medida;
import br.edu.ifsp.medidacerta.shared.models.Pessoa;

/**
 * Classe para c�lculo de RCQ (rela��o cintura/quadril) 
 * @author Tiago
 */
public class RCQ implements Medida{

    private Double valor;
    private Pessoa pessoa;
    /**
     * Cria um novo c�lculo de RCQ (rela��o cintura/quadril) de uma pessoa
     *
     * @param circunferenciaCintura 
     * @param circunferenciaQuadril 
     */
    public RCQ(double circunferenciaCintura, double circunferenciaQuadril) {
        this.pessoa = new Pessoa();
        this.pessoa.setCircunferenciaQuadril(circunferenciaQuadril);
        this.pessoa.setCircunferenciaCintura(circunferenciaCintura);
        recalcular();
    }
    
    /**
     * Cria um novo c�lculo de RCQ (rela��o cintura/quadril) com valores de 
     * peso, altura, sexo e idade de uma pessoa     
     * @param pessoa
     * @throws Exception
     */
    public RCQ(Pessoa pessoa) throws Exception{
        this.pessoa = pessoa;  
        if(pessoa.getCircunferenciaCintura()== null || pessoa.getCircunferenciaQuadril() == null){
            throw new UnsupportedOperationException("C�lculo de RCQ n�o dispon�vel quando n�o tem o valor da circunfer�ncia da cintura.");
        } 
        recalcular();
    }
    private void recalcular(){
        valor = pessoa.getCircunferenciaCintura()/ pessoa.getCircunferenciaQuadril();
    }

    @Override
    public double getValor() {
        recalcular();
        return valor;
    }

    @Override
    public String toString() {
        return "" + valor ;
    }
    
    
}
