/*
 * Equipe de Medidas
 * 
 */
package br.edu.ifsp.medidacerta.medida.models.imc;

import java.util.Date;

import br.edu.ifsp.medidacerta.medida.models.Medida;
import br.edu.ifsp.medidacerta.shared.models.Pessoa;
import br.edu.ifsp.medidacerta.shared.models.Sexo;

/**
 * Classe para c�lculo de IMC (�ndice de massa corp�rea)
 *
 * @author Tiago
 * @author Kelvin
 */
public class IMC implements Medida {    
    private Pessoa pessoa;
    private double valor;
    private Classificacao classificacao;

    /**
     * Cria um novo c�lculo de IMC (�ndice de massa corp�rea) de uma pessoa
     *
     * @param pessoa
     */
    public IMC(Pessoa pessoa) {
        this.pessoa = pessoa;
        recalcular();
    }

  
    /**
     * Cria um novo c�lculo de IMC (�ndice de massa corp�rea) com valores de 
     * peso, altura, sexo e idade de uma pessoa     
     * @param peso O peso (em Kg) da pessoa
     * @param altura A altura (em m) da pessoa
     * @param sexo O sexo da pessoa
     * @param idade A idade (em anos) da pessoa
     */
    public IMC(double peso, double altura, Sexo sexo, int idade) {
        this.pessoa = new Pessoa();
        this.pessoa.setAltura(altura);
        this.pessoa.setPeso(peso);
        this.pessoa.setSexo(sexo);
        
        // "Artif�cio t�cnico" para setar a idade da pessoa:
        Date dataNascimento = new Date();
        dataNascimento.setYear(dataNascimento.getYear() - idade);
        this.pessoa.setDataNascimento(dataNascimento);


        recalcular();
    }

    
    /**
     * Cria um novo c�lculo de IMC (�ndice de massa corp�rea) com valores de 
     * peso, altura, sexo e a data de nascimento de uma pessoa     
     * @param peso O peso (em Kg) da pessoa
     * @param altura A altura (em m) da pessoa
     * @param sexo O sexo da pessoa
     * @param dataNascimento A data de nascimento da pessoa
     */
    public IMC(double peso, double altura, Sexo sexo, Date dataNascimento) {
        this.pessoa = new Pessoa();
        this.pessoa.setAltura(altura);
        this.pessoa.setPeso(peso);
        this.pessoa.setSexo(sexo);
        this.pessoa.setDataNascimento(dataNascimento);
        recalcular();
    }

    /**
     * Retorna a classifica��o do IMC
     *
     * @return Classificacao
     */
    public Classificacao getClassificacao() {
        return classificacao;
    }

    /**
     * Retorna o valor do IMC
     *
     * @return valor
     */
    @Override
    public double getValor() {
        return valor;
    }

    private void recalcular() {
        valor = 1.3 * pessoa.getPeso() / Math.pow(pessoa.getAltura(), 2.5);
        classificacao = Classificacao.getClassificacao(this);
    }

    /**
     * Retorna uma dica referente ao IMC
     * @return Uma String contendo dicas com base o IMC
     */
    public String getDica() {

        String dica = "N�o h� dicas dispon�veis. [TO-DO: buscar as dicas de Enciclopedia]";


        return dica;
    }

    @Override
    public String toString() {

        return String.valueOf(valor);
    }
    
    
    /**
     * Classifica��o do IMC
     * @author Tiago
     */
    public static enum Classificacao {

        /**
         * Magreza severa
         */
        MAGREZA_SEVERA(1),
        /**
         * Magreza moderada
         */
        MAGREZA_MODERADA(2),
        /**
         * Magreza leve ou subnutri��o
         */
        MAGREZA_LEVE(3),
        /**
         * Saud�vel / eutrofia
         */
        SAUDAVEL(4),
        /**
         * Sobrepeso
         */
        SOBREPESO(5),
        /**
         * Obesidade
         */
        OBESIDADE(6),
        /**
         * Obesidade severa
         */
        OBESIDADE_SEVERA(7),
        /**
         * Obesidade morbida
         */
        OBESIDADE_MORBIDA(8),
        /**
         * IMC sem classifica��o
         */
        SEM_CLASSIFICACAO(0);
        
        
        private int id;
        private double minIdeal = 0;
        private double maxIdeal = 0;

        /**
         * Retorna uma classifica��o baseando-se em um id pr�-definido
         *
         * @param id
         * @return Classificacao
         */
        public static Classificacao valueOf(int id) {
            for (Classificacao c : values()) {
                if (c.id == id) {
                    return c;
                }
            }
            return SEM_CLASSIFICACAO;
        }

        private Classificacao(int id) {
            this.id = id;
        }

        private static Classificacao getClassificacao(IMC imc) {
            Classificacao classificacao = Classificacao.SEM_CLASSIFICACAO;
            Integer idade = imc.pessoa.getIdade();
            Sexo sexo = imc.pessoa.getSexo();
            if (idade != null) {
                if (idade >= 18 && idade < 65) {
                    classificacao = TabelaAdulto.getClassificacao(imc.valor);
                    classificacao.maxIdeal = TabelaAdulto.SAUDAVEL_ADULTO.getValorMaximo();
                    classificacao.minIdeal = TabelaAdulto.MAGREZA_LEVE_ADULTO.getValorMaximo();
                } else if (idade > 65) {
                    classificacao = TabelaIdoso.getClassificacao(sexo, imc.valor);
                    if (sexo == Sexo.MASCULINO) {
                        classificacao.maxIdeal = TabelaIdoso.SAUDAVEL_MASCULINO.getValorMaximo();
                        classificacao.minIdeal = TabelaIdoso.MAGREZA_LEVE_MASCULINO.getValorMaximo();
                    } else if (sexo == Sexo.FEMININO) {
                        classificacao.maxIdeal = TabelaIdoso.SAUDAVEL_FEMININO.getValorMaximo();
                        classificacao.minIdeal = TabelaIdoso.MAGREZA_LEVE_FEMININO.getValorMaximo();
                    }
                } else if (idade < 18) {
                    TabelaInfantil itemClassInfantil = TabelaInfantil.parseValues(idade, sexo);
                    if (itemClassInfantil != null){
	                    classificacao = TabelaInfantil.getClassificacao(itemClassInfantil, imc.valor);
	                    classificacao.minIdeal = itemClassInfantil.getMinIdeal();
	                    classificacao.maxIdeal = itemClassInfantil.getMaxIdeal();
                    }

                }
            }
            return classificacao;
        }

        /**
         * Retorna o identificador
         * @return id O identificador do item da classifica��o
         */
        public int getId() {
            return id;
        }

        /**
         * Retorna o m�nimo ideal do IMC da pessoa
         * @return O valor m�nimo ideal para o IMC da pessoa
         */
        public double getMinIdeal() {
            return minIdeal;
        }

        /**
         * Retorna o m�ximo ideal do IMC da pessoa
         * @return O valor m�ximo ideal para o IMC da pessoa
         */
        public double getMaxIdeal() {
            return maxIdeal;
        }
    }
}
