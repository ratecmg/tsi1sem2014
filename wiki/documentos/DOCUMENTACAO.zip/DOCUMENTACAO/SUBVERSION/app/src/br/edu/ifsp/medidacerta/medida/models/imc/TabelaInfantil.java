/*
 * Equipe de Medidas
 * 
 */
package br.edu.ifsp.medidacerta.medida.models.imc;

import br.edu.ifsp.medidacerta.shared.models.Sexo;

enum TabelaInfantil {
    // Feminino
    CLASS_2F(Sexo.FEMININO, 2, 15.7d, 17.1d, 18.7d),
    CLASS_3F(Sexo.FEMININO, 3, 15.4d, 16.8d, 18.4d),
    CLASS_4F(Sexo.FEMININO, 4, 15.0d, 16.8d, 18.5d),
    CLASS_5F(Sexo.FEMININO, 5, 14.3d, 16.9d, 18.8d),
    CLASS_6F(Sexo.FEMININO, 6, 13.7d, 17.0d, 17.5d),
    CLASS_7F(Sexo.FEMININO, 7, 14.1d, 17.5d, 18.2d),
    CLASS_8F(Sexo.FEMININO, 8, 14.1d, 18.7d, 19.8d),
    CLASS_9F(Sexo.FEMININO, 9, 14.6d, 19.8d, 21.2d),
    CLASS_10F(Sexo.FEMININO, 10, 14.3d, 18.7d, 19.8d),
    CLASS_11F(Sexo.FEMININO, 11, 15.3d, 21.8d, 23.4d),
    CLASS_12F(Sexo.FEMININO, 12, 15.6d, 23.1d, 24.6d),
    CLASS_13F(Sexo.FEMININO, 13, 16.3d, 23.8d, 25.2d),
    CLASS_14F(Sexo.FEMININO, 14, 17.1d, 24.7d, 26.2d),
    CLASS_15F(Sexo.FEMININO, 15, 17.5d, 24.1d, 25.6d),
    CLASS_16F(Sexo.FEMININO, 16, 18.3d, 25.7d, 26.8d),
    CLASS_17F(Sexo.FEMININO, 17, 17.9d, 25.7d, 26.2d),
    // Masculino
    CLASS_2M(Sexo.MASCULINO, 2, 16.0d, 17.3d, 18.9d),
    CLASS_3M(Sexo.MASCULINO, 3, 15.6d, 16.9d, 18.4d),
    CLASS_4M(Sexo.MASCULINO, 4, 15.3d, 16.7d, 18.4d),
    CLASS_5M(Sexo.MASCULINO, 5, 15.2d, 16.6d, 18.3d),
    CLASS_6M(Sexo.MASCULINO, 6, 14.1d, 17.2d, 18.0d),
    CLASS_7M(Sexo.MASCULINO, 7, 14.4d, 17.5d, 18.2d),
    CLASS_8M(Sexo.MASCULINO, 8, 14.3d, 18.7d, 19.8d),
    CLASS_9M(Sexo.MASCULINO, 9, 14.6d, 19.8d, 21.2d),
    CLASS_10M(Sexo.MASCULINO, 10, 15.0d, 19.2d, 19.8d),
    CLASS_11M(Sexo.MASCULINO, 11, 15.1d, 21.5d, 22.5d),
    CLASS_12M(Sexo.MASCULINO, 12, 15.7d, 21.7d, 23.7d),
    CLASS_13M(Sexo.MASCULINO, 13, 16.4d, 22.2d, 24.0d),
    CLASS_14M(Sexo.MASCULINO, 14, 17.0d, 23.1d, 24.2d),
    CLASS_15M(Sexo.MASCULINO, 15, 17.5d, 23.4d, 24.1d),
    CLASS_16M(Sexo.MASCULINO, 16, 18.5d, 24.8d, 25.9d),
    CLASS_17M(Sexo.MASCULINO, 17, 18.4d, 24.9d, 26.1d);
    
    private int idade;
    private double minimoSaudavel;
    private double maximoSaudavel;
    private double maximoSobrepeso;
    private Sexo sexo;

    private TabelaInfantil(
    		Sexo sexo, 
    		int idade, 
    		double minimoSaudavel, 
    		double maximoSaudavel, 
    		double maximoSobrepeso) {
        
    	this.idade = idade;
        this.minimoSaudavel = minimoSaudavel;
        this.maximoSaudavel = maximoSaudavel;
        this.maximoSobrepeso = maximoSobrepeso;
        this.sexo = sexo;
        
    }

    static TabelaInfantil parseValues(int idade, Sexo sexo) {
        TabelaInfantil result = null;
        for (TabelaInfantil item : values()) {
            if (idade == item.idade && sexo == item.sexo) {
                return item;
            }
        }
        return result;
    }

    static IMC.Classificacao getClassificacao(TabelaInfantil itemTabela, double valorIMC) {
    	if (itemTabela != null){
	        if (valorIMC < itemTabela.minimoSaudavel) {
	            return IMC.Classificacao.MAGREZA_LEVE;
	        } else if (valorIMC > itemTabela.minimoSaudavel && valorIMC <= itemTabela.maximoSaudavel) {
	            return IMC.Classificacao.SAUDAVEL;
	        } else if (valorIMC > itemTabela.maximoSaudavel && valorIMC <= itemTabela.maximoSobrepeso) {
	            return IMC.Classificacao.SOBREPESO;
	        } else if (valorIMC > itemTabela.maximoSobrepeso) {
	            return IMC.Classificacao.OBESIDADE;
	        }
        }
        return IMC.Classificacao.SEM_CLASSIFICACAO;
    }

    double getMinIdeal() {
        return minimoSaudavel;
    }

    double getMaxIdeal() {
        return maximoSaudavel;
    }
}
