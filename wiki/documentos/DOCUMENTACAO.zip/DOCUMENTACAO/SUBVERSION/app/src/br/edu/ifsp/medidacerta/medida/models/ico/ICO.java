/*
 * Equipe de Medidas
 * 
 */
package br.edu.ifsp.medidacerta.medida.models.ico;

import br.edu.ifsp.medidacerta.medida.models.Medida;
import br.edu.ifsp.medidacerta.shared.models.Pessoa;



/**
 * Classe para c�lculo do �ndice de conicidade
 * @author Tiago
 */
public class ICO implements Medida {

    private double valor;
    private Pessoa pessoa;

    /**
     * Calcula o �ndice de conicidade, informando o peso, altura e circunfer�ncia da
     * cintura de uma pessoa.
     * @param altura A altura (em m) da pessoa
     * @param peso O peso (em Kg) da pessoa
     * @param circunferenciaCintura A circunfer�ncia da cintura da pessoa
     */
    public ICO(double altura, double peso, double circunferenciaCintura) {
        this.pessoa = new Pessoa();
        this.pessoa.setAltura(altura);
        this.pessoa.setPeso(peso);
        this.pessoa.setCircunferenciaCintura(circunferenciaCintura);        
        recalcular();
    }

    /**
     * Calcula o �ndice de conicidade, informando a pessoa que deseja obter o c�lculo 
     * @param pessoa Pessoa a se obter o ICO
     * @throws Exception Ir� gerar uma exce��o caso n�o haja o valor da circunfer�ncia 
     * da pessoa
     */
    public ICO(Pessoa pessoa) throws Exception {
        this.pessoa = pessoa;
        if (pessoa.getCircunferenciaCintura() == null) {
            throw new UnsupportedOperationException("C�lculo de ICO n�o dispon�vel "
                    + "quando n�o h� o valor da circunfer�ncia da cintura.");
        }
    }

    private void recalcular() {
        valor = pessoa.getCircunferenciaCintura() / (0.109 * (Math.sqrt(pessoa.getPeso()) / pessoa.getAltura()));
    }

    /**
     * M�todo para obter o valor do �ndice
     * @return O valor do �ndice de conicidade
     */
    @Override
    public double getValor() {
        recalcular();
        return valor;
    }

    @Override
    public String toString() {
        recalcular();
        return String.valueOf(valor);

    }
}
