package br.edu.ifsp.medidacerta.shared.models;

import java.util.Calendar;
import java.util.Date;

/**
 * Classe que representa uma pessoa
 *
 * @author Tiago Donizetti Gomes
 */
public class Pessoa {

	private String nome;
    private double peso;
    private double altura;
    private Double circunferenciaCintura = null;
    private Double circunferenciaQuadril = null;
    private Sexo sexo = Sexo.INDEFINIDO;
    private Date dataNascimento;

    
    
    /**
     * Retorna a data de nascimento
	 * @return a data de nascimento da pessoa
	 */
	public Date getDataNascimento() {
		return dataNascimento;
	}

	/**
	 * Define a data de nascimento da pessoa
	 * @param dataNascimento a data de nascimento da pessoa
	 */
	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	/**
     * Retorna o nome da pessoa
     * 
	 * @return O nome da pessoa
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * Define o nome da pessoa
	 * 
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
     * Retorna o valor da altura da pessoa, em metros.
     *
     * @return O valor da medida
     */
    public double getAltura() {
        return altura;
    }

    /**
     * Define a altura da pessoa, em metros.
     *
     * @param altura O valor da medida
     */
    public void setAltura(double altura) {
        this.altura = altura;
    }

    /**
     * Retorna a idade da pessoa, em anos.
     *
     * @return A idade, em anos
     */
    public Integer getIdade() {
    	Calendar calendar1 = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        calendar1.setTime(dataNascimento);
        calendar2.setTime(new Date());
        long milliseconds1 = calendar1.getTimeInMillis();
        long milliseconds2 = calendar2.getTimeInMillis();
        long diff = milliseconds2 - milliseconds1;
        long diffYear = (diff / (24 * 60 * 60 * 1000)) / 365;
        return (int) diffYear;
    }



    /**
     * Retorna o valor do peso da pessoa, em quilogramas.
     *
     * @return O valor da medida, em quilogramas.
     */
    public double getPeso() {
        return peso;
    }

    /**
     * Define o peso da pessoa, em quilogramas.
     *
     * @param peso O valor da medida, em quilogramas.
     */
    public void setPeso(double peso) {
        this.peso = peso;
    }

    /**
     * Retorna o sexo da pessoa
     *
     * @return O sexo da pessoa
     */
    public Sexo getSexo() {
        return sexo;
    }

    /**
     * Define o sexo da pessoa
     *
     * @param sexo {@code Sexo.MASCULINO}, {@code Sexo.FEMININO} ou
     * {@code Sexo.INDEFINIDO}
     * @see Sexo
     */
    public void setSexo(Sexo sexo) {
        if (sexo == null) {
            sexo = Sexo.INDEFINIDO;
        }
        this.sexo = sexo;
    }

    /**
     * Define o sexo da pessoa
     *
     * @param sexo Um caracter que representa o sexo da pessoa.
     * <p>
     * Por exemplo:
     * <ul>
     * <li>Caracter 'M' representa {@code Sexo.MASCULINO}</li>
     * <li>Caracter 'F' representa {@code Sexo.FEMININO}</li>
     * <li>Qualquer outro caracter representa {@code Sexo.INDEFINIDO}</li>
     * </ul></p>
     * <p><strong>Nota: </strong>a fun��o � case-insensitive.</p>
     *
     * @see setSexo(Sexo sexo)
     * @see Sexo
     * @deprecated Prefira utilizar constantes enum do tipo Sexo:
     * {@code setSexo(Sexo.MASCULINO)} ou {@code setSexo(Sexo.FEMININO)}
     */
    @Deprecated
    public void setSexo(char sexo) {
        this.sexo = Sexo.valueOf(sexo);
    }

    /**
     * Define o sexo da pessoa
     *
     * @param sexo Uma string de caracteres que representa o sexo da pessoa: M
     * para masculino, F para feminino
     * <p>
     * Caso seja passada uma String com mais de um caracter, somente o primeiro
     * ser� utilizado. Por exemplo: <br>
     * <ul>
     * <li>"Masculino": ser� definido como {@code Sexo.MASCULINO}</li>
     * <li>"Feminino" : ser� definido como {@code Sexo.FEMININO}</li>
     * <li>"Teste": ser� definido como {@code Sexo.INDEFININO}</li>
     * </ul>
     * </p>
     * <p><strong>Nota: </strong>a fun��o � case-insensitive.</p>
     *
     * @see setSexo(Sexo sexo)
     * @see Sexo
     * @deprecated Prefira utilizar constantes enum do tipo Sexo:
     * {@code setSexo(Sexo.MASCULINO)} ou {@code setSexo(Sexo.FEMININO)}
     */
    @Deprecated
    public void setSexo(String sexo) {
        this.sexo = Sexo.valueOf(sexo.charAt(0));
    }

    /**
     * Retorna o valor da circunfer�ncia do quadril da pessoa
     *
     * @return O valor da medida
     */
    public Double getCircunferenciaQuadril() {
        return circunferenciaQuadril;
    }

    /**
     * Define o valor da circunfer�ncia do quadril da pessoa
     *
     * @param circunferenciaQuadril O valor da medida
     */
    public void setCircunferenciaQuadril(Double circunferenciaQuadril) {
        this.circunferenciaQuadril = circunferenciaQuadril;
    }

    /**
     * Retorna o valor da circunfer�ncia da cintura da pessoa
     *
     * @return O valor da medida
     */
    public Double getCircunferenciaCintura() {
        return circunferenciaCintura;
    }

    /**
     * Define o valor da circunfer�ncia da cintura da pessoa
     *
     * @param circunferenciaCintura O valor da medida
     */
    public void setCircunferenciaCintura(Double circunferenciaCintura) {
        this.circunferenciaCintura = circunferenciaCintura;
    }

}
