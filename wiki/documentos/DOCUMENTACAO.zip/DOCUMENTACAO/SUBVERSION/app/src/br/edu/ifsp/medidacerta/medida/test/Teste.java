package br.edu.ifsp.medidacerta.medida.test;

import java.util.Date;

import br.edu.ifsp.medidacerta.medida.models.ico.ICO;
import br.edu.ifsp.medidacerta.shared.models.Pessoa;
import br.edu.ifsp.medidacerta.shared.models.Sexo;
import br.edu.ifsp.medidacerta.medida.models.imc.IMC;
import br.edu.ifsp.medidacerta.medida.models.rcq.RCQ;

/**
 * 
 * @author Tiago
 */
public class Teste {

	public static void main(String[] args) {
		Pessoa pessoa = new Pessoa();
		
		pessoa.setAltura(1.80f);
		pessoa.setPeso(84);
		pessoa.setDataNascimento(new Date(102, 9, 14));
		pessoa.setSexo("f");
		System.out.println("Sexo: " + pessoa.getSexo().name());
		System.out.println("Idade: " + pessoa.getIdade());
		
		IMC imc = new IMC(pessoa);
		System.out.println("Minha classifica��o: " + imc.getClassificacao());
		System.out.println("Meu IMC: " + imc);
		System.out.println("Dica: " + imc.getDica());
		System.out.println("IMC ideal: entre "
				+ imc.getClassificacao().getMinIdeal() + " e "
				+ imc.getClassificacao().getMaxIdeal() + "\n");

		// IMC s� com valores
		System.out.println("Nova classifica��o...");
		IMC imc2 = new IMC(66d, 1.85d, Sexo.FEMININO, 25);
		System.out.println("Classifica��o: " + imc2.getClassificacao());
		System.out.println("IMC: " + imc2);
		System.out.println("Dica: " + imc2.getDica());
		System.out.println("IMC ideal: entre "
				+ imc2.getClassificacao().getMinIdeal() + " e "
				+ imc2.getClassificacao().getMaxIdeal() + "\n");

		try {
			pessoa.setCircunferenciaCintura(99d);
			ICO ico = new ICO(pessoa);
			System.out.println("ICO: " + ico);
		} catch (Exception ex) {
			System.out.println("Erro: " + ex.getMessage());
		}
		try {
			pessoa.setCircunferenciaCintura(99d);
			pessoa.setCircunferenciaQuadril(99d);
			RCQ rcq = new RCQ(pessoa);
			System.out.println("RCQ: " + rcq);
		} catch (Exception ex) {
			System.out.println("Erro: " + ex.getMessage());
		}

	}
}
