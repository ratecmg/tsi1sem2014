package br.edu.ifsp.medidacerta.main.activity;

import android.app.Activity;
import android.os.Bundle;
import br.edu.ifsp.medidacerta.R;

public class TestRedirectActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_test_redirect);
    }



}
