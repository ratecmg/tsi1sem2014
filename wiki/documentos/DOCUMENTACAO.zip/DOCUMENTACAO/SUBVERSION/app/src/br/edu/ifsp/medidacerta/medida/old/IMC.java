package br.edu.ifsp.medidacerta.medida.old;
@Deprecated
public class IMC {
    public enum IMC_F{
        IDADE_2(15.7d, 17.1d, 18.7d),
        IDADE_3(15.4d, 16.8d, 18.4d),
        IDADE_4(15.0d, 16.8d, 18.5d),
        IDADE_5(14.3d, 16.9d, 18.8d),
        IDADE_6(13.7d, 17.0d, 17.5d),
        IDADE_7(14.1d, 17.5d, 18.2d),
        IDADE_8(14.1d, 18.7d, 19.8d),
        IDADE_9(14.6d, 19.8d, 21.2d),
        IDADE_10(14.3d, 18.7d, 19.8d),
        IDADE_11(15.3d, 21.8d, 23.4d),
        IDADE_12(15.6d, 23.1d, 24.6d),
        IDADE_13(16.3d, 23.8d, 25.2d),
        IDADE_14(17.1d, 24.7d, 26.2d),
        IDADE_15(17.5d, 24.1d, 25.6d),
        IDADE_16(18.3d, 25.7d, 26.8d),
        IDADE_17(17.9d, 25.7d, 26.2d);
        
        private double min;
        private double med;
        private double max;
        
        private IMC_F(double min, double med, double max) {
            this.min = min;
            this.med = med;
            this.max = max;
        }

        public double getMin(){
            return this.min;
        }
        
        public double getMed(){
            return this.med;
        }
        
        public double getMax(){
            return this.max;
        }
    }
    
    public enum IMC_M{
        IDADE_2(16.0d, 17.3d, 18.9d),
        IDADE_3(15.6d, 16.9d, 18.4d),
        IDADE_4(15.3d, 16.7d, 18.4d),
        IDADE_5(15.2d, 16.6d, 18.3d),
        IDADE_6(14.1d, 17.2d, 18.0d),
        IDADE_7(14.4d, 17.5d, 18.2d),
        IDADE_8(14.3d, 18.7d, 19.8d),
        IDADE_9(14.6d, 19.8d, 21.2d),
        IDADE_10(15.0d, 19.2d, 19.8d),
        IDADE_11(15.1d, 21.5d, 22.5d),
        IDADE_12(15.7d, 21.7d, 23.7d),
        IDADE_13(16.4d, 22.2d, 24.0d),
        IDADE_14(17.0d, 23.1d, 24.2d),
        IDADE_15(17.5d, 23.4d, 24.1d),
        IDADE_16(18.5d, 24.8d, 25.9d),
        IDADE_17(18.4d, 24.9d, 26.1d);
        
        private double min;
        private double med;
        private double max;
        
        private IMC_M(double min, double med, double max) {
            this.min = min;
            this.med = med;
            this.max = max;
        }

        public double getMin(){
            return this.min;
        }
        
        public double getMed(){
            return this.med;
        }
        
        public double getMax(){
            return this.max;
        }
        
    }
        
}