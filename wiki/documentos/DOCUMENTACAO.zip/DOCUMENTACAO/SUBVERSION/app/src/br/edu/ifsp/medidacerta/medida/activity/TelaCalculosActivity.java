package br.edu.ifsp.medidacerta.medida.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import br.edu.ifsp.medidacerta.R;
//import br.edu.ifsp.medidacerta.medida.Medida;

public class TelaCalculosActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_m_principal);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_m_principal, menu);
		return true;
	}
	/*
	private void calcularIMC() {
		Perfil pf = new Perfil();
		
		double p = pf.getPeso();
		double h = pf.getAltura();
		char/*ou boolean  sx = pf.getSexo();
		int id = pf.getIdade();
		
		int idclass = Medida.IMC(h, p, id, sx == 'm');
		double[] imcideal = Medida.IMCIdeal(h, id, sx == 'm');
        double imcidealmin = imcideal[0];
        double imcidealmax = imcideal[1];
        
        double pesoidealmin = (imcidealmin * Math.pow(h, 2.5))/1.3;
        double pesoidealmax = (imcidealmax * Math.pow(h, 2.5))/1.3;
		
	}
	*/
}
