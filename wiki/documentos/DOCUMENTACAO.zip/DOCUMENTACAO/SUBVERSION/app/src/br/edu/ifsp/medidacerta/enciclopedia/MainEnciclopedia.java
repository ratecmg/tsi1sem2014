package br.edu.ifsp.medidacerta.enciclopedia;

import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.R.layout;
import br.edu.ifsp.medidacerta.R.menu;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class MainEnciclopedia extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//// Linha abaixo causando erros (activity inexistente?)
		// setContentView(R.layout.activity_main_enciclopedia);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present. TESTE
		
		//// Linha abaixo causando erros (activity inexistente?)
		// getMenuInflater().inflate(R.menu.activity_main_enciclopedia, menu);
		return true;
	}

}
