package br.edu.ifsp.medidacerta.medida.test;

import java.util.Date;

import br.edu.ifsp.medidacerta.medida.models.ico.ICO;
import br.edu.ifsp.medidacerta.medida.models.imc.IMC;
import br.edu.ifsp.medidacerta.medida.models.rcq.RCQ;
import br.edu.ifsp.medidacerta.shared.models.Pessoa;
import br.edu.ifsp.medidacerta.shared.models.Sexo;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tiago
 */
public class Teste2 {
    public static void main(String[] args) {
        Pessoa p = new Pessoa();
        p.setAltura(1.80d);
        p.setDataNascimento(new Date(90, 2, 23));
        p.setPeso(88);
        p.setSexo(Sexo.FEMININO);
        
        IMC imc = new IMC(p);
        System.out.println("IMC: " + imc);
        System.out.println("Classifica��o: " + imc.getClassificacao());
        System.out.println("Dica: " + imc.getDica());
        System.out.println("IMC ideal: entre " + imc.getClassificacao().getMinIdeal() + " e " + imc.getClassificacao().getMaxIdeal());
        try {
            p.setCircunferenciaCintura(99d);
            ICO ico = new ICO(p);
            System.out.println("ICO: " + ico);
            p.setCircunferenciaQuadril(101d);
            RCQ rcq = new RCQ(p);
            System.out.println("RCQ: " + rcq);
        } catch (Exception ex) {
            System.out.println("Erro: " + ex.getMessage());
        }
       
        
        
        
    }
}
