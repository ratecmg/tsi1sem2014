package br.edu.ifsp.medidacerta.main;

import br.edu.ifsp.medidacerta.main.activity.*;


public enum Tela {

    TESTES (TestRedirectActivity.class),  
    PERFIL_CADASTRO(null),
    PERFIL_LOGIN(null),
    MEDIDA_VISUALIZAR_IMC(null),
    MEDIDA_VISUALIZAR_ICO(null);

    
    private Class telaClass;

    private Tela(Class telaClass) {
	this.telaClass = telaClass;
    }

    public Class getActivityClass() {
	return telaClass;
    }

}
