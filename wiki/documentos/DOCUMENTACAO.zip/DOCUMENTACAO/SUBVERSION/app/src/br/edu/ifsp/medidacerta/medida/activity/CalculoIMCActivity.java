package br.edu.ifsp.medidacerta.medida.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import br.edu.ifsp.medidacerta.R;

public class CalculoIMCActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_m_calculo_imc);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_m_calculo_imc, menu);
		return true;
	}

	

}
