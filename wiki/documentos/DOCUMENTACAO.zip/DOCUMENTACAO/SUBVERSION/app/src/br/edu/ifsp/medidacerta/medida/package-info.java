/**
 * Pacote da equipe de Medidas
 * 
 * @author Cl�udio
 * @author Kelvin 
 * @author Tiago 
 * @author Wellington 
 */
package br.edu.ifsp.medidacerta.medida;