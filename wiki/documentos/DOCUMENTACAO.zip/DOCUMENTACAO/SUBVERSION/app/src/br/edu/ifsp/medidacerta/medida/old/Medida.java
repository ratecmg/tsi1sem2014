package br.edu.ifsp.medidacerta.medida.old;

@Deprecated
public class Medida {

    public static double[] IMCIdeal(double h, int id, boolean sx){
        double[] imcideal = {0, 0};
        
        if(id >=18 && id < 65){//adulto (homem ou mulher)
            imcideal[0] = 18.5;
            imcideal[1] = 25;
        }
        
        if(sx){//homem = true?
            if(id < 18){//menino-rapaz
                int c = 2;
                for(IMC.IMC_M imcm : IMC.IMC_M.values()){
                    if(c == id){
                        imcideal[0] = imcm.getMin();
                        imcideal[1] = imcm.getMed();
                    } else {
                        c++;
                    }
                }
            } else if(id > 65){//idoso
                imcideal[0] = 22;
                imcideal[1] = 27;
            } 
        } else {//mulher = false?
            if(id < 18){//menina-rapariga
                int c = 2;
                for(IMC.IMC_F imcf : IMC.IMC_F.values()){
                    if(c == id){
                        imcideal[0] = imcf.getMin();
                        imcideal[1] = imcf.getMed();
                    } else {
                        c++;
                    }
                }
            } else if(id < 18){//idosa
                imcideal[0] = 22;
                imcideal[1] = 27;
            }
        }
        
        return imcideal;
    }
    
    public static int IMC(double h, double p, int id, boolean sx){
        double imc;
        int idClassif = 0;
        
        imc = 1.3*p/Math.pow(h, 2.5);
        
        if(id >=18 && id < 65){//adulto (homem ou mulher)
                if(imc < 16){
                    idClassif = 1;//magreza severa
                }
                if(imc >= 16 && imc < 17){
                    idClassif = 2;//magreza moderada
                }
                if(imc >= 17 && imc < 18.5){
                    idClassif = 3;//magreza leve/subnutri��o
                }
                if(imc >= 18.5 && imc < 25){
                    idClassif = 4;//saud�vel/eutrofia
                }
                if(imc >= 25 && imc < 30){
                    idClassif = 5;//sobrepeso
                }
                if(imc >= 30 && imc < 35){
                    idClassif = 6;//obesidade
                }
                if(imc >= 35 && imc < 40){
                    idClassif = 7;//obesidade severa
                }
                if(imc >= 40){
                    idClassif = 8;//obesidade m�rbida
                }
        }
        
        if(sx){//homem = true?
            if(id < 18){//menino-rapaz
                for(IMC.IMC_M imcm : IMC.IMC_M.values()){
                    if(imc < imcm.getMin()){
                        idClassif = 3;//magreza leve/subnutri��o
                    }
                    if(imc >= imcm.getMin() && imc <= 
                            imcm.getMed()){
                        idClassif = 4;//saud�vel/eutrofia
                    }
                    if(imc >= imcm.getMed() && imc <= 
                            imcm.getMax()){
                        idClassif = 5;//sobrepeso
                    }
                    if(imc > imcm.getMax()){
                        idClassif = 6;//obesidade
                    }
                }
            } else if(id > 65){//idoso
                if(imc < 22){
                    idClassif = 3;//magreza leve/subnutri��o
                }
                if(imc >= 22 && imc <= 27){
                    idClassif = 4;//saud�vel/eutrofia
                }
                if(imc > 27 && imc <= 30){
                    idClassif = 5;//sobrepeso
                }
                if(imc > 30 && imc <= 35){
                    idClassif = 6;//obesidade
                }
                if(imc > 35 && imc < 40){
                    idClassif = 7;//obesidade severa
                }
                if(imc >= 40){
                    idClassif = 8;//obesidade m�rbida
                }
            } 
        } else {//mulher = false?
            if(id < 18){//menina-rapariga
                for(IMC.IMC_F imcf : IMC.IMC_F.values()){
                    if(imc < imcf.getMin()){
                        idClassif = 3;//magreza leve/subnutri��o
                    }
                    if(imc >= imcf.getMin() && imc <= 
                            imcf.getMed()){
                        idClassif = 4;//saud�vel/eutrofia
                    }
                    if(imc >= imcf.getMed() && imc <= 
                            imcf.getMax()){
                        idClassif = 5;//sobrepeso
                    }
                    if(imc > imcf.getMax()){
                        idClassif = 6;//obesidade
                    }
                }
            } else if(id < 18){//idosa
                if(imc < 22){
                    idClassif = 3;//magreza leve/subnutri��o
                }
                if(imc >= 22 && imc <= 27){
                    idClassif = 4;//saud�vel/eutrofia
                }
                if(imc > 27 && imc <= 32){
                    idClassif = 5;//sobrepeso
                }
                if(imc > 32 && imc <= 37){
                    idClassif = 6;//obesidade
                }
                if(imc > 37 && imc < 42){
                    idClassif = 7;//obesidade severa
                }
                if(imc >= 42){
                    idClassif = 8;//obesidade m�rbida
                }

            }
        }
        
        return idClassif;
    }
    
    public static double ICO(double h, double p, double c/*em metro*/){
        double ico;
        
        ico = c/(0.109 * (Math.sqrt(p)/h));
        
        return ico;
    }
    
    public static double RCQ(double q, double c/*em cent�metros*/){
        double rcq;
        
        rcq = c/q;
        
        return rcq;
    }
    
}
