package br.edu.ifsp.medidacerta.enciclopedia;


public class Enciclopedia  {

}
