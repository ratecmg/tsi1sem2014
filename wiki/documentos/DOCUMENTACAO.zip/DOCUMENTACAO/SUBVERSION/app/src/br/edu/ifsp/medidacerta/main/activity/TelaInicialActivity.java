package br.edu.ifsp.medidacerta.main.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.main.Tela;

public class TelaInicialActivity extends Activity {
    private static int SPLASH_TIME_OUT = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_tela_inicial);
	new Handler().postDelayed(new Runnable() {
	    @Override
	    public void run() {	
		Intent intent = new Intent(TelaInicialActivity.this, Tela.TESTES.getActivityClass());
		startActivity(intent);		
		finish();
	    }
	}, SPLASH_TIME_OUT);
    }

    

}
