package br.edu.ifsp.medidacerta.perfil;


public class Perfil {

	public double getPeso() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getAltura() {
		// TODO Auto-generated method stub
		return 0;
	}

	public char /*boolean*/ getSexo() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getIdade() {
		// TODO Auto-generated method stub
		return 0;
	}
    

}
