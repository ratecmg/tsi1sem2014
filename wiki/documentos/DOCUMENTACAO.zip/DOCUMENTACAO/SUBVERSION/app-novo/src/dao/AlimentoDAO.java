package dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.edu.ifsp.medidacerta.UtilHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import classe.Alimento;
import classe.GrupoAlimento;
import classe.Usuario;

public class AlimentoDAO extends DAO<Alimento> {

	private SQLiteDatabase database;
	
	private String[] campos;
	private String tableName;
	
	public AlimentoDAO (Context context) {
		super(context);
		campos = new String[]{"id_alimento","id_grupo_alimento","alimento","descricao","caloria_porcao","figura","origem","data_atualizacao"};
		tableName = "alimento";
		database = getWritableDatabase();
	}
	
	/**
	 * M�todo para recuperar alimento pelo id
	 * @param Valor inteiro
	 * @return Um objeto do tipo alimento
	 */
	public Alimento getByID(Integer id) {
		
		Alimento alimento = null;
		
		Cursor cursor = executeSelect("id_alimento = ?", new String[]{String.valueOf(id)}, null);
		
		if(cursor!=null && cursor.moveToFirst())
		{
			alimento = serializeByCursor(cursor);			
		}
		if(!cursor.isClosed())
		{
			cursor.close();
		}
		
		return alimento;
	}
	
	/**
	 * M�todo para recuperar uma lista de alimentos cadastrados
	 * @param String com um termo para a busca de alimetno
	 * @return Lista de alimentos encontrados
	 */
	public List<Alimento> getByAlimento(String a) {
		List<Alimento> alimentos = null; 
		
		Cursor cursor = executeSelect("alimento like ?", new String[]{"%" + a + "%"}, null);
		
		if(cursor!=null && cursor.moveToFirst())
		{
			alimentos = new ArrayList<Alimento>();
			do{
				alimentos.add(serializeByCursor(cursor));
			}while( cursor.moveToNext() );
		}
		if(!cursor.isClosed())
		{
			cursor.close();
		}
		return alimentos;
	}
	
	/**
	 * M�todo que recupera todos os alimentos cadastrados
	 * @return Lista com todos os alimetnos cadastrados
	 */
	public List<Alimento> listAll() {
		List<Alimento> list = new ArrayList<Alimento>();
		this.openDataBase();
		Cursor cursor = executeSelect(null, null, "alimento");
		
		if(cursor!=null && cursor.moveToFirst())
		{
			int i = 0;
			do{
				list.add(serializeByCursor(cursor));
				i++;
			}while(cursor.moveToNext());
		}
		
		if(!cursor.isClosed())
		{
			cursor.close();
		}
		
		return list;		
	}
	
	/**
	 * M�todo para persistir um alimetno
	 * @param Alimento a ser salvo
	 * @return Valor verdadeiro em caso de sucesso e falso em caso de falha
	 */
	public boolean salvar(Alimento alimento) {
		ContentValues values = serializeContentValues(alimento);
		if(database.insert(tableName, null, values)>0)
			return true;			
		else
			return false;
	}

	/**
	 * M�todo para serializar um alimento
	 * @param Cursor com dados vindos do banco
	 * @return Objeto do tipo Alimento
	 */
	private Alimento serializeByCursor(Cursor cursor){
		//"id_alimento","id_grupo_alimento","alimento","descricao","caloria_porcao","figura","origem"
		Alimento alimento = new Alimento();
		alimento.setIdAlimento(cursor.getInt(0));
		
		GrupoAlimento gpAlimento = new GrupoAlimento();
		gpAlimento.setIdGrupoAlimentos(cursor.getInt(1));
		alimento.setGrupoAlimento(gpAlimento);
		
		alimento.setAlimento(cursor.getString(2));
		
		alimento.setDescricao(cursor.getString(3));
		
		alimento.setCaloriaPorcao(cursor.getString(4));
		
		alimento.setFigura(cursor.getString(5));
		
		alimento.setOrigem(cursor.getString(6));
		
		try {
			alimento.setDataAtualizacao(UtilHelper.getDataByStringDateHour(cursor.getString(7)));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return alimento;		
	}
	
	private ContentValues serializeContentValues(Alimento alimento){
		//"id_alimento","id_grupo_alimento","alimento","descricao","caloria_porcao","figura","origem"
		ContentValues values = new ContentValues();
		values.put("id_alimento", alimento.getIdAlimento());
		values.put("id_grupo_alimento", alimento.getGrupoAlimento().getDescricao());
		values.put("alimento", alimento.getAlimento());
		values.put("descricao", alimento.getDescricao());
		values.put("caloria_porcao", alimento.getCaloriaPorcao());
		values.put("figura", alimento.getFigura());
		values.put("origem", alimento.getOrigem());
		values.put("data_atualizacao", UtilHelper.getDataHourToPersist(alimento.getDataAtualizacao()));
		values.put("id_grupo_alimento", alimento.getGrupoAlimento().getIdGrupoAlimentos());
		
		return values;
	}	
	
	private Cursor executeSelect(String selection, String[] selectionArgs, String orderBy)
	{		
		return database.query(tableName,campos, selection, selectionArgs, null, null, orderBy);

	}
	
}
