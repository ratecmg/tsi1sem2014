package dao;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import classe.CadastroBasico;
import classe.CadastroComplementar;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * 
 * @author Richard
 * Faz o CRUD das medidas complementares do usu�rio (circunfer�ncia abdominal, circunfer�ncia do quadril, frequ�ncia card�aca e press�o arterial)
 */
public class MedidasDAO extends DAO<CadastroComplementar>{
	
	private SQLiteDatabase database;
	private String[] campos = new String[]{"id_medida_complementar","id_usuario","circ_abdominal","quadril","freq_cardiaca","pressao_cardiaca","data_atualizacao"};
	private String tableName = "medida_complementar";
	
	public MedidasDAO(Context context) {
		super(context);
		
        database = getWritableDatabase();
		
	}
	
	/**
	 * Recupera o �ltimo Cadastro Complementar do usu�rio pelo seu id
	 * @param id do usu�rio
	 * @return Cadastro Complementar
	 */
	public CadastroComplementar getByID(Integer id) {
		CadastroComplementar medidas = null;
		
		Cursor cursor = executeSelect("id_usuario = ?", new String[]{String.valueOf(id)}, "id_medida_complementar DESC");
		
		if(cursor!=null && cursor.moveToFirst())
		{
			medidas = serializeByCursor(cursor);			
		}
		if(!cursor.isClosed())
		{
			cursor.close();
		}
		
		
		return medidas;
	}
	/**
	 *  Recupera uma lista de Cadastro Complementar pelo id do usu�rio
	 * @param id do usu�rio
	 * @return Lista de Cadastro Complementar
	 */
	public List<CadastroComplementar> getTodosOrdenadosPelaUltimaInclusao(Integer id) {
		List<CadastroComplementar> list = new ArrayList<CadastroComplementar>();

		Cursor cursor = executeSelect("id_usuario = ?", new String[]{String.valueOf(id)}, "id_medida_complementar DESC");
		
		if(cursor != null && cursor.moveToFirst())
		{
			do{
				list.add(serializeByCursor(cursor));
			}while(cursor.moveToNext());			
		}
		if(!cursor.isClosed())
		{
			cursor.close();
		}
		
		return list;
	}
	/**
	 * M�todo respons�vel por salvar as informa��es complementares do usu�rio
	 * @param objeto de Cadastro Complementar
	 * @return Um valor booleano - Se salvou ou n�o o Cadastro Complementar
	 * 
	 */
	public boolean salvar(CadastroComplementar medidas) {
		ContentValues values = serializeContentValues(medidas);
		if(database.insert(tableName, null, values)>0)
			return true;			
		else
			return false;
	}

	/**
	 * M�todo respons�vel por atualizar as informa��es complementares do usu�rio
	 * @param objeto de Cadastro Complementar
	 * @return Um valor booleano - Se atualizou ou n�o o Cadastro Complementar
	 * 
	 */
	public boolean atualizar(CadastroComplementar medidas) {
		ContentValues values = serializeContentValues(medidas);
		if(database.update(tableName, values, "id_usuario = ?", new String[]{String.valueOf(medidas.getId_usuario())})>0)
			return true;
		else
			return false;
	}		

	private CadastroComplementar serializeByCursor(Cursor cursor)
	{
		CadastroComplementar m = new CadastroComplementar();
		m.setId(cursor.getInt(0));
		m.setId_usuario(cursor.getInt(1));
		m.setCircunferencia(cursor.getDouble(2));
		m.setQuadril(cursor.getDouble(3));
		m.setFrequencia(cursor.getDouble(4));
		m.setPressao(cursor.getString(5));
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		String dataTeste = cursor.getString(6);
		Date dt = new Date(dataTeste);		
		m.setAtualizacao(dt);
		
		return m;
		
	}
	
	
	

	private ContentValues serializeContentValues(CadastroComplementar medidas)
	{
		ContentValues values = new ContentValues();
		//values.put("id_medida_complementar", medidas.getId());
		values.put("id_usuario",medidas.getId_usuario());
		values.put("circ_abdominal", medidas.getCircunferencia());
		values.put("quadril", medidas.getQuadril());
		values.put("freq_cardiaca", medidas.getFrequencia());
		values.put("pressao_cardiaca", medidas.getPressao());
		values.put("data_atualizacao", medidas.getAtualizacao().toString());
		
		return values;
	}	
	
	
	
	private Cursor executeSelect(String selection, String[] selectionArgs, String orderBy)
	{
		
		return database.query(tableName,campos, selection, selectionArgs, null, null, orderBy);		

	}

}
