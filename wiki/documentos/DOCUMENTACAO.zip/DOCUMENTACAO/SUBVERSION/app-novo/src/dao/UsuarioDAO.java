package dao;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.edu.ifsp.medidacerta.UtilHelper;
import classe.Usuario;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

/**
 * 
 * @author Douglas
 * Faz o CRUD das informa��es do usu�rio ("id", "nome", "email", "sexo",
			"data_nascimento", "senha", "objetivo", "meta_calorica")
 */
public class UsuarioDAO extends DAO<Usuario> {
	
	private Context context;
	private SQLiteDatabase database;
	private String[] campos = new String[] { "id", "nome", "email", "sexo",
			"data_nascimento", "senha", "objetivo", "meta_calorica" };
	private String tableName = "usuario";

	public UsuarioDAO(Context context2) {
		super(context2);
		context = context2;;

		database = getWritableDatabase();
	}
	/**
	 * Recupera o Usuario do usu�rio pelo seu login
	 * @param login e senha
	 * @return Usuario
	 */

	public Usuario getByLoginSenha(String login, String senha) {
		Usuario usuario = null;

		Cursor cursor = executeSelect("email = ? AND senha = ?", new String[] {
				login, senha }, null);

		if (cursor != null && cursor.moveToFirst()) {
			usuario = serializeByCursor(cursor);
		}
		if (!cursor.isClosed()) {
			cursor.close();
		}

		return usuario;
	}
	/**
	 * Recupera o Usuario do usu�rio pelo seu nome
	 * @param nome
	 * @return Usuario
	 */
	public Usuario getByNome(String nome) {
		Usuario usuario = null;

		Cursor cursor = executeSelect("nome = ?", new String[] { nome }, null);

		if (cursor != null && cursor.moveToFirst()) {
			usuario = serializeByCursor(cursor);
		}
		if (!cursor.isClosed()) {
			cursor.close();
		}
		return usuario;
	}
	/**
	 * Verifica se um email j� existe no banco
	 * @param email
	 * @return booleano - Se existe ou n�o um email
	 */
	public boolean existeByEmail(String email) {
		Usuario usuario = null;

		Cursor cursor = executeSelect("email = ?", new String[] { email }, null);

		if (cursor != null && cursor.moveToFirst()) {
			usuario = serializeByCursor(cursor);
		}
		if (!cursor.isClosed()) {
			cursor.close();
		}

		if (usuario != null)
			return true;

		return false;
	}
	/**
	 * Recupera o Usuario do usu�rio pelo seu id
	 * @param id
	 * @return Usuario
	 */
	public Usuario getByID(Integer id) {
		Usuario usuario = null;

		Cursor cursor = executeSelect("id = ?",
				new String[] { String.valueOf(id) }, null);

		if (cursor != null && cursor.moveToFirst()) {
			usuario = serializeByCursor(cursor);
		}
		if (!cursor.isClosed()) {
			cursor.close();
		}
		return usuario;
	}
	/**
	 * Autentica o usuario no sistema
	 * @param login e senha
	 * @return Usuario
	 */

	public Usuario getAutenticacao(String login, String senha) {
		Usuario usuario = null;

		Cursor cursor = executeSelect("login = ?, senha = ?", new String[] {
				login, senha }, null);

		if (cursor != null && cursor.moveToFirst()) {
			usuario = serializeByCursor(cursor);
		}
		if (!cursor.isClosed()) {
			cursor.close();
		}
		return usuario;
	}
	
	/**
	 * Retorna uma lista com todos os usuarios
	 * @param
	 * @return Lista de usuario
	 */


	public List<Usuario> listAll() {
		List<Usuario> list = new ArrayList<Usuario>();
		this.openDataBase();
		Cursor cursor = executeSelect(null, null, "1");

		if (cursor != null && cursor.moveToFirst()) {
			do {
				list.add(serializeByCursor(cursor));
			} while (cursor.moveToNext());
		}

		if (!cursor.isClosed()) {
			cursor.close();
		}

		return list;
	}
	
	/**
	 * Salva um usuario no banco
	 * @param usuario
	 * @return booleano - Se salvou ou n�o o usuario
	 */

	public boolean salvar(Usuario usuario) {
		ContentValues values = serializeContentValues(usuario);
		if (database.insert(tableName, null, values) > 0)
			return true;
		else
			return false;
	}
	
	/**
	 * Deleta um usuario no banco
	 * @param usuario
	 * @return booleano - Se deletou ou n�o o usuario
	 */

	public boolean deletar(Integer id) {
		if (database.delete(tableName, "id = ?",
				new String[] { String.valueOf(id) }) > 0)
			return true;
		else
			return false;
	}
	
	/**
	 * Atualiza um usuario no banco
	 * @param usuario
	 * @return booleano - Se atualizou ou n�o o usuario
	 */

	public boolean atualizar(Usuario usuario) {
		ContentValues values = serializeContentValues(usuario);
		if (database.update(tableName, values, "id = ?",
				new String[] { String.valueOf(usuario.getId()) }) > 0)
			return true;
		else
			return false;
	}

	private Usuario serializeByCursor(Cursor cursor) {
		Usuario usuario = new Usuario();
		usuario.setId(cursor.getInt(0));
		usuario.setNome(cursor.getString(1));
		usuario.setEmail(cursor.getString(2));
		usuario.setSexo(cursor.getString(3));
		try {
			usuario.setDataNascimento(UtilHelper.getDataByStringDate(cursor.getString(4)));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Toast.makeText(context, "Erro ao converter data"+e.getMessage(), Toast.LENGTH_LONG).show();
		}
		usuario.setSenha(cursor.getString(5));
		int teste = cursor.getInt(6);
		usuario.setObjetivo(cursor.getInt(6));
		usuario.setMetaCalorica(cursor.getInt(7));
		return usuario;
	}

	private ContentValues serializeContentValues(Usuario usuario) {
		ContentValues values = new ContentValues();
		values.put("id", usuario.getId());
		values.put("nome", usuario.getNome());
		values.put("email", usuario.getEmail());
		values.put("sexo", String.valueOf(usuario.getSexo().getCode()));
		values.put("data_nascimento",
				UtilHelper.getDataToPersist(usuario.getDataNascimento()));
		values.put("senha", usuario.getSenha());
		if (usuario.getObjetivo() != null)
			values.put("objetivo", usuario.getObjetivo().getId());
		else
			values.put("objetivo", 0);
		values.put("meta_calorica", usuario.getMetaCalorica());

		return values;
	}

	private Cursor executeSelect(String selection, String[] selectionArgs,
			String orderBy) {
		return database.query(tableName, campos, selection, selectionArgs,
				null, null, orderBy);
		// return null;
	}
}