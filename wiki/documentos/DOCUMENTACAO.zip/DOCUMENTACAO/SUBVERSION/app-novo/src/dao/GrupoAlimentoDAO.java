package dao;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import classe.GrupoAlimento;

public class GrupoAlimentoDAO extends DAO<GrupoAlimento> {

	private SQLiteDatabase database;
	
	private String[] campos;
	private String tableName;
	
	public GrupoAlimentoDAO(Context context) {
		super(context);
		campos = new String[]{"id_grupo_alimento","grupo_alimento","descricao"};
		tableName = "grupo_alimento";
		database = getWritableDatabase();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * M�todo que lista todos os grupos cadastrados
	 * @return
	 */
	public List<GrupoAlimento> listAll() {
		List<GrupoAlimento> list = new ArrayList<GrupoAlimento>();
		this.openDataBase();
		Cursor cursor = executeSelect(null, null, "id_grupo_alimento");
		
		if(cursor!=null && cursor.moveToFirst())
		{
			int i = 0;
			do{
				list.add(serializeByCursor(cursor));
				i++;
			}while(cursor.moveToNext() && i < 50);
		}
		
		if(!cursor.isClosed())
		{
			cursor.close();
		}
		
		return list;		
	}
	
	/**
	 * M�todo que serializa um grupo de alimentos
	 * @param Cursor com dados do banco
	 * @return Um objeto do tipo GrupoAlimento
	 */
	private GrupoAlimento serializeByCursor(Cursor cursor)
	{
		//"id_alimento","id_grupo_alimento","alimento","descricao","caloria_porcao","figura","origem"
		GrupoAlimento grupoAlimento = new GrupoAlimento();
		grupoAlimento.setIdGrupoAlimentos(cursor.getInt(0));
		
		grupoAlimento.setGrupoAlimento(cursor.getString(1));
		
		grupoAlimento.setDescricao(cursor.getString(2));

		return grupoAlimento;		
	}
	
	private Cursor executeSelect(String selection, String[] selectionArgs, String orderBy)
	{		
		return database.query(tableName,campos, selection, selectionArgs, null, null, orderBy);

	}
}
