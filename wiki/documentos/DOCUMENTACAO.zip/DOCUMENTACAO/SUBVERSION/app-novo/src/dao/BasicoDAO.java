package dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;
import br.edu.ifsp.medidacerta.UtilHelper;
import classe.CadastroBasico;

/**
 * 
 * @author Raissa
 * Faz o CRUD das informa��es b�sicas do usu�rio (altura, peso, meta calorica e objetivo)
 */
public class BasicoDAO extends DAO<CadastroBasico>{
	
	private SQLiteDatabase database;
	private String[] campos  = new String[]{"id_medida","id_usuario","altura","peso","data_atualizacao"};
	private String tableName = "medida_basica";
	private Context context;
	
	public BasicoDAO(Context context2) {
		super(context2);
		context = context2;
		database = getWritableDatabase();
		
	}
	
	/**
	 * Recupera o Cadastro B�sico do usu�rio pelo seu id
	 * @param id do usu�rio
	 * @return Cadastro B�sico
	 */
	public CadastroBasico getByID(Integer id) {
		
		CadastroBasico cadastro = null;
		
		Cursor cursor = executeSelect("id_usuario = ?", new String[]{String.valueOf(id)}, null);
		
		if(cursor != null && cursor.moveToFirst())
		{
			cadastro = serializeByCursor(cursor);			
		}
		if(!cursor.isClosed())
		{
			cursor.close();
		}
		
		return cadastro;
	}
	
	/**
	 * Recupera o �ltimo Cadastro B�sico do usu�rio pelo seu id
	 * @param id do usu�rio
	 * @return Cadastro B�sico
	 */
	public CadastroBasico getByIDOrder(Integer id) {
		
		CadastroBasico cadastro = null;
		
		Cursor cursor = executeSelect("id_usuario = ?", new String[]{String.valueOf(id)}, "id_medida DESC");
		
		if(cursor != null && cursor.moveToFirst())
		{
			cadastro = serializeByCursor(cursor);			
		}
		if(!cursor.isClosed())
		{
			cursor.close();
		}
		
		return cadastro;
	}
	
	/**
	 *  Recupera uma lista de Cadastros B�sicos pelo id do usu�rio
	 * @param id do usu�rio
	 * @return Lista de Cadastros B�sicos
	 */
public List<CadastroBasico> getTodosOrdenadosPelaUltimaInclusao(Integer id) {
		List<CadastroBasico> list = new ArrayList<CadastroBasico>();

		Cursor cursor = executeSelect("id_usuario = ?", new String[]{String.valueOf(id)}, "id_medida DESC");
		
		if(cursor != null && cursor.moveToFirst())
		{
			do{
				list.add(serializeByCursor(cursor));
			}while(cursor.moveToNext());			
		}
		if(!cursor.isClosed())
		{
			cursor.close();
		}
		
		return list;
	}

	/**
	 * M�todo respons�vel por salvar as informa��es b�sicas do usu�rio
	 * @param objeto de Cadastro B�sico
	 * @return Um valor booleano - Se salvou ou n�o o Cadastro B�sico
	 */
	public boolean salvar(CadastroBasico cadBasico) {
		
		ContentValues values = serializeContentValues(cadBasico);
		
		if(database.insert(tableName, null, values) > 0)
			return true;			
		else
			return false;
	}

	/*public boolean deletar(Integer id) {
		if(database.delete(tableName, "id_usuario = ?", new String[]{String.valueOf(id)})>0)
			return true;
		else
			return false;
	}*/

	/*public boolean atualizar(CadastroBasico cadBasico) {
		
		ContentValues values = serializeContentValues(cadBasico);
		if(database.update(tableName, values, "id_usuario = ?", 
							new String[]{String.valueOf(cadBasico.getId_usuario())})>0)
			return true;
		else
			return false;
	}		*/

	
	private CadastroBasico serializeByCursor(Cursor cursor)
	{
		CadastroBasico cadBasico = new CadastroBasico();
		cadBasico.setId_medida(cursor.getInt(0));
		cadBasico.setId_usuario(cursor.getInt(1));
		cadBasico.setAltura(cursor.getFloat(2));
		cadBasico.setPeso(cursor.getFloat(3));
		String sdt = "";
		
		/**
		 * O c�digo comentado abaixo � a vers�o antiga que 
		 * parecia estar funcionando, mas n�o estava. 
		 * N�o causava erros pois a vari�vel dt estava sendo 
		 * instanciada logo no in�cio. 
		 * Quando chegava no dateFormat.parse gerava uma exce��o,
		 * ca�a no catch, mas beleza: dt j� tinha um valor e n�o 
		 * dava erros mais tarde.
		 * 
		 * Quando o Paulo alterou o c�digo, o bug foi revelado :P
		 * 
		 */
		//		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		//		String dataTeste = cursor.getString(4);
		//		Date dt = new Date();
		//		try {
		//			dt = dateFormat.parse(dataTeste);
		/////////// Sempre gerou exce��o, mas ningu�m percebeu. 
		/////////// O formato para o parse est� errado. 
		/////////// Deve ser "EEE MMM dd HH:mm:ss z yyyy" (que � bugado tbm) 
		//		} catch (ParseException e) {
		//			// TODO Auto-generated catch block
		//			e.printStackTrace();
		//		}
			
		/**
		 * Os m�todos abaixo resolvem o problema, mas somente se estiverem
		 * no novo padr�o (dd/MM/yyyy).
		 * O m�todo getDataByStringDate foi modificado para aceitar o formato antigo,
		 * mas n�o � garantido, pois o formato date.toString() sempre d� dor de cabe�a.
		 * Solu��o: apague o banco e n�o usem mais o formato antigo.	 
		 */
		Date data_atualizacao = new Date();	
		try {
		    
			sdt = cursor.getString(cursor.getColumnIndex("data_atualizacao"));
			// Obtem a data no novo formato
			data_atualizacao = (UtilHelper.getDataByStringDate(sdt));
		} catch (Exception e) {			
				Toast.makeText(context, "Erro ao converter data " + e.getMessage() + "\n::" + sdt, Toast.LENGTH_LONG).show();
		}		
		cadBasico.setData_atualizacao(data_atualizacao);
		
		
		return cadBasico;
		
	}
	
	private ContentValues serializeContentValues(CadastroBasico cadBasico)
	{
		ContentValues values = new ContentValues();
		//values.put("id_medida", cadBasico.getId_medida());
		values.put("id_usuario", cadBasico.getId_usuario());
		values.put("altura", cadBasico.getAltura());
		values.put("peso", cadBasico.getPeso());
		values.put("data_atualizacao", UtilHelper.getDataToPersist(cadBasico.getData_atualizacao()));
		
		return values;
	}	
	
	private Cursor executeSelect(String selection, String[] selectionArgs, String orderBy)
	{
		
		return database.query(tableName,campos, selection, selectionArgs, null, null, orderBy);		
	}

}