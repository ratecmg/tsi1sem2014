package dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import br.edu.ifsp.medidacerta.UtilHelper;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;
import classe.Alimento;
import classe.ConsumoDiario;
import classe.DataCaloriaGrafico;
import classe.GrupoAlimento;
import classe.Usuario;
import classe.UsuarioLogado;

public class ConsumoDAO extends DAO<ConsumoDiario> {

	private SQLiteDatabase database;

	private Context context;
	private String[] campos;
	private String tableName;

	public ConsumoDAO(Context context2) {
		super(context2);
		context = context2;
		campos = new String[] { "id_consumo", "id_alimento", "id_usuario",
				"data_hora_consumo", "qtde_consumo" };
		tableName = "cadastro_consumo";
		database = getWritableDatabase();
	}
	
	/**
	 * Recupera um consumo di�rio pelo id
	 * @param Valor inteiro
	 * @return Um objeto do tipo Consumo di�rio
	 */
	public ConsumoDiario getByID(Integer id) {
		ConsumoDiario c = null;
		Cursor cursor = executeSelect("id_consumo = ?",
				new String[] { String.valueOf(id) }, null);

		if (cursor != null && cursor.moveToFirst()) {
			c = serializeByCursor(cursor);
		}
		if (!cursor.isClosed()) {
			cursor.close();
		}
		return c;
	}
	
	/**
	 * M�todo para salvar um consumo di�rio
	 * @param Consumo di�rio
	 * @return Verdadeiro caso tenha sucesso e falso em caso de falha
	 */
	public boolean salvar(ConsumoDiario consumo) {
		ContentValues values = serializeContentValues(consumo);
		if (database.insert(tableName, null, values) > 0)
			return true;
		else
			return false;
	}
	
	private ContentValues serializeContentValues(ConsumoDiario consumo) {
		ContentValues values = new ContentValues();
		values.put("id_consumo", consumo.getIdConsumo());
		values.put("id_alimento", consumo.getAlimentoConsumido().getIdAlimento());
		values.put("id_usuario", consumo.getUsuario().getId());
		values.put("data_hora_consumo", UtilHelper.getDataHourToPersist(consumo.getDataHoraConsumo()));
		values.put("qtde_consumo", consumo.getQuantidadeEmPorcoes());
		return values;
	}

	/**
	 * M�todo para serializar um Consumo di�rio
	 * @param Cursor com dados do banco
	 * @return Retorna um objeto do tipo Consumo Di�rio
	 */
	private ConsumoDiario serializeByCursor(Cursor cursor) {
		// "id_alimento","id_grupo_alimento","alimento","descricao","caloria_porcao","figura","origem"
		ConsumoDiario c = new ConsumoDiario();
		c.setIdConsumo(cursor.getInt(0));

		AlimentoDAO daoA = new AlimentoDAO(context);
		Alimento a = daoA.getByID(cursor.getInt(1));
		a.setIdAlimento(cursor.getInt(1));
		c.setAlimentoConsumido(a);
		
		Usuario u = new Usuario();
		u.setId(cursor.getInt(2));
		c.setUsuario(u);
		try {
			c.setDataHoraConsumo(UtilHelper.getDataByStringDateHour(cursor.getString(3)));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Toast.makeText(context, "Erro ao converter data"+e.getMessage(), Toast.LENGTH_LONG).show();
		}
		c.setQuantidadeEmPorcoes(cursor.getFloat(4));

		return c;
	}
	
	/**
	 * Lista todos os consumos di�rios cadastrados
	 * @return Lista de consumo di�rio
	 */
	public List<ConsumoDiario> listAll() {
		List<ConsumoDiario> list = new ArrayList<ConsumoDiario>();
		this.openDataBase();
		Cursor cursor = executeSelect(null, null, "1");
		
		if(cursor!=null && cursor.moveToFirst())
		{
			do{
				list.add(serializeByCursor(cursor));
			}while(cursor.moveToNext());
		}
		
		if(!cursor.isClosed())
		{
			cursor.close();
		}
		
		return list;		
	}
	
	/**
	 * M�todo que recupera o consumo di�rio de um determinado per�odo
	 * @param Data de in�cio
	 * @param Data de fim
	 * @return Lista de consumos di�rios
	 */
	public List<DataCaloriaGrafico> getListConsumoByDateInicioAndDateFim( Calendar calIni, Calendar calFim ){
		
		Usuario u;
		u = UsuarioLogado.getUsuarioLogado();
		
		int codUsuario = 0;
		
    	if (u != null)
    	{
    		codUsuario = u.getId();
    	}
		
		List<DataCaloriaGrafico> list = null;
		
		this.openDataBase();
		
		String query = "SELECT cc.data_hora_consumo, SUM( ( a.caloria_porcao * cc.qtde_consumo ) ) AS totalDeCalorias "
		+ " FROM cadastro_consumo AS cc "
		+ " INNER JOIN alimento AS a ON cc.id_alimento = a.id_alimento "
		+ " WHERE cc.data_hora_consumo >= ? AND cc.data_hora_consumo <= ? "
		+ " GROUP BY cc.data_hora_consumo "
		+ " ORDER BY cc.data_hora_consumo ASC ";
		
		String[] values = { String.valueOf( UtilHelper.getDataToPersist( calIni ) ), String.valueOf( UtilHelper.getDataToPersist( calFim ) )  };
		
		Cursor cursor = database.rawQuery( query, values );
		
		if (cursor != null && cursor.moveToFirst()) {
			
			list = new ArrayList<DataCaloriaGrafico>();
			
			do
			{
				
				Date data;
				
				try {
					
					DataCaloriaGrafico dcg = new DataCaloriaGrafico();
					
					data = UtilHelper.getDataByStringDate( cursor.getString( 0 ) );
					
					dcg.setData( data );
					dcg.setQtdCaloria( Float.parseFloat( cursor.getString( 1 ) ) );
					
					list.add( dcg );
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				Log.d( "Logando", "Data: " + cursor.getString( 0 ) + " - Qtd: " + cursor.getString( 1 ) );
			}
			while(cursor.moveToNext());
			
		}
		
		if (!cursor.isClosed()) {
			cursor.close();
		}
		
		return list;
		
	}

	private Cursor executeSelect(String selection, String[] selectionArgs,
			String orderBy) {
		return database.query(tableName, campos, selection, selectionArgs,
				null, null, orderBy);

	}
	
	/**
	 * M�todo que exlui um consumo di�rio
	 * @param Valor inteiro
	 * @return Verdadeiro caso sucesso e falso em caso de falha
	 */
	public boolean deletar(Integer id) {
		if(database.delete(tableName, "id_consumo = ?", new String[]{String.valueOf(id)})>0)
			return true;
		else
			return false;
	}

}
