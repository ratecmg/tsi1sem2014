package classe;

/**
 * Defini��es para objetivo
 * @author Tiago
 *
 */
public enum Objetivo {
	PERDER_PESO(1),
	MANTER_PESO(2),
	GANHAR_PESO(3),
	NENHUM(4);
	
	private int id_objetivo;

	private Objetivo(int id_objetivo) {
		this.id_objetivo = id_objetivo;
	}

	/**
	 * Retorna o identificador do objetivo
	 * @return o id do objetivo
	 */
	public int getId() {
		return id_objetivo;
	}

	public static Objetivo valueOf(int id) {
        for (Objetivo o : Objetivo.values()) {
            if (o.getId() == id) {
                return o;
            }
        }
        return NENHUM;
    }

	
}
