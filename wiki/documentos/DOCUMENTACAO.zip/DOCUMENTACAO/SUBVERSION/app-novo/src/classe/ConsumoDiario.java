package classe;

import java.io.Serializable;
import java.util.Date;

public class ConsumoDiario implements Serializable{
	
	private Integer idConsumo;
	private Alimento alimentoConsumido;
	private Usuario usuario;
	private Float quantidadeEmPorcoes;
	private Date dataHoraConsumo;
	
	public Integer getIdConsumo() {
		return idConsumo;
	}
	public void setIdConsumo(Integer idConsumo) {
		this.idConsumo = idConsumo;
	}
	public Alimento getAlimentoConsumido() {
		return alimentoConsumido;
	}
	public void setAlimentoConsumido(Alimento alimentoConsumido) {
		this.alimentoConsumido = alimentoConsumido;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Float getQuantidadeEmPorcoes() {
		return quantidadeEmPorcoes;
	}
	public void setQuantidadeEmPorcoes(Float quantidadeEmPorcoes) {
		this.quantidadeEmPorcoes = quantidadeEmPorcoes;
	}
	public Date getDataHoraConsumo() {
		return dataHoraConsumo;
	}
	public void setDataHoraConsumo(Date dataHoraConsumo) {
		this.dataHoraConsumo = dataHoraConsumo;
	}
	
	
}
