/*
 * Equipe de Medidas
 * 
 */package classe;

/**
 * Defini��es de sexo para uma pessoa
 * @author Tiago Donizetti Gomes
 */
public enum Sexo {    
	/**
     * Sexo Masculino
     */
    MASCULINO('M'),
    /**
     * Sexo Feminino
     */
    FEMININO('F'),
    /**
     * Sexo indefinido
     */
    INDEFINIDO('I');
    
    private char codigo;

    private Sexo(char codigo) {
        this.codigo = codigo;
    }

    /**
     * Retorna o caracter representativo do sexo (M, F, ou I)
     * @return
     */
    public char getCode() {
        return codigo;
    }



    /**
     * Retorna o Sexo que representa o caracter
     * @param caracter Um caracter
     * @return Sexo
     */
    public static Sexo valueOf(char caracter) {
        for (Sexo sexo : Sexo.values()) {
            if (sexo.getCode() == Character.toUpperCase(caracter)) {
                return sexo;
            }
        }
        return INDEFINIDO;
    }


    @Override
    public String toString() {
        return String.valueOf(codigo);
    }
}

