package classe;

import java.io.Serializable;
import java.util.Date;

public class Alimento implements Serializable {

	private Integer idAlimento;
	private GrupoAlimento grupoAlimento;
	private String alimento;
	private String descricao;
	private String caloriaPorcao;
	private String figura;
	private String origem;
	private Date dataAtualizacao;

	public Integer getIdAlimento() {
		return idAlimento;
	}

	public void setIdAlimento(Integer idAlimento) {
		this.idAlimento = idAlimento;
	}

	public GrupoAlimento getGrupoAlimento() {
		return grupoAlimento;
	}

	public void setGrupoAlimento(GrupoAlimento grupoAlimento) {
		this.grupoAlimento = grupoAlimento;
	}

	public String getAlimento() {
		return alimento;
	}

	public void setAlimento(String alimento) {
		this.alimento = alimento;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getCaloriaPorcao() {
		return caloriaPorcao;
	}

	public void setCaloriaPorcao(String caloriaPorcao) {
		this.caloriaPorcao = caloriaPorcao;
	}

	public String getFigura() {
		return figura;
	}

	public void setFigura(String figura) {
		this.figura = figura;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}

	public Date getDataAtualizacao() {
		return dataAtualizacao;
	}

	public void setDataAtualizacao(Date dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}
}
