package classe;

import java.util.Date;

public class CadastroComplementar {

	
	
	private Integer id;
	private int id_usuario;
	private Double circunferencia;
	private Double quadril;
	private Double frequencia;
	private String pressao;
	private Date atualizacao;
	
	
	
	
	
	public String getPressao() {
		return pressao;
	}
	public void setPressao(String pressao) {
		this.pressao = pressao;
	}
	public int getId_usuario() {
		return id_usuario;
	}
	public void setId_usuario(int id_usuario) {
		this.id_usuario = id_usuario;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Double getCircunferencia() {
		return circunferencia;
	}
	public void setCircunferencia(Double circunferencia) {
		this.circunferencia = circunferencia;
	}
	public Double getQuadril() {
		return quadril;
	}
	public void setQuadril(Double quadril) {
		this.quadril = quadril;
	}
	public Double getFrequencia() {
		return frequencia;
	}
	public void setFrequencia(Double frequencia) {
		this.frequencia = frequencia;
	}
	
	public Date getAtualizacao() {
		return atualizacao;
	}
	public void setAtualizacao(Date atualizacao) {
		this.atualizacao = atualizacao;
	}
	
	
	
	
}
