package classe;

public final class UsuarioLogado {
	// Variavel est�tica que conter� a instancia do m�todo
    private static UsuarioLogado instance;
    private Usuario usuario;

    // Construtor privado. Suprime o construtor p�blico padrao.
    private UsuarioLogado(Usuario usuario) {
         this.setUsuario(usuario);
    }

    // M�todo p�blico est�tico de acesso �nico ao objeto!
    public static Usuario getUsuarioLogado(){
          // Verifica se a vari�vel possui algum valor,caso n�o, � criada a instancia.
          if (instance == null)
        	  return null;
          // Se a variavel possui algum valor, � retornado para quem est� pedindo
          return instance.getUsuario();
    }
    
    public static UsuarioLogado setUsuarioLogado(Usuario usuario){
        // Verifica se a vari�vel possui algum valor,caso n�o, � criada a instancia.
        instance = new UsuarioLogado(usuario);
        
        // Se a variavel possui algum valor, � retornado para quem est� pedindo
        return instance;
  }

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

}