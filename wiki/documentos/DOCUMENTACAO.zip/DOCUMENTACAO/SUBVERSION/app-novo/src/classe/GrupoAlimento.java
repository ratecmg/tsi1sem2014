package classe;

import java.io.Serializable;

public class GrupoAlimento implements Serializable{

	private Integer idGrupoAlimentos;
	private String grupoAlimento;
	private String descricao;
	
	public Integer getIdGrupoAlimentos() {
		return idGrupoAlimentos;
	}
	
	public void setIdGrupoAlimentos(Integer idGrupoAlimentos) {
		this.idGrupoAlimentos = idGrupoAlimentos;
	}
	
	public String getGrupoAlimento() {
		return grupoAlimento;
	}
	
	public void setGrupoAlimento(String grupoAlimento) {
		this.grupoAlimento = grupoAlimento;
	}
	
	public String getDescricao() {
		return descricao;
	}
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
}
