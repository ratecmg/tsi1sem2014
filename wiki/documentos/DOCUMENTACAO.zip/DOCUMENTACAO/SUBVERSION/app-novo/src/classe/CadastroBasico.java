package classe;

import java.text.DecimalFormat;
import java.util.Date;

public class CadastroBasico {
	
			private int id_medida;
			private int id_usuario;
			private float altura;
			private float peso;
			private Date data_atualizacao;
			
			public int getId_medida() {
				return id_medida;
			}
			public void setId_medida(int id_medida) {
				this.id_medida = id_medida;
			}
			public int getId_usuario() {
				return id_usuario;
			}
			public void setId_usuario(int id_usuario) {
				this.id_usuario = id_usuario;
			}
			public float getAltura() {
				
				String aux = Float.toString(altura);
				float alt = Float.valueOf(aux);//(String.format("%.2f%n", aux));
				//float alt = Float.valueOf(String.format("%.2f%n", aux));
				altura = alt;
				return altura;
			}
			public void setAltura(float altura) {
				this.altura = altura;
			}
			public float getPeso() {
				return peso;
			}
			public void setPeso(float peso) {
				this.peso = peso;
			}
			public Date getData_atualizacao() {
				return data_atualizacao;
			}
			public void setData_atualizacao(Date data_atualizacao) {
				this.data_atualizacao = data_atualizacao;
			}
}
