package classe;

import java.util.Date;

public class DataCaloriaGrafico {
	
	private Date data;
	private float qtdCaloria;
	
	public void setData( Date dt )
	{
		this.data = dt;
	}
	
	public void setQtdCaloria( float cal )
	{
		this.qtdCaloria = cal;
	}
	
	public Date getData()
	{
		return this.data;
	}
	
	public float getQtdCaloria()
	{
		return this.qtdCaloria;
	}
	
}
