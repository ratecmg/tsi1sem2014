/*
 * Equipe de Medidas
 * 
 */

package br.edu.ifsp.medidacerta.medida.models.rcq;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import classe.Objetivo;
import classe.Pessoa;
import classe.Sexo;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.R.color;
import br.edu.ifsp.medidacerta.enciclopedia.dao.DicaDAO;
import br.edu.ifsp.medidacerta.enciclopedia.models.Dica;
import br.edu.ifsp.medidacerta.medida.models.Medida;

/**
 * Classe para c�lculo de RCQ (rela��o cintura/quadril)
 * 
 * @author Tiago
 */
public class RCQ implements Medida, Serializable {

	public static final int ID_INDICE = 3;

	private Double valor;
	private Pessoa pessoa;

	/**
	 * Cria um novo c�lculo de RCQ (rela��o cintura/quadril) de uma pessoa
	 * 
	 * @param circunferenciaCintura
	 * @param circunferenciaQuadril
	 */
	public RCQ(double circunferenciaCintura, double circunferenciaQuadril,
			Sexo sexo, int idade) {
		this.pessoa = new Pessoa();
		this.pessoa.setCircunferenciaQuadril(circunferenciaQuadril);
		this.pessoa.setCircunferenciaCintura(circunferenciaCintura);
		this.pessoa.setSexo(sexo);
		// "Artif�cio t�cnico" para setar a idade da pessoa:
		Date dataNascimento = new Date();
		dataNascimento.setYear(dataNascimento.getYear() - idade);
		this.pessoa.setDataNascimento(dataNascimento);
		
		if (pessoa.getCircunferenciaCintura() == null
				|| pessoa.getCircunferenciaQuadril() == null) {
			throw new UnsupportedOperationException(
					"Voc� precisa cadastrar suas medidas de cintura e quadril para efetuar o c�lculo do RCQ");
		}		
		recalcular();
	}

	/**
	 * Cria um novo c�lculo de RCQ (rela��o cintura/quadril) com valores de
	 * peso, altura, sexo e idade de uma pessoa
	 * 
	 * @param pessoa
	 * @throws Exception
	 */
	public RCQ(Pessoa pessoa) throws Exception {
		if (pessoa == null) {
			throw new UnsupportedOperationException("Usu�rio n�o definido");
		}
		this.pessoa = pessoa;
		if (pessoa.getCircunferenciaCintura() == null
				|| pessoa.getCircunferenciaQuadril() == null) {
			throw new UnsupportedOperationException(
					"Voc� precisa cadastrar suas medidas de cintura e quadril para efetuar o c�lculo do RCQ");
		}
		recalcular();
	}

	/**
	 * M�todo que � invocado quando � preciso atualizar o valor do RCQ
	 * 
	 * @author Kelvin
	 */
	private void recalcular() {
		valor = pessoa.getCircunferenciaCintura()
				/ pessoa.getCircunferenciaQuadril();
	}

	@Override
	public double getValor() {
		recalcular();
		return valor;
	}

	@Override
	public String toString() {
		return "" + valor;
	}


	public Classificacao getClassificacao() {
		return Classificacao.getClassificacao(this.pessoa, this);
	}
	public String getDicas() {
		DicaDAO dao = new DicaDAO();
		StringBuilder dica = new StringBuilder();
		dica.append("N�o h� dicas dispon�veis.");
		List<Dica> dicas;
		try {
			dicas = dao.listPorClassificacao(this.getClassificacao().getObjetivo().getId(), this.getClassificacao().getId());
			if (dicas.size()>0) dica = new StringBuilder();
			for (Dica d : dicas){
				dica.append(d.getDica() +  "\n\n");
			}			
		} catch (Exception e) {
			dica.append("N�o h� dicas dispon�veis. Verifique se h� conex�o com a Internet.");
		}
		return dica.toString();
	}
    
	public static enum Classificacao {
		RISCO_BAIXO(4, Objetivo.MANTER_PESO, 
				0.83, 0.84, 0.88, 0.90, 0.91, 0.71, 0.72, 0.73, 0.74, 0.76, 
				R.string.m_classificacao_risco_baixo,
				color.SAUDAVEL), 
		RISCO_MODERADO(5, Objetivo.PERDER_PESO,
				0.88, 0.91, 0.95, 0.96, 0.98, 0.77, 0.78, 0.79, 0.81, 0.83, 
				R.string.m_classificacao_risco_medio,
				color.OBESIDADE), 
		RISCO_ALTO(6, Objetivo.PERDER_PESO,
				0.94, 0.96, 1.00, 1.02, 1.03, 0.82, 0.84, 0.87, 0.88, 0.90, 
				R.string.m_classificacao_risco_alto,
				color.OBESIDADE_SEVERA), 
		RISCO_MUITO_ALTO(7, Objetivo.PERDER_PESO,
				9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 9999, 
				R.string.m_classificacao_risco_alto,
				color.OBESIDADE_MORBIDA), 
		SEM_CLASSIFICACAO(0,Objetivo.NENHUM,
				10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 100000,
				R.string.m_classificacao_sem_classificacao,
				color.white
				);
		private int id;
		private int stringId;
		private int colorId;
		private Objetivo objetivo;
		private Double masculinoMin20_29M;
		private Double masculinoMin30_39M;
		private Double masculinoMin40_49M;
		private Double masculinoMin50_59M;
		private Double masculinoMin60_69M;

		private Double femininoMin20_29M;
		private Double femininoMin30_39M;
		private Double femininoMin40_49M;
		private Double femininoMin50_59M;
		private Double femininoMin60_69M;
		
		public int getColorId() {
			return colorId;
		}

		public Objetivo getObjetivo() {
			return objetivo;
		}


		public int getId() {
			return id;
		}


		private Classificacao(int id, Objetivo objetivo,
			double masculinoMin20_29M,
			double masculinoMin30_39M, double masculinoMin40_49M,
			double masculinoMin50_59M, double masculinoMin60_69M,
			double femininoMin20_29M, double femininoMin30_39M,
			double femininoMin40_49M, double femininoMin50_59M,
			double femininoMin60_69M,
			int stringId,
			int colorId) {
				this.id = id;
				this.objetivo = objetivo;
				this.masculinoMin20_29M = masculinoMin20_29M;
				this.masculinoMin30_39M = masculinoMin30_39M;
				this.masculinoMin40_49M = masculinoMin40_49M;
				this.masculinoMin50_59M = masculinoMin50_59M;
				this.masculinoMin60_69M = masculinoMin60_69M;
				this.femininoMin20_29M = femininoMin20_29M;
				this.femininoMin30_39M = femininoMin30_39M;
				this.femininoMin40_49M = femininoMin40_49M;
				this.femininoMin50_59M = femininoMin50_59M;
				this.femininoMin60_69M = femininoMin60_69M;
				this.stringId = stringId;
				this.colorId = colorId;
		}

		public static Classificacao getClassificacao(Pessoa p, RCQ rcq) {
			Classificacao res = Classificacao.SEM_CLASSIFICACAO;
			// System.out.println(rcq.getValor());

			for (Classificacao c : values()) {

				if (p.getSexo() == Sexo.MASCULINO) {
					//System.out.println(c);
					if (p.getIdade() >= 20 && p.getIdade() <= 29) {
						if (rcq.getValor() < c.masculinoMin20_29M) {
							return c;
						}
					}
					if (p.getIdade() >= 30 && p.getIdade() <= 39) {
						if (rcq.getValor() < c.masculinoMin30_39M) {
							return c;
						}
					}
					if (p.getIdade() >= 40 && p.getIdade() <= 49) {
						if (rcq.getValor() < c.masculinoMin40_49M) {
							return c;
						}
					}
					if (p.getIdade() >= 50 && p.getIdade() <= 59) {
						if (rcq.getValor() < c.masculinoMin50_59M) {
							return c;
						}
					}
					if (p.getIdade() >= 60 && p.getIdade() <= 69) {
						if (rcq.getValor() < c.masculinoMin60_69M) {
							return c;
						}
					}
				} else if (p.getSexo() == Sexo.FEMININO) {
					if (p.getIdade() >= 20 && p.getIdade() <= 29) {
						if (rcq.getValor() < c.femininoMin20_29M) {
							return c;
						}
					}
					if (p.getIdade() >= 30 && p.getIdade() <= 39) {
						if (rcq.getValor() < c.femininoMin30_39M) {
							return c;
						}
					}
					if (p.getIdade() >= 40 && p.getIdade() <= 49) {
						if (rcq.getValor() < c.femininoMin40_49M) {
							return c;
						}
					}
					if (p.getIdade() >= 50 && p.getIdade() <= 59) {
						if (rcq.getValor() < c.femininoMin50_59M) {
							return c;
						}
					}
					if (p.getIdade() >= 60 && p.getIdade() <= 69) {
						if (rcq.getValor() < c.femininoMin60_69M) {
							return c;
						}
					}
				}
			}
			return res;
		}

		public int getStringId() {
			// TODO Auto-generated method stub
			return stringId;
		}

	}



}
