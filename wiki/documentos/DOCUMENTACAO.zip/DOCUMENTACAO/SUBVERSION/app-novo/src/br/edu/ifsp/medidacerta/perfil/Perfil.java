package br.edu.ifsp.medidacerta.perfil;


public class Perfil {
    

}
