package br.edu.ifsp.medidacerta.enciclopedia.activity;

import java.util.ArrayList;
import java.util.List;


import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.R.layout;
import br.edu.ifsp.medidacerta.R.menu;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class EncQuestionarioActivity extends Activity {

	private TextView txtPergunta;
	private Button btnAvancar;
	private Button btnVoltar;
	private Integer numeroPergunta;
	private Integer resultadoQuestionario=0;
	private RadioGroup rgRespostas;
	private RadioButton r1;
	private RadioButton r2;
	private RadioButton r3;
	
	ArrayList<String> perguntas = new ArrayList<String> ();
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_enc_quest);
		
				
		txtPergunta = (TextView) findViewById(R.id.p04_tvpergunta);
		btnAvancar = (Button) findViewById(R.id.btnAvancarPergunta);
		btnVoltar = (Button) findViewById(R.id.btn_voltar);
		rgRespostas = (RadioGroup) findViewById(R.id.rgRespostas);
		r1 = (RadioButton) findViewById(R.id.rb1);
		r2 = (RadioButton) findViewById(R.id.rb2);
		r3 = (RadioButton) findViewById(R.id.rb3);
				
        
        perguntas.add("1. Quantos copos de �gua voc� consome por dia?\n\n"+
						"a) Tr�s ou menos.\n\n"+
						"b) Entre quatro e seis.\n\n"+
						"c) Mais de seis.");   
        
        perguntas.add("2. O que voc� costuma tomar durante as refei��es?\n\n"+
						"a) Refrigerante.\n\n"+
						"b) Suco.\n\n"+
						"c) �gua ou nada.\n\n");  
        
        perguntas.add("3. Voc� tem o h�bito de tomar caf� ou ch� depois das refei��es?\n\n"+
						"a) Todos os dias.\n\n"+
						"b) �s vezes.\n\n"+
						"c) Nunca."); 
        
        perguntas.add("4. Quantas vezes por semana voc� consome frituras?\n\n"+
						"a) Todos os dias.\n\n"+
						"b) Uma vez por semana.\n\n"+
						"c) Raramente.");         
        		
        perguntas.add("5. Quantas refei��es voc� faz por dia?\n\n"+
						"a) Uma ou duas.\n\n"+
						"b) Tr�s ou quatro.\n\n"+
						"c) Cinco ou mais.");       
        
        perguntas.add("6. Quantas frutas voc� consome por dia?\n\n"+
						"a) Zero a duas.\n\n"+
						"b) Tr�s a quatro.\n\n"+
						"c) Cinco ou mais.");  
        
        perguntas.add("7. Quantas por��es de leite voc� consome por dia?\n\n"+
						"a) Uma ou nenhuma.\n\n"+
						"b) Mais de cinco.\n\n"+
						"c) Duas a tr�s.");    
        
        perguntas.add("8. Quantas cores diferentes de salada voc� consome por dia?\n\n"+
						"a) Duas ou nenhuma.\n\n"+
						"b) Tr�s.\n\n"+
						"c) Quatro ou mais.");    
        
        perguntas.add("9. Voc� consome peixe com que frequ�ncia?\n\n"+
						"a) Uma vez por m�s ou menos.\n\n"+
						"b) Mais de uma vez por m�s.\n\n"+
						"c) Uma vez por semana ou mais."); 
        
        perguntas.add("10. Quantas vezes voc� come doce por dia?\n\n"+
						"a) Tr�s ou mais.\n\n"+
						"b) Uma ou duas.\n\n"+
						"c) Nenhuma ou uma."); 
        
        perguntas.add("11. Quantos caf�s voc� toma por dia?\n\n"+
						"a) Tr�s ou mais.\n\n"+
						"b) Uma ou dois.\n\n"+
						"c) Nenhum."); 
        
        perguntas.add("12. Quais desses pratos voc� escolheria para o seu almo�o?\n\n"+
						"a) Pizza.\n\n"+
						"b) Arroz, bife grelhado e batata frita.\n\n"+
						"c) Salada de alface e cenoura, bife de frango e arroz.");  
        
        perguntas.add("13. Voc� costuma ler o r�tulo dos alimentos?\n\n"+
						"a) Nunca.\n\n"+
						"b) �s vezes.\n\n"+
						"c) Com frequ�ncia.");  
        
        perguntas.add("14. Com que frequ�ncia voc� consome frutas oleaginosas (castanhas, nozes, am�ndoas)?\n\n"+
						"a) Nunca.\n\n"+
						"b) �s vezes.\n\n"+
						"c) Com frequ�ncia.");   
        
        perguntas.add("15. Com que frequ�ncia voc� consome farinha branca?\n\n"+
						"a) Todos os dias.\n\n"+
						"b) �s vezes.\n\n"+
						"c) Eventualmente ou nunca.");        
		                                  
     
     numeroPergunta = 0;   
     txtPergunta.setText(perguntas.get(numeroPergunta));                
        
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//getMenuInflater().inflate(R.menu.activity_enc_quest, menu);
		return true;
	}
	
	
	public void avancarquestao (View v){
					
						
		if (numeroPergunta <= 14){
						
									
			if(r1.isChecked() == true){
								
				resultadoQuestionario = resultadoQuestionario + 3;				
				numeroPergunta++;
				
			}
			else if(r2.isChecked() == true){
				
				resultadoQuestionario = resultadoQuestionario + 2;				
				numeroPergunta++;

			}			
			else if(r3.isChecked() == true){
				
				resultadoQuestionario++;				
				numeroPergunta++;
				
			}
			else{
				
				Toast.makeText(getApplicationContext(), "Selecione uma resposta antes de avan�ar!", Toast.LENGTH_SHORT).show();				
			}			
			
			
			if (numeroPergunta <= 14){
			
				txtPergunta.setText(perguntas.get(numeroPergunta));				
				
			}else{
				avancarquestao(v);
			}
						
		}
		else{
			
						
			if(resultadoQuestionario <= 20){
								
				txtPergunta.setText("PARAB�NS!\n\n\n Voc� se alimenta muito bem!\n\n Mantenha sempre o mesmo ritmo, o que lhe assegurar� uma vida mais saud�vel.");
				
			}
			else if(resultadoQuestionario > 20 && resultadoQuestionario <=30){
				
				txtPergunta.setText("ATEN��O!\n\n\n Sua alimenta��o est� razo�vel e pode melhorar.\n\n Analise os pontos negativos e mude-os.");
				
			}
			else{
				
				txtPergunta.setText("CUIDADO!\n\n\n Sua alimenta��o n�o est� adequada.\n\n Est�o faltando nutrientes essenciais, como vitaminas e minerais.\n\n Lembre-se que uma alimenta��o equilibrada reflete em bem-estar e qualidade de vida.\n\n Mude seus h�bitos alimentares.");
				
			}
			
			InativarComponentes();			
			
		};
		
					
	};
	
	public void InativarComponentes() {
		
		r1.setVisibility(View.GONE);
		r2.setVisibility(View.GONE);
		r3.setVisibility(View.GONE);
		btnAvancar.setVisibility(View.GONE);
		btnVoltar.setText("Voltar");
		
	}	
	
	public void InativarOpcoesRadio() {
					
		r1.setChecked(false);
		r2.setChecked(false);
		r3.setChecked(false);
				
	}	
		
	public void voltar(View v){
    	Intent intent_main = new Intent(this, EncMainActivity.class);
		startActivity(intent_main);
	}	

}
