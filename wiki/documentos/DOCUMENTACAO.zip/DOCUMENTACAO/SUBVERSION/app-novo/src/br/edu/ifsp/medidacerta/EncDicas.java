package br.edu.ifsp.medidacerta;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class EncDicas extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.enc_dicas);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.enc_dicas, menu);
		return true;
	}

}
