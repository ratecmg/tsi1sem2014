package br.edu.ifsp.medidacerta.shared.chart;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.chart.BarChart.Type;
import org.achartengine.model.CategorySeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import br.edu.ifsp.medidacerta.UtilHelper;
import classe.DataCaloriaGrafico;
import dao.ConsumoDAO;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;

public class BarGraph {
	
	XYMultipleSeriesRenderer sRenderer = new XYMultipleSeriesRenderer();
	
	public Calendar dataInicio;
	public Calendar dataFim;
	
	public Intent getIntent( Context context )
	{
		
		ConsumoDAO cdao = new ConsumoDAO( context );
		
		List<DataCaloriaGrafico> listConsumo;
		
		listConsumo = cdao.getListConsumoByDateInicioAndDateFim( dataInicio, dataFim );
		
		if ( listConsumo != null )
		{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM");
			
			CategorySeries series = new CategorySeries( "Gr�fico de consumo di�rio" );
			
			int size = listConsumo.size() - 1;
			int count = 1;
			
			for ( int i = 0; i < listConsumo.size(); i++ )
			{
				DataCaloriaGrafico dcg = listConsumo.get( i );
				
				Date dataTemp;
				
				if ( i != size )
				{
					
					DataCaloriaGrafico dcgTemp = listConsumo.get( i + 1 );
					
					series.add( dcg.getQtdCaloria() );
					
					sRenderer.addXTextLabel( count, sdf.format( dcg.getData() ) );
					
					count++;
					
					dataTemp = UtilHelper.addDay( dcg.getData(), 1 );
					
					while( !dcgTemp.getData().equals( dataTemp ) )
					{
						
						series.add( dcg.getQtdCaloria() );
						
						sRenderer.addXTextLabel( count, sdf.format( dataTemp ) );
						
						count++;
						
						dataTemp = UtilHelper.addDay( dataTemp, 1 );
						
					}
					
				}
				else
				{
					series.add( dcg.getQtdCaloria() );
					
					sRenderer.addXTextLabel( count, sdf.format( dcg.getData() ) );
					
				}
				
			}
			
			XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
			dataset.addSeries( series.toXYSeries() );
			
			XYSeriesRenderer renderer = new XYSeriesRenderer();
			renderer.setDisplayChartValues( true );
			renderer.setChartValuesSpacing( (float) 2.5 );
			renderer.setColor( Color.WHITE );
			
			sRenderer.setChartTitle( "Gr�fico de consumo di�rio" );
			sRenderer.setBackgroundColor( Color.BLACK );
			sRenderer.setApplyBackgroundColor( true );
			sRenderer.setXTitle( "Dias" );
			sRenderer.setYTitle( "Calorias consumidas por dia" );
			sRenderer.setBarSpacing( (double) 0.5 );
			sRenderer.setShowGrid( true );
			sRenderer.addSeriesRenderer( renderer );
			
			sRenderer.setXLabels(0);
			
			Intent intent = ChartFactory.getBarChartIntent( context, dataset, sRenderer, Type.DEFAULT);
			
			return intent;
		}
		else
		{
			
			return null;
			
		}
		
	}
	
}
