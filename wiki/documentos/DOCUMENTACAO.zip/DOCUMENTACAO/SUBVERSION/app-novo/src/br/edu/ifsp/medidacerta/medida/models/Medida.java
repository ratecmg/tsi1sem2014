/*
 * Equipe de Medidas
 * 
 */
package br.edu.ifsp.medidacerta.medida.models;

/**
 * Interface para medidas
 * @author Tiago
 */
public interface Medida {
     /**
     * M�todo para obter o valor num�rico da medida
     * @return O valor da medida
     */
    public double getValor();
    
    
    @Override
    public String toString();
}
