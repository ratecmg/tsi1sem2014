package br.edu.ifsp.medidacerta.enciclopedia.ws;

import java.util.ArrayList;
import java.util.List;

import br.edu.ifsp.medidacerta.enciclopedia.models.Dica;
import br.edu.ifsp.medidacerta.enciclopedia.ws.WebServiceCliente;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;

public class DicaREST {

    private StringBuilder URL_WS = new StringBuilder("http://10.0.0.102:8080/MedidaCertaEnciclopediaWS/");

    public DicaREST(String url)
    {
    	this.URL_WS.append("dica/");    	
    }
	
    public List<Dica> getListaDicas() throws Exception {

        String[] resposta = new WebServiceCliente().get(URL_WS.toString()+"buscarTodosGSON");
        
        if (resposta[0].equals("200")) {
            Gson gson = new Gson();
            ArrayList<Dica> listaDica = new ArrayList<Dica>();
            JsonParser parser = new JsonParser();
           JsonArray array = parser.parse(resposta[1]).getAsJsonArray();
            
           for (int i = 0; i < array.size(); i++) {
           	listaDica.add(gson.fromJson(array.get(i), Dica.class));
            }
            return listaDica;
        } else {
            throw new Exception(resposta[1]);
        }
       }
    
    public List<Dica> getListaDicas(int id_objetivo) throws Exception {

        
        String[] resposta = new WebServiceCliente().get(URL_WS.toString()+id_objetivo);
        
        if (resposta[0].equals("200")) {
            Gson gson = new Gson();
            ArrayList<Dica> listaDica = new ArrayList<Dica>();
            JsonParser parser = new JsonParser();
           JsonArray array = parser.parse(resposta[1]).getAsJsonArray();
            
           for (int i = 0; i < array.size(); i++) {
           	listaDica.add(gson.fromJson(array.get(i), Dica.class));
            }
            return listaDica;
        } else {
            throw new Exception(resposta[1]);
        }
       }

    public List<Dica> getListaDicasAtividades(int id_objetivo) throws Exception {

        
        String[] resposta = new WebServiceCliente().get(URL_WS.toString()+"buscarDicasAtividadesFisicas/"+id_objetivo);
        
        if (resposta[0].equals("200")) {
            Gson gson = new Gson();
            ArrayList<Dica> listaDica = new ArrayList<Dica>();
            JsonParser parser = new JsonParser();
           JsonArray array = parser.parse(resposta[1]).getAsJsonArray();
            
           for (int i = 0; i < array.size(); i++) {
           	listaDica.add(gson.fromJson(array.get(i), Dica.class));
            }
            return listaDica;
        } else {
            throw new Exception(resposta[1]);
        }
       }

    public List<Dica> getListaDicasNutricionais(int id_objetivo) throws Exception {

    
    String[] resposta = new WebServiceCliente().get(URL_WS.toString()+"buscarDicasNutricionais/"+id_objetivo);
    
    if (resposta[0].equals("200")) {
        Gson gson = new Gson();
        ArrayList<Dica> listaDica = new ArrayList<Dica>();
        JsonParser parser = new JsonParser();
       JsonArray array = parser.parse(resposta[1]).getAsJsonArray();
        
       for (int i = 0; i < array.size(); i++) {
       	listaDica.add(gson.fromJson(array.get(i), Dica.class));
        }
        return listaDica;
    } else {
        throw new Exception(resposta[1]);
    }
   }

    public List<Dica> getListaDicasPorClassificacao(int id_objetivo, int id_classificacao) throws Exception {

    
    String[] resposta = new WebServiceCliente().get(URL_WS.toString()+"buscarDicasPorClassificacao/"+id_objetivo+"/"+id_classificacao);
    
    if (resposta[0].equals("200")) {
        Gson gson = new Gson();
        ArrayList<Dica> listaDica = new ArrayList<Dica>();
        JsonParser parser = new JsonParser();
       JsonArray array = parser.parse(resposta[1]).getAsJsonArray();
        
       for (int i = 0; i < array.size(); i++) {
       	listaDica.add(gson.fromJson(array.get(i), Dica.class));
        }
        return listaDica;
    } else {
        throw new Exception(resposta[1]);
    }
   }

    
}
