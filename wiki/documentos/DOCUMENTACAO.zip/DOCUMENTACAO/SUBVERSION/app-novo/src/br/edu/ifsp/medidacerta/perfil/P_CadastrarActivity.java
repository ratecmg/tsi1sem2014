package br.edu.ifsp.medidacerta.perfil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.edu.ifsp.medidacerta.R;

import classe.Usuario;
import classe.UsuarioLogado;
import dao.UsuarioDAO;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;

public class P_CadastrarActivity extends Activity {

	private Usuario usuario;
	private UsuarioDAO usuarioDAO;
	private List<Usuario> usuarios;
	private EditText nome;
	private EditText email;
	private EditText id;
	private RadioGroup sexo;
	private EditText dataNascimento;
	private EditText senha;
	private EditText confirmacaoSenha;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.p_cadastro);
		
		id = (EditText) findViewById(R.id.IdEditText);
		nome = (EditText) findViewById(R.id.NomeEditText);
		email = (EditText) findViewById(R.id.EmailEditText);
		sexo = (RadioGroup) findViewById(R.id.radioGroup1);
		dataNascimento = (EditText) findViewById(R.id.DataNascimentoEditText);
		senha = (EditText) findViewById(R.id.SenhaEditText);
		confirmacaoSenha = (EditText) findViewById(R.id.ConfirmacaoSenhaEditText);
		
		id.setVisibility(View.INVISIBLE);
		
		//Se o usu�rio j� tiver logado ent�o faz a atualiza��o
		Usuario usuarioLogado = UsuarioLogado.getUsuarioLogado();
		if (usuarioLogado != null)
		{
			preencherDados(usuarioLogado);
			email.setEnabled(false);
		}
		else
			email.setEnabled(true);
		
		usuarios = new ArrayList<Usuario>();
		usuarioDAO = new UsuarioDAO(getApplicationContext());		
		atualizarLista();
	}	
	
	private void preencherDados(Usuario usuario) {
		id.setText(usuario.getId().toString());
		nome.setText(usuario.getNome());
		email.setText(usuario.getEmail());
		if (usuario.getSexo().equals("F"))
			sexo.check(R.id.SexoRadioButton0);
		else
			sexo.check(R.id.SexoRadioButton1);
		
		SimpleDateFormat formatar = new SimpleDateFormat("dd/MM/yyyy");
		dataNascimento.setText(formatar.format(usuario.getDataNascimento()));
		senha.setText(usuario.getSenha());
		confirmacaoSenha.setText(usuario.getSenha());
	}
	
	
	public void salvar(View v) {
		String msgErro = "";
		usuario = new Usuario();
		
		//Caso seja edi��o, recupera todo o usu�rio
		if (!id.getText().toString().equalsIgnoreCase(""))
		{
			usuario = usuarioDAO.getByID(Integer.valueOf(id.getText().toString()));
		}
		
		usuario.setNome(nome.getText().toString());
		
		if(usuario.getNome().equalsIgnoreCase(""))
			msgErro = msgErro + "O nome deve ser informado.\n";
		
		usuario.setEmail(email.getText().toString());
		if(usuario.getEmail().equalsIgnoreCase(""))
			msgErro = msgErro + "O e-mail deve ser informado.\n";
		else
		//Verifica se o e-mail j� est� cadastrado no sistema caso seja um novo cadastro
		{
			if (usuarioDAO.existeByEmail(usuario.getEmail()) && id.getText().toString().equalsIgnoreCase(""))
				msgErro = msgErro + "O e-mail informado j� est� cadastrado.\n";
			else if (!isEmailValid(usuario.getEmail()))
				msgErro = msgErro + "O e-mail informado � inv�lido.\n";
		}
		
		int selecionado = sexo.getCheckedRadioButtonId();		
		RadioButton b = (RadioButton) findViewById(selecionado);
		
		if (b.getText().toString().toLowerCase().equals("feminino"))
			usuario.setSexo("F");
		else
			usuario.setSexo("M");
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		dateFormat.setLenient(false);
		String dataNasc = dataNascimento.getText().toString();
		Date dt = new Date();
		try {
			/*if (!validarData(dataNascimento.getText().toString()))
				msgErro = msgErro + "A data informada � inv�lida.\n";*/
			dt = dateFormat.parse(dataNasc);
		} catch (ParseException e) {
			msgErro = msgErro + "A data informada � inv�lida.\n";
		}
		
		usuario.setDataNascimento(dt);
		usuario.setSenha(senha.getText().toString());
		
		if (senha.getText().toString().equalsIgnoreCase(""))
			msgErro = msgErro + "A senha deve ser informada.\n";
		else
			if (!senha.getText().toString().equalsIgnoreCase(confirmacaoSenha.getText().toString()))
				msgErro = msgErro + "A senha e a confirma��o s�o diferentes.\n";
		//Caso n�o tenha o id faz um inclus�o
		if (msgErro.equalsIgnoreCase(""))
		{
			if (id.getText().toString().equalsIgnoreCase(""))
			{
				usuarioDAO.salvar(usuario);				
				UsuarioLogado.setUsuarioLogado(usuarioDAO.getByLoginSenha(usuario.getEmail(), usuario.getSenha()));
				Intent it = new Intent(getApplicationContext(), P_CadastroBasico.class);
				startActivity(it);				
			}
			else
			{
				usuario.setId(Integer.valueOf(id.getText().toString()));
				usuarioDAO.atualizar(usuario);
				UsuarioLogado.setUsuarioLogado(usuario);
				Intent it = new Intent(getApplicationContext(), P_ConsultarDados.class);
				startActivity(it);	
			}
			atualizarLista();
			limparDados();
		}
		else
		{
			exibirMensagem(msgErro);
		}
	}
	
	public void limpar(View v) {	
		limparDados();
	}

	private void limparDados() {
		id.setText("");
		nome.setText("");
		email.setText("");
		sexo.check(R.id.SexoRadioButton1);
		dataNascimento.setText("");
		senha.setText("");
		confirmacaoSenha.setText("");
		nome.requestFocus();
	}
	

	private void atualizarLista() {
		usuarios = usuarioDAO.listAll();
	}
	
	private void exibirMensagem(String msg) {
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}	
		
	
	public boolean isEmailValid(String email)
    {
         String regExpn =
             "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                 +"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                   +"[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                   +"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                   +"[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                   +"([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";

     CharSequence inputStr = email;

     Pattern pattern = Pattern.compile(regExpn,Pattern.CASE_INSENSITIVE);
     Matcher matcher = pattern.matcher(inputStr);

     if(matcher.matches())
        return true;
     else
        return false;
    }
}