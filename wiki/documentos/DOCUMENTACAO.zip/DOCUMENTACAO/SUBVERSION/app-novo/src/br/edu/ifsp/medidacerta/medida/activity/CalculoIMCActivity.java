package br.edu.ifsp.medidacerta.medida.activity;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.enciclopedia.dao.DicaDAO;
import br.edu.ifsp.medidacerta.enciclopedia.models.Dica;
import br.edu.ifsp.medidacerta.medida.models.imc.IMC;

public class CalculoIMCActivity extends Activity {

	private TextView lblValorIMC;
	private TextView lblValorMin;
	private TextView lblValorMax;
	private TextView lblValorClassificacao;
	private TextView lblDicasAtiv;
	private FrameLayout frameLayoutImg;
	private ImageView image;
	DicaDAO dica_dao = new DicaDAO();
	List<Dica> listAll = new ArrayList<Dica>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_m_calculo_imc);
		lblValorIMC = (TextView) findViewById(R.id.m_activity_calculo_imc_valor_imc);
		lblValorClassificacao = (TextView) findViewById(R.id.m_activity_calculo_imc_valor_classificacao);
		lblValorMin = (TextView) findViewById(R.id.m_activity_calculo_imc_valor_ideal_min);
		lblValorMax = (TextView) findViewById(R.id.m_activity_calculo_imc_valor_ideal_max);
		lblDicasAtiv = (TextView) findViewById(R.id.m_activity_calculo_imc_dicas);

		frameLayoutImg = (FrameLayout) findViewById(R.id.m_activity_calculo_imc_frame_layout_img);
		image = (ImageView) findViewById(R.id.imageView2);

		IMC imc = (IMC) getIntent().getSerializableExtra("imc");
		showIMC(imc);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return true;
	}

	private void updateDicaHandler(Message msg) {
		lblDicasAtiv.setText((CharSequence) msg.obj);
	}

	public void showIMC(final IMC imc) {
		
		
		
		lblDicasAtiv.setText(getString(R.string.m_carregando_dicas));

		try {
			/**
			 *  ***********************************************************
			 *    Thread para carregamento das dicas
			 *  ***********************************************************
			 */
			final Handler dicaHandler = new Handler() {
				@Override
				public void handleMessage(android.os.Message msg) {
					updateDicaHandler(msg);
				}

			};
			Runnable r = new Runnable() {
				@Override
				public void run() {
					try {
						Message msg = new Message();
						msg.obj = imc.getDicas();						
						dicaHandler.sendMessage(msg);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			};
			new Thread(r).start();
			// **************************************************************
			
			
			DecimalFormat fmt = new DecimalFormat("0.0");
			DecimalFormat fmtPeso = new DecimalFormat("0.00");
			lblValorIMC.setText(String.valueOf(fmt.format(imc.getValor())));
			lblValorMin.setText(String.valueOf(fmtPeso.format(imc
					.getMinPesoIdeal())) + " kg");
			lblValorMax.setText(String.valueOf(fmtPeso.format(imc
					.getMaxPesoIdeal())) + " kg");
			lblValorClassificacao.setText(getString(
					imc.getClassificacao().getStringId()).toUpperCase());

			lblValorIMC.setBackgroundColor(imc.getClassificacao().getColorId());
			frameLayoutImg.setBackgroundColor(imc.getClassificacao()
					.getColorId());
			image.setBackgroundDrawable(getResources().getDrawable(
					imc.getImageDrawable()));

		} catch (Exception ex) {

		}

	}
}
