package br.edu.ifsp.medidacerta.medida.activity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import classe.Pessoa;
import classe.UsuarioLogado;
import android.os.Bundle;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.medida.models.imc.IMC;

public class VisualizarTabela extends Activity {
	private Button bDataInicial;
	private Button bDataFinal;
	private DateFormat formataData;
	private DateFormat formataData_final;
	private static final int DATE_ = 0;
	private static final int DATE_F = 1;
	private Calendar dataInicial;
	private Calendar dataFinal;
	private TextView tabela_a_gerar;
	private TableLayout tabela_peso;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_m_visualizar_tabela);
		formataData = new SimpleDateFormat("dd/MM/yyyy");
		formataData_final = new SimpleDateFormat("dd/MM/yyyy");
		bDataInicial = (Button) findViewById(R.id.m_tabelapeso_btn_data_inicial);
		bDataFinal = (Button) findViewById(R.id.m_tabelapeso_btn_data_final);
		// tabela_a_gerar = (TextView) findViewById(R.id.tabela_gerada);
		tabela_peso = (TableLayout) findViewById(R.id.m_tabela_peso);
		InicializaCalendario();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		// getMenuInflater().inflate(R.menu.visualizar_tabela, menu);
		return true;
	}

	/**
	 * Inicializa o calendario com a data e hora atual
	 */
	private void InicializaCalendario() {
		dataInicial = Calendar.getInstance();
		dataInicial.set(Calendar.HOUR_OF_DAY, 0);
		dataInicial.set(Calendar.MINUTE, 0);
		
		
		dataFinal = Calendar.getInstance();
		dataFinal.set(Calendar.HOUR_OF_DAY, 23);
		dataFinal.set(Calendar.MINUTE, 59);
		
		AtualizaBtnDataInicial();
		AtualizaBtnDataFinal();
	}

	private void AtualizaBtnDataInicial() {
		bDataInicial.setText(formataData.format(dataInicial.getTime()));
	}

	private void AtualizaBtnDataFinal() {
		bDataFinal.setText(formataData_final.format(dataFinal.getTime()));

	}

	public void definirDataInicial(View v) {
		showDialog(DATE_);
		//System.out.println("inicial: " + DATE_);
	}

	public void definirDataFinal(View v) {
		showDialog(DATE_F);
		//System.out.println("final: " + DATE_F);
	}

	public void gerarTabela(View v) {
		Date agora = new Date();
	
		long tempoAtual = new Date(System.currentTimeMillis()).getTime();
		
		System.out.println("Data inicial: " + new Date(dataInicial.getTimeInMillis()) + dataInicial.getTime().getTime());
		System.out.println("Data final  : " + new Date(dataFinal.getTimeInMillis()) + dataFinal.getTime().getTime());
		System.out.println("Agora       : " + agora);
		
		
		if (dataInicial.after(dataFinal)) {
			Toast.makeText(this,"A data inicial deve ser anterior a data final!",
					Toast.LENGTH_LONG).show();
		/*} else if (dataFinal.getTime().getTime() > agora.getTime()) {
			Toast.makeText(this, "A data final deve at� hoje!",
					Toast.LENGTH_LONG).show();*/
		} else {
			tabela_peso.removeAllViews();

			TableRow tRow;
			TextView txt;
			
			tRow = new TableRow(getApplicationContext());

			txt = new TextView(getApplicationContext());
			txt.setText("Data do registro          ");
			txt.setTextColor(Color.BLUE);
			tRow.addView(txt);

			txt = new TextView(getApplicationContext());
			txt.setText("Peso");
			txt.setTextColor(Color.BLUE);
			txt.setGravity(Gravity.CENTER);
			tRow.addView(txt);

			tabela_peso.addView(tRow);

			dao.BasicoDAO b = new dao.BasicoDAO(getApplicationContext());
			List<classe.CadastroBasico> lst = b
					.getTodosOrdenadosPelaUltimaInclusao(UsuarioLogado
							.getUsuarioLogado().getId());

			for (int i = lst.size() - 1; i >= 0; i--) {
				
				System.out.println("Data inicial: " + new Date(dataInicial.getTimeInMillis()));
				System.out.println("Data final  : " + new Date(dataFinal.getTimeInMillis()));
				System.out.println("data at     : " + lst.get(i).getData_atualizacao());
				if (dataInicial.getTime().getTime() < 
						lst.get(i).getData_atualizacao().getTime()
						&& dataFinal.getTime().getTime() >
							lst.get(i).getData_atualizacao().getTime())
				{
					tRow = new TableRow(getApplicationContext());
					txt = new TextView(getApplicationContext());
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					try {
						txt.setText(sdf
								.format(lst.get(i).getData_atualizacao()));
					} catch (Exception e) {
						txt.setText("????");
					}
					txt.setTextColor(Color.BLACK);
					tRow.addView(txt);

					txt = new TextView(getApplicationContext());
					txt.setTextColor(Color.BLACK);
					txt.setText(String.valueOf(lst.get(i).getPeso()));

					tRow.addView(txt);

					tabela_peso.addView(tRow);
				}
			}
		}

	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DATE_:
			return new DatePickerDialog(this, DateInitialSetListener,
					dataInicial.get(Calendar.YEAR),
					dataInicial.get(Calendar.MONTH),
					dataInicial.get(Calendar.DAY_OF_MONTH));
		case DATE_F:
			return new DatePickerDialog(this, DateFinalSetListener,
					dataFinal.get(Calendar.YEAR),
					dataFinal.get(Calendar.MONTH),
					dataFinal.get(Calendar.DAY_OF_MONTH));

		}
		return null;

	}

	public void finish(View v) {
		finish();
	}

	private DatePickerDialog.OnDateSetListener DateInitialSetListener = new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			dataInicial.set(Calendar.DAY_OF_MONTH, dayOfMonth);
			dataInicial.set(Calendar.MONTH, monthOfYear);
			dataInicial.set(Calendar.YEAR, year);
			AtualizaBtnDataInicial();
		}
	};

	private DatePickerDialog.OnDateSetListener DateFinalSetListener = new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year_final,
				int monthOfYear_final, int dayOfMonth_final) {
			dataFinal.set(Calendar.DAY_OF_MONTH, dayOfMonth_final);
			dataFinal.set(Calendar.MONTH, monthOfYear_final);
			dataFinal.set(Calendar.YEAR, year_final);
			AtualizaBtnDataFinal();
		}
	};

}
