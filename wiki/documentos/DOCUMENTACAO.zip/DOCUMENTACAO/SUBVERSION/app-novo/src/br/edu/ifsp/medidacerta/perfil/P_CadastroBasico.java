package br.edu.ifsp.medidacerta.perfil;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.edu.ifsp.medidacerta.R;

import classe.CadastroBasico;
import classe.Usuario;
import classe.UsuarioLogado;
import dao.BasicoDAO;
import dao.UsuarioDAO;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class P_CadastroBasico extends Activity {

    private CadastroBasico cad;
    private Usuario usu;
	private List<CadastroBasico> cadastro;
	private BasicoDAO dao;
	private UsuarioDAO usu_dao;
	private EditText txtAltura;
	private EditText txtPeso;
	private EditText txtMeta;
	private Spinner spObjetivo;
	private String operacao;
	private Integer id = 0;
	private String[] objetivo = { "Ganhar peso", "Perder peso", "Manter peso", "Nenhum objetivo" };

    @Override    
    public void onCreate(Bundle savedInstanceState) {
		
    	super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		txtAltura = (EditText) findViewById(R.id.txtAltura);
		txtPeso = (EditText) findViewById(R.id.txtPeso);
		txtMeta = (EditText) findViewById(R.id.txtMeta);
		spObjetivo = (Spinner) findViewById(R.id.spObjetivo);		
		
		cadastro = new ArrayList<CadastroBasico>();
		dao = new BasicoDAO(getApplicationContext());
		preencherObjetivo();
		
		usu_dao = new UsuarioDAO(getApplicationContext());
		usu = UsuarioLogado.getUsuarioLogado();
		id = usu.getId();
		int meta = usu.getMetaCalorica();
		int obj = usu.getObjetivo().getId();
		
		if(obj == 1){
			
			spObjetivo.setSelection(0);
		}
		else if(obj == 2){
			
			spObjetivo.setSelection(1);
		}
		else if(obj == 3){
			
			spObjetivo.setSelection(2);
		}
		else if(obj == 4){
			
			spObjetivo.setSelection(3);
			
		}
		
		txtMeta.setText(String.valueOf(meta));
		
		operacao = new String("Novo");

		/*Date data_dia = new Date();
		cad = dao.getByIDOrder(id);
		
		if(cad != null){
		
			long diff = data_dia.getTime() - cad.getData_atualizacao().getTime();
			
			if(diff > 30){
			
				exibirMensagem("Voc� j� pode informar novos valores para peso e altura!");
				cad = null;
			}
		}*/
	}

    private void preencherObjetivo() {
		
    	try {
    		
			ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
					android.R.layout.simple_list_item_1, objetivo);
			adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spObjetivo.setAdapter(adapter);
		} catch (Exception ex) {
			exibirMensagem("Erro: " + ex.getMessage());
		}

	}
    
    private void preencherDados(CadastroBasico cadastro) {
		
		txtAltura.setText(String.valueOf(cadastro.getAltura()));
		txtPeso.setText(String.valueOf(cadastro.getPeso()));
		
		if(usu != null){
			
			txtMeta.setText(String.valueOf(usu.getMetaCalorica()));
			
			if(usu.getObjetivo().getId() == 1){
				
				spObjetivo.setSelection(0);
			}
			else if(usu.getObjetivo().getId() == 2){
				
				spObjetivo.setSelection(1);
			}
			else if(usu.getObjetivo().getId() == 3){
				
				spObjetivo.setSelection(2);
			}
			else if(usu.getObjetivo().getId() == 4){
				
				spObjetivo.setSelection(3);
				
			}

		}
		else exibirMensagem("Erro ao selecionar usuario!");
		
	}
    
    public void salvar(View v) {
		
		if (operacao.equalsIgnoreCase("Novo")) {
			cad = new CadastroBasico();
		}
		
		if(txtAltura.getText().toString().equalsIgnoreCase("") ||
				txtPeso.getText().toString().equalsIgnoreCase("") ||
				txtMeta.getText().toString().equalsIgnoreCase("")){
			
			exibirMensagem("Informe todos os dados para cadastro!");
		}
		else{
				cad.setId_usuario(id);
				cad.setAltura(Float.valueOf((txtAltura.getText().toString())));
				cad.setPeso(Float.valueOf(txtPeso.getText().toString()));
				cad.setData_atualizacao(new Date());
												
				int obj = 0;
				
				if (objetivo[spObjetivo.getSelectedItemPosition()]
						.equalsIgnoreCase("Ganhar Peso")){
					
					obj = 1;
				}
				else if (objetivo[spObjetivo.getSelectedItemPosition()]
						.equalsIgnoreCase("Perder Peso")){
					
					obj = 2;
					
				}
				else if (objetivo[spObjetivo.getSelectedItemPosition()]
						.equalsIgnoreCase("Manter Peso")){
					
					obj = 3;
					
				}
				else obj = 4;
				
				usu.setMetaCalorica(Integer.parseInt(txtMeta.getText().toString()));
				usu.setObjetivo(obj);
		
				if (operacao.equalsIgnoreCase("Novo")) {
		
					usu_dao.atualizar(usu);
					dao.salvar(cad);
					
					exibirMensagem("Dados cadastrados com sucesso!");
					Intent it = new Intent(getApplicationContext(), P_ConsultarAvancado.class);
					startActivity(it);
					
				}
				
				limparDados();
		}

	}
    
    private void limparDados() {
		
    	txtAltura.setText("");
		txtPeso.setText("");
		txtMeta.setText("");
		spObjetivo.setSelection(0);

	}
    
    private void exibirMensagem(String msg) {
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
	}
    
    public void voltar(View v) {
    	Intent it = new Intent(getApplicationContext(), P_ConsultarDados.class);
    	startActivity(it);
    }
}