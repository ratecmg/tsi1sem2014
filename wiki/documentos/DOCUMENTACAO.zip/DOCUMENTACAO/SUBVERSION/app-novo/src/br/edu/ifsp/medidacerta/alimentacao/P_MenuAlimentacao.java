package br.edu.ifsp.medidacerta.alimentacao;

import classe.Usuario;
import classe.UsuarioLogado;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.alimentacao.graphs.AlimentacaoMenuGraphActivity;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class P_MenuAlimentacao extends Activity {
	
	ImageButton btnGraphc = null;
	ImageButton btnListaAlimentos = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.a_p_menu_alimentacao);
		
		btnGraphc = (ImageButton) findViewById( R.id.imageButton5 );
		
		btnGraphc.setOnClickListener( new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent( getApplicationContext(), AlimentacaoMenuGraphActivity.class );
				startActivity( intent );
				
			}
			
		} );
		
		btnListaAlimentos = (ImageButton) findViewById( R.id.imageButton2 );
		
		btnListaAlimentos.setOnClickListener( new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent( getApplicationContext(), A_ListaAlimentos.class );
				startActivityForResult( intent, 1 );
				
			}
			
		} );
		Usuario u = UsuarioLogado.getUsuarioLogado();
		if(u!=null){
			Toast.makeText(getApplicationContext(), "Usuario: "+u.getEmail(), Toast.LENGTH_LONG).show();
		}else{
			Toast.makeText(getApplicationContext(), "Usuario: null", Toast.LENGTH_LONG).show();
		}
	}
	
	public void onActivityResult( int requestCode, int resultCode, Intent data ) {
			
		String teste;
		teste = data.getExtras().getString("valor"); 
		
		Toast.makeText( getApplicationContext(), teste, Toast.LENGTH_LONG ).show();
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.p_menu_alimentacao, menu);
		return true;
	}
	
	/**
	 * Chamada da intent para cadastro de consumo di�rio
	 */
	public void abrirCadastroConsumo(View v) {
		Intent i = new Intent(this, P_CadastroConsumo.class);
		startActivity(i);
	}
	
	/**
	 * Chamada da intent para listagem de consumo di�rio
	 */
	public void abrirExibirConsumo(View v) {
		Intent i = new Intent(this, P_ListaConsumo.class);
		startActivity(i);
	}
	
	/**
	 * Chamada da intent para cadastro de alimento
	 */
	public void abrirCadastroAlimento(View v) {
		Intent i = new Intent(this, A_InserirAlimento.class);
		startActivity(i);
	}

}
