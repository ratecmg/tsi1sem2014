package br.edu.ifsp.medidacerta.alimentacao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Toast;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.UtilHelper;
import classe.ConsumoDiario;
import dao.ConsumoDAO;

public class P_ListaConsumo extends Activity {

	private static final int INICIO_ = 0;
	private static final int FIM_ = 1;
	private ListView lConsumo;
	private Button bDataBuscaInicial;
	private Button bDataBuscaFinal;
	private List<ConsumoDiario> consumos;
	private Calendar dataConsumoBuscaIncio = Calendar.getInstance();
	private Calendar dataConsumoBuscaFim = Calendar.getInstance();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.a_p_lista_consumo);
		bDataBuscaFinal = (Button) findViewById(R.id.bDataBuscaConsumoFinal);
		bDataBuscaInicial = (Button) findViewById(R.id.bDataBuscaConsumoInicial);
		lConsumo = (ListView) findViewById(R.id.lConsumo);
		lConsumo.setOnItemLongClickListener(excluirConsumo);
		atualizaLista();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.p__lista_consumo, menu);
		return true;
	}

	/**
	 * Busca os consumos diarios no banco. Caso receba o parametro null retorna
	 * todos os valores.
	 */
	public List<ConsumoDiario> busca(Calendar cI, Calendar cF) {
		ConsumoDAO daoC = new ConsumoDAO(getApplicationContext());
		List<ConsumoDiario> l = daoC.listAll();
		List<ConsumoDiario> lFinal = new ArrayList<ConsumoDiario>();
		
		cI.add(Calendar.DATE, -1);
		cF.add(Calendar.DATE, 1);
		
		for (ConsumoDiario consumoDiario : l) {
			if(consumoDiario.getDataHoraConsumo().after(cI.getTime())){
				if(consumoDiario.getDataHoraConsumo().before(cF.getTime())){
					lFinal.add(consumoDiario);
				}
			}
		}
		return lFinal;
	}
	
	public void buscar(View v) {
		atualizaLista();
	}
	
	/**
	 * M�todo para atualizar a lista ap�s uma busca
	 */
	public void atualizaLista() {
		consumos =  busca(dataConsumoBuscaIncio, dataConsumoBuscaFim);
		ConsumoListAdapter cla = new ConsumoListAdapter(
				getApplicationContext(),consumos);
		lConsumo.setAdapter(cla);
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case INICIO_:
			return new DatePickerDialog(this, DateSetListener,
					dataConsumoBuscaIncio.get(Calendar.YEAR),
					dataConsumoBuscaIncio.get(Calendar.MONTH),
					dataConsumoBuscaIncio.get(Calendar.DAY_OF_MONTH));

		case FIM_:
			return new DatePickerDialog(this, DateSetListener2,
					dataConsumoBuscaFim.get(Calendar.YEAR),
					dataConsumoBuscaFim.get(Calendar.MONTH),
					dataConsumoBuscaFim.get(Calendar.DAY_OF_MONTH));
		}
		return null;

	}
	
	private DatePickerDialog.OnDateSetListener DateSetListener = new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			dataConsumoBuscaIncio.set(Calendar.DAY_OF_MONTH, dayOfMonth);
			dataConsumoBuscaIncio.set(Calendar.MONTH, monthOfYear);
			dataConsumoBuscaIncio.set(Calendar.YEAR, year);
			AtualizaBtnDataInicio();
		}
	};
	
	private DatePickerDialog.OnDateSetListener DateSetListener2 = new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			dataConsumoBuscaFim.set(Calendar.DAY_OF_MONTH, dayOfMonth);
			dataConsumoBuscaFim.set(Calendar.MONTH, monthOfYear);
			dataConsumoBuscaFim.set(Calendar.YEAR, year);
			AtualizaBtnDataFim();
			}
	};
	private void AtualizaBtnDataInicio() {
		bDataBuscaInicial.setText(UtilHelper.getDataToPersist(dataConsumoBuscaIncio));
	}
	
	/**
	 * M�todo para atualizar a data do bot�o
	 */
	private void AtualizaBtnDataFim() {
		bDataBuscaFinal.setText(UtilHelper.getDataToPersist(dataConsumoBuscaFim));
	}
	
	/**
	 * M�todo para selecionar uma nova data
	 */
	public void definirDataInicio(View v) {
		showDialog(INICIO_);
	}
	
	/**
	 * M�todo para selecionar uma nova data
	 */
	public void definirDataFim(View v) {
		showDialog(FIM_);
	}
	
	private OnItemLongClickListener excluirConsumo = new OnItemLongClickListener() {
		public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int pos,
				long arg3) {

			excluirConsumo(consumos.get(pos).getIdConsumo());
			return true;
		}
	};
	
	/**
	 * M�todo para excluir um consumo di�rio
	 */
	private void excluirConsumo(final Integer idExclusao) {
		final ConsumoDAO daoC = new ConsumoDAO(getApplicationContext());
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Excluir consumo?")
				.setIcon(android.R.drawable.ic_dialog_alert)
				.setMessage("Deseja excluir esse consumo?")
				.setCancelable(false)
				.setPositiveButton("Sim",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								if (daoC.deletar(idExclusao)) {
									atualizaLista();
								} else {
									Toast.makeText(getApplicationContext(), "N�o foi possivel excluir", Toast.LENGTH_LONG).show();
								}

							}
						})
				.setNegativeButton("N�o",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								dialog.cancel();
							}
						});
		builder.create();
		builder.show();
	}
}
