package br.edu.ifsp.medidacerta.shared.chart;

import org.achartengine.ChartFactory;
import org.achartengine.model.CategorySeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;

public class PieGraph {
	
	public Intent getIntent( Context context )
	{
		
		int[] values = { 1, 2, 3, 4, 5 };
		CategorySeries series = new CategorySeries( "Gr�fico de pizza" );
		
		int k = 0;
		
		for ( int value : values )
		{
			series.add( "Se��o " + (++k), value );
		}
		
		int[] colors = { Color.BLUE,
						 Color.GREEN,
						 Color.MAGENTA,
						 Color.YELLOW,
						 Color.CYAN
					   };
		
		DefaultRenderer renderer = new DefaultRenderer();
		
		for ( int color : colors )
		{
			
			SimpleSeriesRenderer r = new SimpleSeriesRenderer();
			r.setColor( color );
			renderer.addSeriesRenderer( r );
			
		}
		
		renderer.setBackgroundColor( Color.BLACK );
		renderer.setApplyBackgroundColor( true );
		renderer.setChartTitle( "Gr�fico de pizza" );
		renderer.setChartTitleTextSize( 20 );
		renderer.setShowGrid( true );
		
		Intent intent = ChartFactory.getPieChartIntent( context, series, renderer, "Pizza" );
		
		return intent;
		
	}
	
}
