package br.edu.ifsp.medidacerta;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.util.Log;
import java.util.Locale;

public class UtilHelper {
	private static SimpleDateFormat formatoDateToString = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
	
	public static String getDataToPersist(Calendar cal) {

		String retorno = "";

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		retorno = sdf.format(cal.getTime());

		return retorno;

	}

	public static String getDataHourToPersist(Calendar cal) {

		String retorno = "";

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

		retorno = sdf.format(cal.getTime());

		return retorno;

	}

	public static String getDataToPersist(Date cal) {

		String retorno = "";

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		retorno = sdf.format(cal);

		return retorno;

	}

	public static String getDataHourToPersist(Date cal) {

		String retorno = "";

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

		retorno = sdf.format(cal);

		return retorno;

	}
	public static Date getDataByStringDate(String sData) throws Exception {

		Date data = new Date();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			data = sdf.parse(sData);
		} catch (Exception e) {
			data = getLegacyFormat(sData);
		}
		

		return data;

	}
	
	public static Date getDataByStringDateHour(String sData) throws Exception {

		Date data = new Date();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

		try {
			data = sdf.parse(sData);
		} catch (Exception e) {
			data = getLegacyFormat(sData);
		}

		return data;

	}

	public static Date addDay(Date data, int numDays) {

		Calendar cTemp = Calendar.getInstance();
		cTemp.setTime(data);
		cTemp.add(Calendar.DATE, 1);

		Date dataTemp = cTemp.getTime();

		return dataTemp;

	}
	public static Date getLegacyFormat(String sdt) {
		Date data = null;
		try {
			data = formatoDateToString.parse(sdt);
		} catch (Exception e2) {
			// senta e chora
			e2.printStackTrace();
		}
		return data;
	}
}
