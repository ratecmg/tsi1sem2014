package br.edu.ifsp.medidacerta.alimentacao;

import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.alimentacao.graphs.AlimentacaoMenuGraphActivity;
import classe.Alimento;
import dao.AlimentoDAO;

public class A_ListaAlimentos extends Activity {

	Alimento alimento;
	AlimentoDAO dao;
	List<Alimento> la;
	ListView listViewAlimento;
	private EditText edBuscar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.a_a_lista_alimentos);
		edBuscar = (EditText) findViewById(R.id.edBuscar);

		dao = new AlimentoDAO(getApplicationContext());

		la = dao.listAll();

		ARAlimentoAdapterActivity alimentoAdapter = new ARAlimentoAdapterActivity(
				getApplicationContext(), la);

		listViewAlimento = (ListView) findViewById(R.id.listViewAlimentos);

		listViewAlimento.setOnItemClickListener(selecionaAlimento);

		listViewAlimento.setAdapter(alimentoAdapter);

	}

	private OnItemClickListener selecionaAlimento = new OnItemClickListener() {

		public void onItemClick(AdapterView<?> arg0, View arg1, int pos, long id) {
			
			/*
			 * CHICO COLOQUEI ISSA INSTRU��O TRY CATCH PARA VERIFICAR SE A TELA ANTERIOR ENVIOU UMA INFORMA��O BOLEANA COM O NOME DE RETORNO
			 * SE A TELA ENVIAR ESSA INFORMA��O ELE RETORNA O OBJETO ATRAV�S DO setResult, CASO N�O ENVIAR, VAI DAR ERRO O ERRO CAI NO CATH QUE MANDA PARA UMA TELA QUE VOC� ESCOLHER...
			 * A TELA QUE PRECISAR DE UM RETORNO DE ALIMENTO DEVER� TER UMA INSTRU��O INTENT.EXTRA( "RETORNO", TRUE ) IGUAL A LINHA 71 DA CLASSE P_CadastroConsumo.java
			 * OBS: ESPERO QUE A LINHA AINDA SEJA ESSA, PORQUE SE ALGUEM MEXEU PODE SER MAIS ESSA, QUALQUER COISA � SO PROCURAR... 
			 * 
			 * */
			
			Bundle extras = getIntent().getExtras();
			
			try
			{
				
				boolean retorno = extras.getBoolean( "retorno" );
				
				if ( retorno )
				{
					
					Alimento a = la.get(pos);

					Intent intent = new Intent();
					intent.putExtra("alimento", a);
					setResult(2, intent);
					finish();
					
				}
				
				
			}
			catch( Exception ex )
			{
				//ex.printStackTrace();
				Log.d( "N�o necessita de retorno", "N�o necessita de retorno" );
				
				// TROQUE ABAIXO A TELA "AlimentacaoMenuGraphActivity.class" PELA QUE VC QUER QUE A APLICA��O TE LEVE
				Intent intent = new Intent( getApplicationContext(), AlimentacaoMenuGraphActivity.class );
				startActivity( intent );
				/*
				 * ESSA LINHA � OPCIONAL, SE VC USA-LA, A TELA ATUAL MORRE ENT�O NA PR�XIMA VC N�O PODE CLICAR NO VOLTAR DO ANDROID PORQUE DA ERRO
				 * SE N�O USAR QUANDO VC USAR O VOLTAR ELE O ANDROID FICAR� NESTA TELA
				 * */
				finish();
				
			}

		}

	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.a_a_lista_alimentos, menu);
		return true;
	}

	
	/**
	 * M�todo para chamar a intent de cadastro de alimento
	 */
	public void novoAlimento(View v) {
		
		Intent intent = new Intent( getApplicationContext(), A_InserirAlimento.class );
		startActivityForResult( intent, 1 );
		
	}
	
	/**
	 * M�todo para pesquisar uma lista de alimentos
	 */
	public void pesquisar(View v) {

		String busca = edBuscar.getText().toString();

		la = dao.getByAlimento(busca);
		if (la != null) {
			atualizarLista(la);
		} else {
			exibirMensagem("Alimento n�o encontrado");
		}

	}

	/**
	 * M�todo para exibir uma mensagem na tela
	 * @param Mensagem que ser� exibida na tela 
	 */
	private void exibirMensagem(String msg) {
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
	}

	/**
	 * M�todo que atualiza a lista de alimentos
	 * @param Lista de alimentos que ser� exibida na atualiza��o
	 */
	private void atualizarLista(List<Alimento> listAlimentos) {

		if (listAlimentos != null) {
			if (listAlimentos.size() >= 0) {
				ARAlimentoAdapterActivity alimentoAdapter = new ARAlimentoAdapterActivity(
						getApplicationContext(), listAlimentos);
				listViewAlimento.setAdapter(alimentoAdapter);
			}

		}

	}

}
