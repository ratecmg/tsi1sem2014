package br.edu.ifsp.medidacerta.alimentacao;


public class Alimentacao {

	
}
