package br.edu.ifsp.medidacerta.shared.chart;



import android.content.Context;
import android.content.Intent;
import android.view.View;

public abstract class Grafico extends View {
	public Grafico(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public abstract Intent drawChart(Context context);

	private String titulo;

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

}
