package br.edu.ifsp.medidacerta.medida.activity;

import java.text.DecimalFormat;
import java.util.Date;


import classe.Pessoa;
import classe.Sexo;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.R.layout;
import br.edu.ifsp.medidacerta.R.menu;
import br.edu.ifsp.medidacerta.medida.models.ico.ICO;
import br.edu.ifsp.medidacerta.medida.models.ico.ICO.Classificacao;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.view.Menu;
import android.widget.TextView;
import android.widget.Toast;

public class CalculoICOActivity extends Activity {

	private TextView lblValorICO;
	private TextView lblValorClassificacao;
	private TextView lblDica;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_m_calculo_ico);
		lblValorICO = (TextView) findViewById(R.id.m_activity_calculo_ico_valor_ico);
		lblValorClassificacao = (TextView) findViewById(R.id.m_activity_calculo_ico_valor_classificacao);
		lblDica = (TextView) findViewById(R.id.m_activity_calculo_ico_dica);
		ICO ico = (ICO) getIntent().getSerializableExtra("ico");
		showICO(ico);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return true;
	}
	
	
	private void updateDicaHandler(Message msg) {
		lblDica.setText((CharSequence) msg.obj);
	}
	public void showICO(final ICO ico) {

		DecimalFormat fmt = new DecimalFormat("0.00");

		lblValorICO.setText(String.valueOf(fmt.format(ico.getValor())));
		lblValorICO.setBackgroundColor(ico.getClassificacao().getColorId());
		lblValorClassificacao.setText(getString(
				ico.getClassificacao().getStringId()).toUpperCase());


		lblDica.setText(getString(R.string.m_carregando_dicas));
		try {
			/**
			 *  ***********************************************************
			 *    Thread para carregamento das dicas
			 *  ***********************************************************
			 */
			final Handler dicaHandler = new Handler() {
				@Override
				public void handleMessage(android.os.Message msg) {
					updateDicaHandler(msg);
				}

			};
			Runnable r = new Runnable() {
				@Override
				public void run() {
					try {
						Message msg = new Message();
						msg.obj = ico.getDicas();						
						dicaHandler.sendMessage(msg);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			};
			new Thread(r).start();
			// **************************************************************
			
			
		}catch (Exception ex) {

		}

		
	}

}
