package br.edu.ifsp.medidacerta.perfil;

import br.edu.ifsp.medidacerta.R;

import classe.CadastroBasico;
import classe.Usuario;
import classe.UsuarioLogado;
import dao.BasicoDAO;
import dao.UsuarioDAO;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class P_AutenticacaoActivity extends Activity {
	
	private EditText login;
	private EditText senha;
	private Usuario usuario;
	private UsuarioDAO usuarioDAO;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.p_autenticacao);
		
		login = (EditText) findViewById(R.id.LoginAutenticacaoEditText);
		senha = (EditText) findViewById(R.id.SenhaAutenticacaoEditText);
		
		usuarioDAO = new UsuarioDAO(getApplicationContext());	
		
	}	

	
	public void autenticar(View v)
	{
		usuario = usuarioDAO.getByLoginSenha(login.getText().toString(), senha.getText().toString());

		if (usuario == null)
		{
			exibirMensagem("Login ou senha incorretos");
		}
		else
		{
			Intent it = new Intent(getApplicationContext(), P_ConsultarDados.class);
			UsuarioLogado.setUsuarioLogado(usuario);
			startActivity(it);
			
		}
	
	}
	
	private void exibirMensagem(String msg) {
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
	}
	
	public void cadastrar(View v)
	{
		UsuarioLogado.setUsuarioLogado(null);
		Intent it = new Intent(this, P_CadastrarActivity.class);
		startActivity(it);
	}
}