package br.edu.ifsp.medidacerta.enciclopedia.activity;

import java.util.ArrayList;
import java.util.List;

import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.enciclopedia.dao.DicaDAO;
import br.edu.ifsp.medidacerta.enciclopedia.models.Dica;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

/** Classe utilizada para exibir as dicas de nutri��o

* podendo filtra-las de acordo com os objetivos pr� determinados

* - Perder peso, Manter peso e ganhar Peso - 

* @author Ricardo Theodoro

*/

public class EncDcNutricaoActivity extends Activity {

	private Spinner spn1;
	private List<String> opcs = new ArrayList<String>();
	private String opc;
	private List<Dica> dicas;
	private ListView lvDicas;
	DicaDAO dao = new DicaDAO();
	
/** M�todo para a execu��o da tela que exibe as dicas de nutri��o

* @return Void

*/	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_enc_dcnutricao);

		lvDicas = (ListView) findViewById(R.id.list_nutri);
		dicas = new ArrayList<Dica>();

		// Add op��es para Spinner
		opcs.add("PERDER PESO");
		opcs.add("MANTER PESO");
		opcs.add("GANHAR PESO");

		spn1 = (Spinner) findViewById(R.id.spn_atv);

		ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, opcs);
		ArrayAdapter<String> spinnerArrayAdapter = arrayAdapter;
		spinnerArrayAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_item);
		spn1.setAdapter(spinnerArrayAdapter);

		spn1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

			
			@Override
			public void onItemSelected(AdapterView<?> parent, View v,
					int posicao, long id) {
				// pega nome pela posi��o
				opc = parent.getItemAtPosition(posicao).toString();
				
				// imprime um Toast na tela com o nome que foi selecionado
				Toast.makeText(EncDcNutricaoActivity.this,
						"Dicas para " + opc + " selecionadas!",
						Toast.LENGTH_LONG).show();

			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {

			}

		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_enc_dcnutricao, menu);
		return true;
	}

/**M�todo para execu��o do webservice buscando uma lista de dicas

* de acordo com o objetivo selecionado pelo usu�rio.

* @return void

*/	

	private void atualizarLista() {

		if (opc.equals("PERDER PESO")) {
			dicas = getDicasWS(1);
		}
		else if (opc.equals("MANTER PESO")) {
			dicas = getDicasWS(2);
		}
		else if (opc.equals("GANHAR PESO")) {
			dicas = getDicasWS(3);
		}

		DicaListAdapter pla = new DicaListAdapter(getApplicationContext(),
				dicas);
		lvDicas.setAdapter(pla);

	}

/**M�todo pque percorre a lista retornada pelo webservice

* @return List - dicas

*/
	
	public List<Dica> getDicasWS(int num) {

		
		List<Dica> dicas = new ArrayList<Dica>();
		try {
			 dicas = dao.listDicasNutricionais(num);
			 for (Dica d : dicas){
			 dicas.add(d);
			 }
		} catch (Exception e) {
			Dica d = new Dica();
			d.setDica("Sem dicas.");
			dicas.add(d);
		}
		return dicas;
	}	

/**M�todo que implementa a fun��o - android:onclick - do bot�o - voltar - 

*/
	
	public void voltar(View v) {
		Intent intent_main = new Intent(this, EncMainActivity.class);
		startActivity(intent_main);
	}

/**M�todo que implementa a fun��o - android:onclick - do bot�o - atualizar - 

*/
	
	public void pesquisar(View v) {
		atualizarLista();
	}

}
