package br.edu.ifsp.medidacerta.shared.chart;

import org.achartengine.ChartFactory;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;

public class ScatterGraph {
	
	public Intent getIntent( Context context )
	{
		
		//Valores 1
		XYSeries series = new XYSeries( "Valores 1" );
		
		int[] x = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		double[] values = { 1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7, 8.8, 9.9, 10.1 };
		
		int length = x.length;
		for ( int k = 0; k < length; k++ )
		{
			series.add( x[k], values[k] );
		}
		
		//Valores 2
		XYSeries series2 = new XYSeries( "Valores 2" );
		
		int[] x2 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		double[] values2 = { 2.4, 3.5, 6.7, 3.5, 4.57, 6.7, 9.7, 10.8, 11.9, 14.1 };
		
		int length2 = x2.length;
		for ( int k = 0; k < length2; k++ )
		{
			series2.add( x2[k], values2[k] );
		}
		
		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		dataset.addSeries( series );
		dataset.addSeries( series2 );
		
		XYSeriesRenderer renderer = new XYSeriesRenderer();
		renderer.setColor( Color.WHITE );
		renderer.setPointStyle( PointStyle.DIAMOND );
		renderer.setLineWidth( 6 );
		
		XYSeriesRenderer renderer2 = new XYSeriesRenderer();
		renderer2.setColor( Color.YELLOW );
		renderer2.setPointStyle( PointStyle.TRIANGLE );
		renderer2.setLineWidth( 6 );
		
		XYMultipleSeriesRenderer sRenderer = new XYMultipleSeriesRenderer();
		sRenderer.setBackgroundColor( Color.BLACK );
		sRenderer.setApplyBackgroundColor( true );
		sRenderer.setShowGrid( true );
		sRenderer.addSeriesRenderer( renderer );
		sRenderer.addSeriesRenderer( renderer2 );
		
		return ChartFactory.getScatterChartIntent( context, dataset, sRenderer );
		
	}
	
}
