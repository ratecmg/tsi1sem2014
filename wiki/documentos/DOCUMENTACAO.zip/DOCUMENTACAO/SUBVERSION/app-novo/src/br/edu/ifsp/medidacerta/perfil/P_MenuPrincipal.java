package br.edu.ifsp.medidacerta.perfil;

import java.io.IOException;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.alimentacao.P_MenuAlimentacao;
import br.edu.ifsp.medidacerta.enciclopedia.activity.EncMainActivity;
import br.edu.ifsp.medidacerta.medida.activity.MedidasPrincipalActivity;
import classe.Usuario;
import classe.UsuarioLogado;

public class P_MenuPrincipal extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.p_menuprincipal);
    }
    
    public void abrirAlimentacao(View v) {
    	Intent intent = new Intent(this, P_MenuAlimentacao.class);
    	startActivity(intent);
	}

    public void abrirPerfil(View v) {
    	Intent intent = new Intent(this, P_ConsultarDados.class);
    	startActivity(intent);
	}
    public void abrirMedida(View v) {
    	
    	Usuario u = UsuarioLogado.getUsuarioLogado();
    	if (u == null){
    		Toast.makeText(getApplicationContext(), "Logue antes de entrar", Toast.LENGTH_LONG).show();
    	} else {
	    	Intent intent = new Intent(this, MedidasPrincipalActivity.class);
	    	startActivity(intent);
    	}
	}
    public void abrirEnciclopedia(View v) {
    	Intent intent = new Intent(this, EncMainActivity.class);
    	startActivity(intent);
	}
    
}