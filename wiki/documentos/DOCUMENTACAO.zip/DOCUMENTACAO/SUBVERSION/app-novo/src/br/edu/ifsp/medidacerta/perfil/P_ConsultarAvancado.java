package br.edu.ifsp.medidacerta.perfil;

import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import br.edu.ifsp.medidacerta.R;

import classe.CadastroBasico;
import classe.CadastroComplementar;
import classe.Usuario;
import classe.UsuarioLogado;
import dao.BasicoDAO;
import dao.MedidasDAO;
import dao.UsuarioDAO;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class P_ConsultarAvancado extends Activity {

    private Usuario cad = new Usuario();
	private List<Usuario> cadastro;
	private UsuarioDAO dao;
	private CadastroComplementar cadComplementar;
	private MedidasDAO medDAO;
	private CadastroBasico cadBase;
	private BasicoDAO basicoDAO;

	private TextView cintura;
	private TextView quadril;
	private TextView meta;
	private TextView cardiaca;
	private TextView pressao;
	

    @Override    
    public void onCreate(Bundle savedInstanceState) {
		
    	super.onCreate(savedInstanceState);
		setContentView(R.layout.p_consultaravancado);

		cintura = (TextView) findViewById(R.id.p04_putCintura);
		quadril = (TextView) findViewById(R.id.p04_putQuadril);
		meta = (TextView) findViewById(R.id.p04_putMeta);
		cardiaca = (TextView) findViewById(R.id.p04_putpressao);
		pressao = (TextView) findViewById(R.id.p04_putcardiaca);
		cadComplementar = new CadastroComplementar();
		medDAO = new MedidasDAO(getApplicationContext());
		cad = UsuarioLogado.getUsuarioLogado();
		cadBase = new CadastroBasico();
		basicoDAO = new BasicoDAO(getApplicationContext());
		try {
		cadComplementar = medDAO.getByID(cad.getId());
		} catch (Exception x) {
			cadComplementar.setCircunferencia(0.0);
			cadComplementar.setFrequencia(0.0);
			cadComplementar.setPressao("0.0");
			cadComplementar.setQuadril(0.0);
		}
		try {
		preencherDados();
		} catch (Exception x) {
			preencherDados2();
		}

	}

	/**
	 * Preencha os dados avan�ados do usuario na tela
	 * @param 
	 * @return
	 */
    public void preencherDados() {
		
    	meta.setText(Integer.toString(cad.getMetaCalorica()));
    	cintura.setText(Double.toString(cadComplementar.getCircunferencia()));
    	quadril.setText(Double.toString(cadComplementar.getQuadril()));    	
    	cardiaca.setText(Double.toString(cadComplementar.getFrequencia()));   	
    	pressao.setText(cadComplementar.getPressao());
	}
    
	/**
	 * Preencha os dados do usuario na tela caso os complementares n�o existam
	 * @param 
	 * @return
	 */
    
    public void preencherDados2() {
		try{
			meta.setText(cad.getMetaCalorica());
    	}catch(Exception e){
			e.printStackTrace();
		}
    	cintura.setText("Sem cintura");
    	quadril.setText("Sem quadril");    	
    	cardiaca.setText("Sem batimentos cardiacos");   	
    	pressao.setText("Sem pressao");
	}
    
    public void voltar(View v) {
        Intent it = new Intent(getApplicationContext(), P_ConsultarDados.class);
        startActivity(it);
    }
    
    public void mudarEditar(View v) {
    	
    }
    
    private void exibirMensagem(String msg) {
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
	}
    
    public void cadastroComplementar(View v) {
    	Intent it = new Intent(getApplicationContext(), P_CadastroComplementar.class);
    	startActivity(it);
    }
}
