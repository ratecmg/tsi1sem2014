package br.edu.ifsp.medidacerta.alimentacao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import classe.ConsumoDiario;

import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.R.layout;
import br.edu.ifsp.medidacerta.R.menu;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ConsumoListAdapter extends BaseAdapter {

	private Context context;
	private List<ConsumoDiario> lista;
	
	
	/**
	 * Construtor para criar uma lista de consumo di�rio
	 */
	public ConsumoListAdapter(Context context, List<ConsumoDiario> lista) {
		this.context = context;
		this.lista = lista;
	}
	@Override
	public int getCount() {
		return lista.size();
	}
	@Override
	public Object getItem(int position) {
		return lista.get(position);
		
	}
	@Override
	public long getItemId(int position) {
		return position;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ConsumoDiario c = lista.get(position);
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
		View view = inflater.inflate(R.layout.a_p_consumo_list_adapter,null);
		
		TextView alimentoConsumido = (TextView) view.findViewById(R.id.tvAlimentoConsumido);
		alimentoConsumido.setText(c.getAlimentoConsumido().getAlimento());
		
		TextView porcaoConsumido = (TextView) view.findViewById(R.id.tvPorcaoConsumido);
		porcaoConsumido.setText(c.getQuantidadeEmPorcoes().toString() + " por��es");
		
		TextView dataHoraConsumo = (TextView) view.findViewById(R.id.tvDataHoraConsumo);
		String data = "";
		try {
			SimpleDateFormat formataData = new SimpleDateFormat("dd/MM/yyyy HH:mm");
			data = formataData.format(c.getDataHoraConsumo());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dataHoraConsumo.setText(data);
		return view;
	}

	
}
