package br.edu.ifsp.medidacerta.enciclopedia.activity;

import br.edu.ifsp.medidacerta.R;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;

/** Classe utilizada para exibir um alerta sobre a importância

* da consulta de um profissional especializado em nutrição e atividades físicas.

* @author Ricardo Theodoro

*/

public class EncAlertaActivity extends Activity {

	private Integer tela;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_enc_alerta);

		Intent it = getIntent();
		Bundle params = it.getExtras();

		tela = params.getInt("tela");

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_enc_alerta, menu);
		return true;
	}

/**	Método para redirecionamento de acordo com a opção escolhida pelo usuário

* - Dicas de Atividades Físicas ou Dicas de Nutrição -

*/
	
	public void redirect(View v) {
		System.out.print("valor de tela: " + tela);
		if (tela == 1) {
			Intent intent_nutricao = new Intent(this,
					EncDcNutricaoActivity.class);
			startActivity(intent_nutricao);
		} else if (tela == 2) {
			Intent intent_atividades = new Intent(this,
					EncDcAtividadesActivity.class);
			startActivity(intent_atividades);
		}
	}

/**Método que implementa a função - android:onclick - do botão - voltar - 

*/
	
	public void voltar(View v) {
		Intent intent_main = new Intent(this, EncMainActivity.class);
		startActivity(intent_main);
	}

}

	