package br.edu.ifsp.medidacerta.medida.activity;

import classe.Usuario;
import classe.UsuarioLogado;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.R.layout;
import br.edu.ifsp.medidacerta.R.menu;
import br.edu.ifsp.medidacerta.medida.models.imc.IMC;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.webkit.WebView;

public class CompartilharActivity extends Activity {

	private WebView webView;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_m_compartilhar);
		webView = (WebView) findViewById(R.id.m_activity_compartilhar_webview);
		Usuario u = MedidasPrincipalActivity.usuarioAtualizado;
		String nome = u.getNome();
		double peso = u.getPeso();	
		String genero = String.valueOf(u.getSexo().getCode()).toLowerCase();
		if (genero.equals("m")){
			genero = "h";
		} else if (genero.equals("f")){
			genero = "m";
		}
		System.out.println("Sexo: " + genero);
		int clsf = 0;
		try {
			IMC imc = new IMC(u);
			clsf = imc.getClassificacao().getId();
		} catch (Exception e) {
			
		}
		String url = "https://www.facebook.com/sharer.php?" +
				"appId=627169240660685&sdk=joey&u=" +
				"http%3A%2F%2Ftdg.zz.mu%2Fmedidacerta%3F" +
				"nm%3D" + nome + "%26" +
				"sx%3D" + genero + "%26" +
				"cf%3D" + clsf + "%26" +
				"kg%3D" + peso + "%26"	;
		System.out.println("URL: " + url);
		
		webView.loadUrl(url);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.compartilhar, menu);
		return true;
	}

}
