package br.edu.ifsp.medidacerta.enciclopedia.dao;



import java.util.ArrayList;
import java.util.List;

import br.edu.ifsp.medidacerta.enciclopedia.models.Dica;
import br.edu.ifsp.medidacerta.enciclopedia.ws.DicaREST;

public class DicaDAO {
	
	private DicaREST rest = new DicaREST("dica");

	public List<Dica> listAll() {
		List<Dica> list = new ArrayList<Dica>();
		try {
			list = rest.getListaDicas();
		} catch (Exception e) {

			e.printStackTrace();
		}

		return list;

	}
	
	public List<Dica> listPorObjetivo(Integer id_objetivo) {
		List<Dica> list = new ArrayList<Dica>();
		try {
			list = rest.getListaDicas(id_objetivo);
		} catch (Exception e) {

			e.printStackTrace();
		}

		return list;

	}
	
	public List<Dica> listDicasAtividades(Integer id_objetivo) {
		List<Dica> list = new ArrayList<Dica>();
		try {
			list = rest.getListaDicasAtividades(id_objetivo);
		} catch (Exception e) {

			e.printStackTrace();
		}

		return list;

	}

	public List<Dica> listDicasNutricionais(Integer id_objetivo) {
		List<Dica> list = new ArrayList<Dica>();
		try {
			list = rest.getListaDicasNutricionais(id_objetivo);
		} catch (Exception e) {

			e.printStackTrace();
		}

		return list;

	}
	
	public List<Dica> listPorClassificacao(Integer id_objetivo, Integer id_classificacao) {
		List<Dica> list = new ArrayList<Dica>();
		try {
			list = rest.getListaDicasPorClassificacao(id_objetivo, id_classificacao);
		} catch (Exception e) {

			e.printStackTrace();
		}

		return list;

	}
	
}
