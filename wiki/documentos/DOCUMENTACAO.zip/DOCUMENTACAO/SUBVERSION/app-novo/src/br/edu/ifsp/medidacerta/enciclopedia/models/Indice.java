package br.edu.ifsp.medidacerta.enciclopedia.models;

public class Indice {

	private int id_indice;
	private String indice;
	
	public int getId_indice() {
		return id_indice;
	}
	public void setId_indice(int id_indice) {
		this.id_indice = id_indice;
	}
	public String getIndice() {
		return indice;
	}
	public void setIndice(String indice) {
		this.indice = indice;
	}	

}
