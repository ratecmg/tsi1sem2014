package br.edu.ifsp.medidacerta.enciclopedia.models;


public class Enciclopedia  {

}
