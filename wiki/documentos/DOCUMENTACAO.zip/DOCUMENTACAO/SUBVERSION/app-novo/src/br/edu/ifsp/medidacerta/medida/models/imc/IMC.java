/*
 * Equipe de Medidas
 * 
 */
package br.edu.ifsp.medidacerta.medida.models.imc;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import classe.Objetivo;
import classe.Pessoa;
import classe.Sexo;

import android.graphics.Color;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.enciclopedia.dao.DicaDAO;
import br.edu.ifsp.medidacerta.enciclopedia.models.Dica;
import br.edu.ifsp.medidacerta.medida.models.Medida;

/**
 * Classe para c�lculo de IMC (�ndice de massa corp�rea)
 * 
 * @author Tiago
 * @author Kelvin
 */
public class IMC implements Medida, Serializable{
	public static final int ID_INDICE = 1;
	private Pessoa pessoa;
	private double valor;
	private Classificacao classificacao;

	/**
	 * Cria um novo c�lculo de IMC (�ndice de massa corp�rea) de uma pessoa
	 * 
	 * @param pessoa
	 */
	public IMC(Pessoa pessoa) {
		if (pessoa == null) {
			throw new UnsupportedOperationException("Usu�rio n�o definido");
		}
		this.pessoa = pessoa;
		recalcular();
	}

	/**
	 * Cria um novo c�lculo de IMC (�ndice de massa corp�rea) com valores de
	 * peso, altura, sexo e idade de uma pessoa
	 * 
	 * @param peso
	 *            O peso (em Kg) da pessoa
	 * @param altura
	 *            A altura (em m) da pessoa
	 * @param sexo
	 *            O sexo da pessoa
	 * @param idade
	 *            A idade (em anos) da pessoa
	 */
	public IMC(double peso, double altura, Sexo sexo, int idade) {
		if (sexo == null || sexo == Sexo.INDEFINIDO) {
			throw new UnsupportedOperationException(
					"O c�lculo de IMC depende do sexo.");
		}
		this.pessoa = new Pessoa();
		this.pessoa.setAltura(altura);
		this.pessoa.setPeso(peso);
		this.pessoa.setSexo(sexo);

		// "Artif�cio t�cnico" para setar a idade da pessoa:
		Date dataNascimento = new Date();
		dataNascimento.setYear(dataNascimento.getYear() - idade);
		this.pessoa.setDataNascimento(dataNascimento);

		recalcular();
	}

	/**
	 * Cria um novo c�lculo de IMC (�ndice de massa corp�rea) com valores de
	 * peso, altura, sexo e a data de nascimento de uma pessoa
	 * 
	 * @param peso
	 *            O peso (em Kg) da pessoa
	 * @param altura
	 *            A altura (em m) da pessoa
	 * @param sexo
	 *            O sexo da pessoa
	 * @param dataNascimento
	 *            A data de nascimento da pessoa
	 */
	public IMC(double peso, double altura, Sexo sexo, Date dataNascimento) {
		if (sexo == null || sexo == Sexo.INDEFINIDO) {
			throw new UnsupportedOperationException(
					"O c�lculo de IMC depende do sexo.");
		}
		this.pessoa = new Pessoa();
		this.pessoa.setAltura(altura);
		this.pessoa.setPeso(peso);
		this.pessoa.setSexo(sexo);
		this.pessoa.setDataNascimento(dataNascimento);
		recalcular();
	}

	/**
	 * Retorna a classifica��o do IMC
	 * 
	 * @return Classificacao
	 */
	public Classificacao getClassificacao() {
		return classificacao;
	}

	/**
	 * Retorna o valor do IMC
	 * 
	 * @return valor
	 */
	@Override
	public double getValor() {
		return valor;
	}

	/**
	 * M�todo que � invocado quando � preciso atualizar o valor do IMC
	 * 
	 * @author Kelvin
	 */
	private void recalcular() {
		valor = 1.3 * pessoa.getPeso() / Math.pow(pessoa.getAltura(), 2.5);
		classificacao = Classificacao.getClassificacao(this);
	}

	/**
	 * Retorna uma dica referente ao IMC
	 * 
	 * @return Uma String contendo dicas com base o IMC
	 */
	public String getDicas() {
		DicaDAO dao = new DicaDAO();
		StringBuilder dica = new StringBuilder();
		dica.append("N�o h� dicas dispon�veis.");
		List<Dica> dicas;
		try {
			dicas = dao.listPorClassificacao(this.getClassificacao().getObjetivo().getId(), this.getClassificacao().getId());
			if (dicas.size()>0) dica = new StringBuilder();
			for (Dica d : dicas){
				dica.append(d.getDica() +  "\n\n");
			}			
		} catch (Exception e) {
			dica.append("N�o h� dicas dispon�veis. Verifique se h� conex�o com a Internet.");
		}
		return dica.toString();
	}
	/**
	 * Retorna o sexo da pessoa que foi feita o IMC
	 * 
	 * @return o sexo da pessoa
	 */
	public Sexo getSexoDaPessoa() {
		return pessoa.getSexo();
	}

	@Override
	public String toString() {
		return String.valueOf(valor);
	}
	/**
	 * Retorna o peso m�nimo ideal do IMC da pessoa
	 * 
	 * @return O peso m�nimo ideal para o IMC da pessoa
	 */
	public double getMinPesoIdeal() {
		return (getClassificacao().getMinIdeal() * Math.pow(this.pessoa.getAltura(), 2.5d))/1.3d;
	}

	/**
	 * Retorna o peso m�ximo ideal do IMC da pessoa
	 * 
	 * @return O peso m�ximo ideal para o IMC da pessoa
	 */
	public double getMaxPesoIdeal() {
		return (getClassificacao().getMaxIdeal() * Math.pow(this.pessoa.getAltura(), 2.5d))/1.3d;
	}
	
	/**
	 * Retorna o m�nimo ideal do IMC da pessoa
	 * @see Classificacao.getMinIdeal()
	 * @return O valor m�nimo ideal para o IMC da pessoa
	 */
	public double getMinIdeal() {
		return getClassificacao().getMinIdeal();
	}

	/**
	 * Retorna o m�ximo ideal do IMC da pessoa
	 * @see Classificacao.getMaxIdeal()
	 * 
	 * @return O valor m�ximo ideal para o IMC da pessoa
	 */
	public double getMaxIdeal() {
		return getClassificacao().getMaxIdeal();
	}
	
	
	
	/**
	 * Classifica��o do IMC
	 * 
	 * @author Tiago
	 */
	public static enum Classificacao {


		MAGREZA_SEVERA(1, Objetivo.GANHAR_PESO,  R.string.m_classificacao_magreza_severa, Color.argb(255, 255, 0, 0)),

		MAGREZA_MODERADA(2, Objetivo.GANHAR_PESO,R.string.m_classificacao_magreza_moderada, Color.argb(255, 255, 174, 0)),

		MAGREZA_LEVE(3, Objetivo.GANHAR_PESO, R.string.m_classificacao_magreza_leve, Color.argb(255, 255, 226, 91)),

		SAUDAVEL(4, Objetivo.MANTER_PESO , R.string.m_classificacao_saudavel, Color.argb(255, 127, 127, 255)), // TODO: Alterar as cores

		SOBREPESO(5, Objetivo.PERDER_PESO, R.string.m_classificacao_sobrepeso, Color.argb(255, 255, 226, 91)),

		OBESIDADE(6,  Objetivo.PERDER_PESO, R.string.m_classificacao_obesidade, Color.argb(255, 255, 174, 0)),

		OBESIDADE_SEVERA(7,  Objetivo.PERDER_PESO, R.string.m_classificacao_obesidade_severa, Color.argb(255, 255, 91, 0)),

		OBESIDADE_MORBIDA(8, Objetivo.PERDER_PESO,  R.string.m_classificacao_obesidade_morbida, Color.argb(255, 255, 0, 0)),

		SEM_CLASSIFICACAO(0,  Objetivo.NENHUM , R.string.m_classificacao_sem_classificacao, Color.argb(255, 190, 190, 190));

		private int id;
		private int stringId;
		private int colorId;
		private Objetivo objetivo;
		private double minIdeal = 0;
		private double maxIdeal = 0;

		/**
		 * Retorna uma classifica��o baseando-se em um id pr�-definido
		 * 
		 * @param id
		 * @return Classificacao
		 */
		public static Classificacao valueOf(int id) {
			for (Classificacao c : values()) {
				if (c.id == id) {
					return c;
				}
			}
			return SEM_CLASSIFICACAO;
		}

		private Classificacao(int id, Objetivo objetivo, int stringId, int colorId) {
			this.id = id;
			this.stringId = stringId;
			this.colorId = colorId;
			this.objetivo = objetivo;
		}

		private static Classificacao getClassificacao(IMC imc) {
			Classificacao classificacao = Classificacao.SEM_CLASSIFICACAO;
			Integer idade = imc.pessoa.getIdade();
			Sexo sexo = imc.pessoa.getSexo();
			if (idade != null) {
				if (idade >= 18 && idade < 65) {
					classificacao = TabelaAdulto.getClassificacao(imc.valor);
					classificacao.maxIdeal = TabelaAdulto.SAUDAVEL_ADULTO
							.getValorMaximo();
					classificacao.minIdeal = TabelaAdulto.MAGREZA_LEVE_ADULTO
							.getValorMaximo();
				} else if (idade > 65) {
					classificacao = TabelaIdoso.getClassificacao(sexo,
							imc.valor);
					if (sexo == Sexo.MASCULINO) {
						classificacao.maxIdeal = TabelaIdoso.SAUDAVEL_MASCULINO
								.getValorMaximo();
						classificacao.minIdeal = TabelaIdoso.MAGREZA_LEVE_MASCULINO
								.getValorMaximo();
					} else if (sexo == Sexo.FEMININO) {
						classificacao.maxIdeal = TabelaIdoso.SAUDAVEL_FEMININO
								.getValorMaximo();
						classificacao.minIdeal = TabelaIdoso.MAGREZA_LEVE_FEMININO
								.getValorMaximo();
					}
				} else if (idade < 18) {
					TabelaInfantil itemClassInfantil = TabelaInfantil
							.parseValues(idade, sexo);
					if (itemClassInfantil != null) {
						classificacao = TabelaInfantil.getClassificacao(
								itemClassInfantil, imc.valor);
						classificacao.minIdeal = itemClassInfantil
								.getMinIdeal();
						classificacao.maxIdeal = itemClassInfantil
								.getMaxIdeal();
					}

				}
			}
			return classificacao;
		}

		/**
		 * Retorna o identificador
		 * 
		 * @return id O identificador do item da classifica��o
		 */
		public int getId() {
			return id;
		}

		/**
		 * Retorna o identificador da string na classe R
		 * 
		 * @return stringID O identificador
		 */
		public int getStringId() {
			return stringId;
		}
		/**
		 * Retorna o identificador da cor na classe R
		 * 
		 * @return colorID O identificador
		 */
		public int getColorId() {
			return colorId;
		}

		/**
		 * Retorna o m�nimo ideal do IMC da pessoa
		 * 
		 * @return O valor m�nimo ideal para o IMC da pessoa
		 */
		public double getMinIdeal() {
			return minIdeal;
		}

		/**
		 * Retorna o m�ximo ideal do IMC da pessoa
		 * 
		 * @return O valor m�ximo ideal para o IMC da pessoa
		 */
		public double getMaxIdeal() {
			return maxIdeal;
		}
		/**
		 * Retorna o objetivo equivalente
		 * 
		 * @return objetivo
		 */
		public Objetivo getObjetivo() {
			return objetivo;
		}
		
		
	}
	public int getImageDrawable(){
		if(pessoa.getSexo() == Sexo.MASCULINO){
			switch (getClassificacao().getId()){
			case 1: return R.drawable.imc_h_1;
			case 2: return R.drawable.imc_h_2;
			case 3: return R.drawable.imc_h_3;
			case 4: return R.drawable.imc_h_4;
			case 5: return R.drawable.imc_h_5;
			case 6: return R.drawable.imc_h_6;
			case 7: return R.drawable.imc_h_7;
			case 8: return R.drawable.imc_h_8;
			default: return R.drawable.imc_h_0;
			}
		} else if (pessoa.getSexo() == Sexo.FEMININO){
			switch (getClassificacao().getId()){
			case 1: return R.drawable.imc_m_1;
			case 2: return R.drawable.imc_m_2;
			case 3: return R.drawable.imc_m_3;
			case 4: return R.drawable.imc_m_4;
			case 5: return R.drawable.imc_m_5;
			case 6: return R.drawable.imc_m_6;
			case 7: return R.drawable.imc_m_7;
			case 8: return R.drawable.imc_m_8;
			default: return R.drawable.imc_m_0;
			}
		} else {
			return R.drawable.imc_h_0;
		}
	}
}
