package br.edu.ifsp.medidacerta.perfil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
//import java.sql.Date;
import java.util.Date;
import java.util.List;

import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.main.activity.TelaInicialActivity;
import br.edu.ifsp.medidacerta.main.activity.TestRedirectActivity;

import classe.CadastroBasico;
import classe.CadastroComplementar;
import classe.Usuario;
import classe.UsuarioLogado;
import dao.BasicoDAO;
import dao.MedidasDAO;
import dao.UsuarioDAO;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class P_ConsultarDados extends Activity {

    private Usuario cad = new Usuario();
	private List<Usuario> cadastro;
	private CadastroBasico cadBase;
	private CadastroComplementar cadComplementar;
	private BasicoDAO basicoDAO;
	private MedidasDAO medDAO;

	private TextView nome;
	private TextView email;
	private TextView data;
	private TextView sexo;
	private TextView altura;
	private TextView peso;
	private TextView Txobjetivo;
	
    @Override    
    public void onCreate(Bundle savedInstanceState) {
		
    	super.onCreate(savedInstanceState);
		setContentView(R.layout.p_consultardados);

		nome = (TextView) findViewById(R.id.p04_putMeta);
		email = (TextView) findViewById(R.id.p04_putCintura);
		data = (TextView) findViewById(R.id.p04_putQuadril);
		sexo = (TextView) findViewById(R.id.p04_putSexo);
		altura = (TextView) findViewById(R.id.p04_putAltura);
		peso = (TextView) findViewById(R.id.p04_putPeso);
		Txobjetivo = (TextView) findViewById(R.id.p04_putObjetivo);
	    try {
		cad = UsuarioLogado.getUsuarioLogado();
	    basicoDAO = new  BasicoDAO(getApplicationContext());
	    medDAO = new MedidasDAO(getApplicationContext());
	    cadBase = new CadastroBasico();
	    cadBase = basicoDAO.getByIDOrder(cad.getId());
	    cadComplementar = medDAO.getByID(cad.getId());
	    } catch (Exception x) {
	    	preencherDados2();
	    }
	    try {
	    preencherDados();
	    } catch(Exception x) {
	    	preencherDados2();
	    }
	    
	    Date data_dia = new Date();
	    String msgErro = "";
				
		if(cadBase != null){		
			long diff = data_dia.getTime() - cadBase.getData_atualizacao().getTime();	
			diff = (diff / (1000 * 60 * 60 * 24));
			if(diff > 30){
				msgErro = msgErro + "\n-Cadastro b�sico";				
			}
		}
		
		if(cadComplementar != null){		
			long diff = data_dia.getTime() - cadComplementar.getAtualizacao().getTime();	
			diff = (diff / (1000 * 60 * 60 * 24));
			if(diff > 30){
				msgErro =  msgErro + "\n-Cadastro complementar";				
			}
		}
		
		if (!msgErro.equalsIgnoreCase(""))
			exibirMensagem("H� informa��es n�o atualizadas a mais do que 30 dias."+msgErro);
	}

	/**
	 * Preencha os dados do usuario na tela
	 * @param 
	 * @return
	 */
    private void preencherDados() {
		
    	nome.setText(cad.getNome());
    	email.setText(cad.getEmail());
    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    	data.setText(sdf.format(cad.getDataNascimento()).toString());
    	if (cad.getSexo().toString().equalsIgnoreCase("M")) 
    		sexo.setText("Masculino");
    	else
    		sexo.setText("Feminino");
    	altura.setText(Float.toString(cadBase.getAltura()));
    	peso.setText(Float.toString(cadBase.getPeso()));
    	
    	if (cad.getObjetivo().getId()==1) {
    		Txobjetivo.setText("Ganhar Peso");
    	} else if (cad.getObjetivo().getId()==2) {
    		Txobjetivo.setText("Perder Peso");
    	} else if (cad.getObjetivo().getId()==3) {
    		Txobjetivo.setText("Manter Peso");
    	} else if (cad.getObjetivo().getId()==4) {
    		Txobjetivo.setText("Nenhum");
    	}	
	}
	/**
	 * Preencha os dados do usuario na tela caso n�o existe altura ou peso
	 * @param 
	 * @return
	 */
    private void preencherDados2() {
		try{
	    	nome.setText(cad.getNome());
	    	email.setText(cad.getEmail());
	    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	    	data.setText(sdf.format(cad.getDataNascimento()).toString());
	    	if (cad.getSexo().toString().equalsIgnoreCase("M")) 
	    		sexo.setText("Masculino");
	    	else
	    		sexo.setText("Feminino");
		}catch(Exception e){
			e.printStackTrace();
		}
    	
    	altura.setText("Sem altura");
    	peso.setText("Sem peso");
		Txobjetivo.setText("Sem Objetivo");	
	}
    
    public void mostrarAvancado(View v) {
    	Intent it = new Intent(getApplicationContext(), P_ConsultarAvancado.class);
    	startActivity(it);
    }
    
    public void menu(View v) {
    	Intent it = new Intent(getApplicationContext(), P_MenuPrincipal.class);
    	startActivity(it);
    }
    
    public void mudarEditar(View v) {
    	Intent it = new Intent(getApplicationContext(), P_CadastrarActivity.class);
    	startActivity(it);
    }
    
    public void irBasico(View v) {
    	Intent it = new Intent(getApplicationContext(), P_CadastroBasico.class);
    	startActivity(it);
    }
    
    public void irComplementar(View v) {
    	Intent it = new Intent(getApplicationContext(), P_CadastroComplementar.class);
    	startActivity(it);
    }
    
    private void exibirMensagem(String msg) {
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
	}
    
}
