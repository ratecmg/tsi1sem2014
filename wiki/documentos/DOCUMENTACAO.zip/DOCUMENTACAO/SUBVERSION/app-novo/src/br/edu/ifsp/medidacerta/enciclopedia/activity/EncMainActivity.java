package br.edu.ifsp.medidacerta.enciclopedia.activity;

import br.edu.ifsp.medidacerta.R;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;

/** Classe utilizada para exibir os botões de redirecionamento para outras funções

* do módulo de enciclopédia.

*/

public class EncMainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_enc_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_enc_main, menu);
		return true;
	}
	
/**Método que implementa a função - android:onclick - do botão - abrir dicas de nutrição - 

*/

    public void abrir_dc_nutricao(View v) {
    	Intent intent = new Intent(this, EncAlertaActivity.class);
    	
        Bundle params = new Bundle();
        Integer tela = 1;
        params.putInt("tela", tela);
        intent.putExtras(params);
    	
    	startActivity(intent);
	}

/**Método que implementa a função - android:onclick - do botão - abrir dicas de atividades - 

*/
    
    public void abrir_dc_atividade(View v) {
    	Intent intent = new Intent(this, EncAlertaActivity.class);
    	    	
        Bundle params = new Bundle();
        Integer tela = 2;
        params.putInt("tela", tela);
        intent.putExtras(params);
    	    	
    	startActivity(intent);
	}

/**Método que implementa a função - android:onclick - do botão - abrir questionário - 

*/	
 
    public void abrir_questionario(View v) {
    	Intent intent = new Intent(this, EncQuestionarioActivity.class);
    	startActivity(intent);
	}

}
