package br.edu.ifsp.medidacerta.perfil;


import java.util.Date;

import classe.CadastroComplementar;
import classe.Usuario;
import classe.UsuarioLogado;
import br.edu.ifsp.medidacerta.R;
import dao.MedidasDAO;
import dao.UsuarioDAO;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
//import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class P_CadastroComplementar extends Activity {
	
	
	private CadastroComplementar m;
	private Usuario u;
	private MedidasDAO dao;
	private UsuarioDAO u_dao;
	private EditText edPressao;
	private EditText edFrequencia;
	private EditText edQuadril;
	private EditText edCircunferencia;
	private Integer id = 0;
	private String operacao;
	
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_complementar);
		//Button bvoltar = (Button) findViewById(R.id.btnVoltar);
		//bvoltar.setOnClickListener (new View.OnClickListener() {
		//public void voltar(View v) {
		//setContentView(R.layout."layout Perfil");
		// }
		//});
		edCircunferencia = (EditText) findViewById(R.id.edCircunferencia);
		edQuadril = (EditText) findViewById(R.id.edQuadril);
		edFrequencia = (EditText) findViewById(R.id.edFrequencia);
		edPressao = (EditText) findViewById(R.id.edPressao);
	
		
		dao = new MedidasDAO(getApplicationContext());
		
		u_dao = new UsuarioDAO(getApplicationContext());
		u = UsuarioLogado.getUsuarioLogado();
		id = u.getId();
		
		operacao = new String ("salvar");
		
	}
	
	
	
	
	public void salvar(View v) {
		
	
		
		
		
		if (operacao.equalsIgnoreCase("salvar")) {
			m = new CadastroComplementar();
		}
		
		if (edCircunferencia.getText().toString().equalsIgnoreCase("") ||
				edQuadril.getText().toString().equalsIgnoreCase("") ||
				edFrequencia.getText().toString().equalsIgnoreCase("") ||
				edPressao.getText().toString().equalsIgnoreCase("")) {
			
			exibirMensagem("Informe os dados!");
	} 
	else { 
		m.setId_usuario(id);
		m.setCircunferencia(Double.valueOf(edCircunferencia.getText().toString())); 
		m.setQuadril(Double.valueOf(edQuadril.getText().toString()));
		m.setFrequencia(Double.valueOf(edFrequencia.getText().toString()));
		m.setPressao(edPressao.getText().toString());
		m.setAtualizacao( new Date());
		

		if (operacao.equalsIgnoreCase("salvar")) {
			dao.salvar(m);
			u_dao.atualizar(u);
			exibirMensagem("Medidas cadastradas com sucesso!");
			Intent it = new Intent(getApplicationContext(), P_ConsultarAvancado.class);
			startActivity(it);
		} //else {
			//dao.atualizar(m);
			//exibirMensagem("Medidas atualizadas com sucesso!");
		//}

		limparDados();
	}
	}
	
	
	
	private void limparDados() {
		
		edCircunferencia.setText("");
		edQuadril.setText("");
		edFrequencia.setText("");
		edPressao.setText("");
		edCircunferencia.requestFocus();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	
	private void exibirMensagem(String msg) {
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
	}
	
	public void voltar(View v) {
    	Intent it = new Intent(getApplicationContext(), P_ConsultarDados.class);
    	startActivity(it);
    }

}
