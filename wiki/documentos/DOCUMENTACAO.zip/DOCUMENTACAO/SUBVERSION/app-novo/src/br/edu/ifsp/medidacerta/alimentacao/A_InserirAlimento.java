package br.edu.ifsp.medidacerta.alimentacao;

import java.util.Calendar;
import java.util.List;

import classe.Alimento;
import classe.GrupoAlimento;
import dao.AlimentoDAO;
import dao.GrupoAlimentoDAO;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.R.layout;
import br.edu.ifsp.medidacerta.R.menu;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class A_InserirAlimento extends Activity {

	private Spinner spGrupo;
	private String[] gpAlimentos;
	private EditText etNomeAlimento;
	private EditText etDescAlimento;
	private EditText etCalPorcao;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_a_inserir_alimento);
		spGrupo = (Spinner) findViewById(R.id.spGpAlimento);
		etNomeAlimento = (EditText) findViewById(R.id.etNomeAlimento);
		etDescAlimento = (EditText) findViewById(R.id.etDescAlimento);
		etCalPorcao = (EditText) findViewById(R.id.etCalPorcao);
		String[] bla = preencherArrayString();
		exibirMensagem(bla[1]);
		gpAlimentos = preencherArrayString();
		preencherGrupoAlimentos();

	}

	
	/**
	 * Prenche o dropdown com o grupos de alimento
	 */
	private void preencherGrupoAlimentos() {
		try {
			ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
					android.R.layout.simple_list_item_1, gpAlimentos);
			adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spGrupo.setAdapter(adapter);
		} catch (Exception ex) {
			exibirMensagem("Erro: " + ex.getMessage());
		}

	}

	private String[] preencherArrayString() {
		GrupoAlimentoDAO dao = new GrupoAlimentoDAO(getApplicationContext());
		List<GrupoAlimento> gp = dao.listAll();
		String s[] = new String[gp.size()];

		for (int x = 0; x < gp.size(); x++) {
			s[x] = gp.get(x).getGrupoAlimento();
		}

		return s;
	}

	private void exibirMensagem(String msg) {
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
	}

	/**
	 * M�todo para salvar um alimento
	 */
	public void salvar(View v) {
		Alimento a = new Alimento();
		try {
			a.setAlimento(etNomeAlimento.getText().toString());
			a.setDescricao(etDescAlimento.getText().toString());
			a.setCaloriaPorcao(etCalPorcao.getText().toString());
			a.setDataAtualizacao(Calendar.getInstance().getTime());
			a.setFigura("");
			a.setOrigem("LOCAL");
			GrupoAlimentoDAO daoC = new GrupoAlimentoDAO(getApplicationContext());
			List<GrupoAlimento> gruposAlimentares = daoC.listAll();
			
			int pos = spGrupo.getSelectedItemPosition();
			for (GrupoAlimento grupoAlimento : gruposAlimentares) {
				if(grupoAlimento.getIdGrupoAlimentos()==(pos+1)){
					a.setGrupoAlimento(grupoAlimento);
					
				}
			}
			AlimentoDAO daoA = new AlimentoDAO(getApplicationContext());
			daoA.salvar(a);
			Toast.makeText(v.getContext(), "Alimento cadastrado", Toast.LENGTH_LONG).show();
		} catch (Exception e) {
			// TODO: handle exception
			Toast.makeText(v.getContext(), "Erro ao salvar alimento "+e.getMessage(), Toast.LENGTH_LONG).show();
		}
	}

}
