/*
 * Equipe de Medidas
 * 
 */
package br.edu.ifsp.medidacerta.medida.models.ico;

import java.io.Serializable;
import java.util.List;

import classe.Objetivo;
import classe.Pessoa;
import android.graphics.Color;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.enciclopedia.dao.DicaDAO;
import br.edu.ifsp.medidacerta.enciclopedia.models.Dica;
import br.edu.ifsp.medidacerta.medida.models.Medida;



/**
 * Classe para c�lculo do �ndice de conicidade
 * @author Tiago
 */
public class ICO implements Medida, Serializable {
	
	public static final int ID_INDICE = 2;
	private double valor;
    private Pessoa pessoa;

    /**
     * Calcula o �ndice de conicidade, informando o peso, altura e circunfer�ncia da
     * cintura de uma pessoa.
     * @param altura A altura (em m) da pessoa
     * @param peso O peso (em Kg) da pessoa
     * @param circunferenciaCintura A circunfer�ncia da cintura da pessoa
     */
    public ICO(double altura, double peso, double circunferenciaCintura) {
        this.pessoa = new Pessoa();
        this.pessoa.setAltura(altura);
        this.pessoa.setPeso(peso);
        this.pessoa.setCircunferenciaCintura(circunferenciaCintura);    
        if (pessoa.getCircunferenciaCintura() == null) {
            throw new UnsupportedOperationException("C�lculo de ICO n�o dispon�vel "
                    + "quando n�o h� o valor da circunfer�ncia da cintura.");
        }
        recalcular();
    }

    /**
     * Calcula o �ndice de conicidade, informando a pessoa que deseja obter o c�lculo 
     * @param pessoa Pessoa a se obter o ICO
     * @throws Exception Ir� gerar uma exce��o caso n�o haja o valor da circunfer�ncia 
     * da pessoa
     */
    public ICO(Pessoa pessoa) {
    	if (pessoa == null) {
			throw new UnsupportedOperationException("Usu�rio n�o definido");

		}
		this.pessoa = pessoa;
        if (pessoa.getCircunferenciaCintura() == null) {
            throw new UnsupportedOperationException("C�lculo de ICO n�o dispon�vel "
                    + "quando n�o h� o valor da circunfer�ncia da cintura.");
        }
        recalcular();
    }

    /**
     * M�todo que � invocado quando � preciso atualizar o valor do ICO
     * @author Kelvin
     */
    private void recalcular() {
        valor = (pessoa.getCircunferenciaCintura()/100) / (0.109 * (Math.sqrt(pessoa.getPeso()) / pessoa.getAltura()));
    }

    /**
     * M�todo para obter o valor do �ndice
     * @return O valor do �ndice de conicidade
     */
    @Override
    public double getValor() {
        recalcular();
        return valor;
    }

    @Override
    public String toString() {
        recalcular();
        return String.valueOf(valor);

    }
    
    
    public Classificacao getClassificacao(){    	
    	if(this.valor <=1){
    		return Classificacao.RISCO_BAIXO;
    	} else if(this.valor > 1 && this.valor <= 1.63d){
    		return Classificacao.RISCO_MEDIO;
    	} else {
    		return Classificacao.RISCO_ALTO;
    	}
    }
    public String getDicas() {
		DicaDAO dao = new DicaDAO();
		StringBuilder dica = new StringBuilder();
		dica.append("N�o h� dicas dispon�veis.");
		List<Dica> dicas;
		try {
			dicas = dao.listPorClassificacao(this.getClassificacao().getObjetivo().getId(), this.getClassificacao().getId());
			if (dicas.size()>0) dica = new StringBuilder();
			for (Dica d : dicas){
				dica.append(d.getDica() +  "\n\n");
			}			
		} catch (Exception e) {
			dica.append("N�o h� dicas dispon�veis. Verifique se h� conex�o com a Internet.");
		}
		return dica.toString();
	}
    public static enum Classificacao{
    	RISCO_BAIXO (4, 0 , 1, Color.argb(255, 204, 204, 255), R.string.m_classificacao_risco_baixo, Objetivo.MANTER_PESO),
    	RISCO_MEDIO (5, 1.02d ,1.63d, Color.argb(255, 255, 255, 000), R.string.m_classificacao_risco_medio, Objetivo.PERDER_PESO),
    	RISCO_ALTO  (6, 1.64d ,1.73, Color.argb(255, 255, 000, 000), R.string.m_classificacao_risco_alto, Objetivo.PERDER_PESO);
    	private int id;
    	private double min;
    	private double max;
    	private int cor;
    	private int stringId;
    	private Objetivo objetivo;
    	private Classificacao(int id,double min, double max, int cor, int stringId, Objetivo objetivo){
    		this.min = min;
    		this.max = max;
    		this.cor = cor;
    		this.stringId = stringId;
    		this.objetivo = objetivo;
    	}
    	
    	public int getId() {
			return id;
		}

		/**
		 * Retorna o identificador da cor na classe R
		 * 
		 * @return colorID O identificador
		 */
		public int getColorId() {
			return cor;
		}
		/**
		 * Retorna o identificador da string na classe R
		 * 
		 * @return stringID O identificador
		 */
		public int getStringId() {
			return stringId;
		}
		
		public Objetivo getObjetivo(){
    		return objetivo;
    	}
		
    }
    
    
}
