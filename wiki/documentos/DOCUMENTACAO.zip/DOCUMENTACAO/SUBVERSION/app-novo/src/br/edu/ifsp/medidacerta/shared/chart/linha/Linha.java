package br.edu.ifsp.medidacerta.shared.chart.linha;

import java.util.ArrayList;
import java.util.List;

import org.achartengine.chart.PointStyle;

import android.graphics.Point;

public class Linha {

	public List<Point> listPontos = new ArrayList<Point>();
	public PointStyle tipoPonto;
	public int cor;
	
	public int getCor() {
		return cor;
	}
	public void setCor(int cor) {
		this.cor = cor;
	}
	public String nome;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void addPonto(Point p){
		listPontos.add(p);
	}
	public List<Point> getListaPontos(){
		return listPontos;
	}
	public PointStyle getTipoPonto() {
		return tipoPonto;
	}
	public void setTipoPonto(PointStyle tipoPonto) {
		this.tipoPonto = tipoPonto;
	}
	
	
	
}
