package br.edu.ifsp.medidacerta.alimentacao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TimePicker;
import android.widget.Toast;
import br.edu.ifsp.medidacerta.R;
import classe.Alimento;
import classe.ConsumoDiario;
import classe.Usuario;
import classe.UsuarioLogado;
import dao.ConsumoDAO;

public class P_CadastroConsumo extends Activity {

	private static final int DATE_ = 0;
	private static final int HORA_ = 1;
	private Calendar dataConsumo;
	private EditText edAlimentoConsumido;
	private EditText edQuantidade;
	private Button bDataConsumo;
	private Button bHoraConsumo;
	private DateFormat formataData;
	private DateFormat formataHora;
	private ImageButton btnSearchAlimento;
	
	Alimento a;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//getMenuInflater().inflate(R.menu.p__cadastro_consumo, menu);
		return true;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.a_p_cadastro_consumo);
		edAlimentoConsumido = (EditText) findViewById(R.id.edAlimentoConsumido);
		edQuantidade = (EditText) findViewById(R.id.edQuantidade);
		
		formataData = new SimpleDateFormat("dd/MM/yyyy");
		formataHora = new SimpleDateFormat("HH:mm");
		bDataConsumo = (Button) findViewById(R.id.bDataConsumo);
		bHoraConsumo = (Button) findViewById(R.id.bHoraConsumo);
		
		InicializaCalendario();
		
		btnSearchAlimento = (ImageButton) findViewById( R.id.btnSearchAlimento );
		
		btnSearchAlimento.setOnClickListener( new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent( getApplicationContext(), A_ListaAlimentos.class );
				intent.putExtra( "retorno", true );
				startActivityForResult( intent, 1 );
			}
		} );
		
		
	}
	
	public void onActivityResult( int requestCode, int resultCode, Intent data ) {
		
		a = (Alimento) data.getExtras().get( "alimento" ); 
		edAlimentoConsumido.setText(a.getAlimento() + a.getDescricao());
		//Toast.makeText( getApplicationContext(), a.getAlimento(), Toast.LENGTH_LONG ).show();
		
	}
	
	/**
	 * Inicializa o calendario com a data e hora atual
	 */
	private void InicializaCalendario() {
		dataConsumo = Calendar.getInstance();
		AtualizaBtnData();
	}
	
	/**
	 * M�todo para atualizar o texto dos bot�es de data
	 */
	private void AtualizaBtnData() {
		bDataConsumo.setText(formataData.format(dataConsumo.getTime()));
		bHoraConsumo.setText(formataHora.format(dataConsumo.getTime()));
	}
	
	/**
	 * M�todo para setar uma data
	 */
	public void definirData(View v) {
		showDialog(DATE_);
	}
	
	/**
	 * M�todo para setar uma hora
	 */
	public void definirHora(View v) {
		showDialog(HORA_);
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DATE_:
			return new DatePickerDialog(this, DateSetListener,
					dataConsumo.get(Calendar.YEAR),
					dataConsumo.get(Calendar.MONTH),
					dataConsumo.get(Calendar.DAY_OF_MONTH));

		case HORA_:
			return new TimePickerDialog(this, HoraSetListener,
					dataConsumo.get(Calendar.HOUR_OF_DAY),
					dataConsumo.get(Calendar.MINUTE),
					true);
		}
		return null;

	}
	
	/**
	 * M�todo para finalizar a execu��o da activity
	 */
	public void finish(View v) {
		finish();
	}
	
	/**
	 * M�todo para cadastrar um novo consumo di�rio
	 */
	public void cadastrar(View v) {
		ConsumoDAO daoC = new ConsumoDAO(v.getContext());
		ConsumoDiario c = new ConsumoDiario();
		
		c.setUsuario(UsuarioLogado.getUsuarioLogado());
		//pog ate funcionar o pegar do usuario
/*		Usuario u = new Usuario();
		u.setId(1);
		c.setUsuario(u);*/

		
		c.setAlimentoConsumido(a);

		Float quantidadePorcoes = Float.parseFloat((edQuantidade.getText().toString()));
		c.setQuantidadeEmPorcoes(quantidadePorcoes);
		c.setDataHoraConsumo(dataConsumo.getTime());
		daoC.salvar(c);
		finish();
		Toast.makeText(v.getContext(), "Consumo cadastrado com sucesso!", Toast.LENGTH_LONG).show();
	}
	
	private DatePickerDialog.OnDateSetListener DateSetListener = new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			dataConsumo.set(Calendar.DAY_OF_MONTH, dayOfMonth);
			dataConsumo.set(Calendar.MONTH, monthOfYear);
			dataConsumo.set(Calendar.YEAR, year);
			AtualizaBtnData();
		}
	};
	
	private TimePickerDialog.OnTimeSetListener HoraSetListener = new TimePickerDialog.OnTimeSetListener() {
		@Override
		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
			// TODO Auto-generated method stub
			dataConsumo.set(Calendar.HOUR_OF_DAY, hourOfDay);
			dataConsumo.set(Calendar.MINUTE, minute);
			AtualizaBtnData();
		}
	};
}
