package br.edu.ifsp.medidacerta.main.activity;

import java.io.IOException;
import java.util.Date;

import classe.*;

import dao.DAO;
import android.app.Activity;
import android.content.Intent;
import android.database.SQLException;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.alimentacao.P_MenuAlimentacao;
import br.edu.ifsp.medidacerta.enciclopedia.activity.EncMainActivity;
import br.edu.ifsp.medidacerta.medida.activity.MedidasPrincipalActivity;
import br.edu.ifsp.medidacerta.medida.dao.UsuarioDAO;
import br.edu.ifsp.medidacerta.perfil.P_AutenticacaoActivity;

public class TestRedirectActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_test_redirect);
	}

	public void abrirAlimentacao(View v) {
		Usuario u = UsuarioLogado.getUsuarioLogado();
		if (u == null) {
			Toast.makeText(getApplicationContext(), "Logue antes de entrar.",
					Toast.LENGTH_LONG).show();
		} else {
			Intent intent = new Intent(this, P_MenuAlimentacao.class);
			startActivity(intent);
		}
	}

	public void abrirPerfil(View v) {
		Intent intent = new Intent(this, P_AutenticacaoActivity.class);
		startActivity(intent);
	}

	public void abrirMedida(View v) {

		br.edu.ifsp.medidacerta.medida.dao.UsuarioDAO d;
		Usuario u;

		// u = new Usuario();
		// u.setNome("Usu�rio teste");
		// u.setAltura(1.80d);
		// u.setPeso(80d);
		// u.setCircunferenciaCintura(99d);
		// u.setCircunferenciaQuadril(101d);
		// u.setDataNascimento(new Date(88, 1, 1));
		// u.setSexo(Sexo.MASCULINO);
		// UsuarioLogado.setUsuarioLogado(u);
		// u.incomplete = false;
		// d = new
		// br.edu.ifsp.medidacerta.medida.dao.UsuarioDAO(getApplicationContext());

		u = UsuarioLogado.getUsuarioLogado();
		if (u == null) {
			Toast.makeText(getApplicationContext(), "Logue antes de entrar.",
					Toast.LENGTH_LONG).show();
		} else {
			// for (int i = 0; i < 28 ; i++){
			// u.setPeso(80d + (Math.random() * 3));
			// d = new
			// br.edu.ifsp.medidacerta.medida.dao.UsuarioDAO(getApplicationContext());
			// d.atualizarMedidas(u, new Date(113, 10, i));
			// d.close();
			// }
			Intent intent = new Intent(this, MedidasPrincipalActivity.class);
			startActivity(intent);
		}
	}

	public void abrirEnciclopedia(View v) {
		Intent intent = new Intent(this, EncMainActivity.class);
		startActivity(intent);
	}

}
