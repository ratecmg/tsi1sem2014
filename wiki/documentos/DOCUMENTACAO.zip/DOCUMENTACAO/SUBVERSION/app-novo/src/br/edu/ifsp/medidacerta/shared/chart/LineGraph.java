package br.edu.ifsp.medidacerta.shared.chart;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.TimeSeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import br.edu.ifsp.medidacerta.UtilHelper;
import dao.ConsumoDAO;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.widget.Toast;
import classe.ConsumoDiario;
import classe.DataCaloriaGrafico;

public class LineGraph {
	
	XYMultipleSeriesRenderer sRenderer = new XYMultipleSeriesRenderer();
	
	public Calendar dataInicio;
	public Calendar dataFim;
	
	public Intent getIntent( Context context )
	{
		
		ConsumoDAO cdao = new ConsumoDAO( context );
		
		List<DataCaloriaGrafico> listConsumo;
		
		listConsumo = cdao.getListConsumoByDateInicioAndDateFim( dataInicio, dataFim );
		
		if ( listConsumo != null )
		{
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM");
			
			TimeSeries series = new TimeSeries( "Caloria di�ria" );
			
			int size = listConsumo.size() - 1;
			int count = 1;
			
			for ( int i = 0; i < listConsumo.size(); i++ )
			{
				DataCaloriaGrafico dcg = listConsumo.get( i );
				
				Date dataTemp;
				
				if ( i != size )
				{
					
					DataCaloriaGrafico dcgTemp = listConsumo.get( i + 1 );
					
					series.add( dcg.getData().getDay(), dcg.getQtdCaloria() );
					
					sRenderer.addXTextLabel( count, sdf.format( dcg.getData() ) );
					
					count++;
					
					dataTemp = UtilHelper.addDay( dcg.getData(), 1 );
					
					while( !dcgTemp.getData().equals( dataTemp ) )
					{
						
						series.add( dataTemp.getDay(), dcg.getQtdCaloria() );
						
						sRenderer.addXTextLabel( count, sdf.format( dataTemp ) );
						
						count++;
						
						dataTemp = UtilHelper.addDay( dataTemp, 1 );
						
					}
					
				}
				else
				{
					series.add( dcg.getData().getDay(), dcg.getQtdCaloria() );
					sRenderer.addXTextLabel( count, sdf.format( dcg.getData() ) );
				}
				
			}
			
			XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
			dataset.addSeries( series );
			
			XYSeriesRenderer renderer = new XYSeriesRenderer();
			renderer.setColor( Color.GREEN );
			renderer.setPointStyle( PointStyle.SQUARE );
			renderer.setFillPoints( true );
			
			sRenderer.setChartTitle( "Gr�fico de consumo di�rio" );
			sRenderer.setBackgroundColor( Color.BLACK );
			sRenderer.setApplyBackgroundColor( true );
			sRenderer.setShowGrid( true );
			sRenderer.addSeriesRenderer( renderer );
			
			sRenderer.setXLabels(0);
			
			Intent intent = ChartFactory.getLineChartIntent( context, dataset, sRenderer, "Gr�fico de consumo di�rio" );
			
			return intent;
			
		}
		else
		{
			return null;
		}
		
	}
	
}
