package br.edu.ifsp.medidacerta.medida.activity;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.enciclopedia.dao.DicaDAO;
import br.edu.ifsp.medidacerta.enciclopedia.models.Dica;
import br.edu.ifsp.medidacerta.medida.models.rcq.RCQ;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.view.Menu;
import android.widget.TextView;



public class CalculoRCQActivity extends Activity {
	private TextView lblValorRCQ;
	private TextView lblDica;
	private TextView lblValorClassificacao;
	DicaDAO dica_dao = new DicaDAO();
	List<Dica> listAll = new ArrayList<Dica>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_m_calculo_rcq);		
		lblValorRCQ = (TextView) findViewById(R.id.valor_rcq);
		lblDica   = (TextView) findViewById(R.id.m_activity_calculo_ico_dica);
		lblValorClassificacao = (TextView) findViewById(R.id.m_activity_calculo_rcq_valor_classificacao);		
		RCQ rcq = (RCQ) getIntent().getSerializableExtra("rcq");
		showRCQ(rcq);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return true;
	}
	private void updateDicaHandler(Message msg) {
		lblDica.setText((CharSequence) msg.obj);
	}
	public void showRCQ(final RCQ rcq) {

		DecimalFormat fmt = new DecimalFormat("0.00");
		if (rcq != null){

			try {
				
				/**
				 *  ***********************************************************
				 *    Thread para carregamento das dicas
				 *  ***********************************************************
				 */
				final Handler dicaHandler = new Handler() {
					@Override
					public void handleMessage(android.os.Message msg) {
						updateDicaHandler(msg);
					}

				};
				Runnable r = new Runnable() {
					@Override
					public void run() {
						try {
							Message msg = new Message();
							msg.obj = rcq.getDicas();						
							dicaHandler.sendMessage(msg);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				};
				new Thread(r).start();
				// **************************************************************
				lblValorRCQ.setText(String.valueOf(fmt.format(rcq.getValor())));
				lblValorRCQ.setBackgroundColor(rcq.getClassificacao().getColorId());			
				System.out.println("Classificacao:" + rcq.getClassificacao().getStringId());
				lblDica.setText(getString(R.string.m_carregando_dicas));				
				lblValorClassificacao.setText(getString(rcq.getClassificacao().getStringId()).toUpperCase());
				
			}catch (Exception ex) {

			}

			
		}
		
		
		

	}

}
