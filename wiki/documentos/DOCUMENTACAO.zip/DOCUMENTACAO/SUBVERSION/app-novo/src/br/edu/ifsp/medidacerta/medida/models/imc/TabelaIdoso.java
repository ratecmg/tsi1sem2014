/*
 * Equipe de Medidas
 * 
 */
package br.edu.ifsp.medidacerta.medida.models.imc;

import classe.Sexo;



enum TabelaIdoso {
    MAGREZA_LEVE_FEMININO(IMC.Classificacao.MAGREZA_LEVE,Sexo.FEMININO, 22),
    SAUDAVEL_FEMININO(IMC.Classificacao.SAUDAVEL,Sexo.FEMININO, 27),
    SOBREPESO_FEMININO(IMC.Classificacao.SOBREPESO,Sexo.FEMININO, 32),
    OBESIDADE_FEMININO(IMC.Classificacao.OBESIDADE,Sexo.FEMININO, 37),
    OBESIDADE_SEVERA_FEMININO(IMC.Classificacao.OBESIDADE_SEVERA,Sexo.FEMININO, 42),
    OBESIDADE_MORBIDA_FEMININO(IMC.Classificacao.OBESIDADE_MORBIDA,Sexo.FEMININO, 100),
    MAGREZA_LEVE_MASCULINO(IMC.Classificacao.MAGREZA_LEVE,Sexo.MASCULINO, 22),
    SAUDAVEL_MASCULINO(IMC.Classificacao.SAUDAVEL, Sexo.MASCULINO,27),
    SOBREPESO_MASCULINO(IMC.Classificacao.SOBREPESO,Sexo.MASCULINO, 30),
    OBESIDADE_MASCULINO(IMC.Classificacao.OBESIDADE, Sexo.MASCULINO,35),
    OBESIDADE_SEVERA_MASCULINO(IMC.Classificacao.OBESIDADE_SEVERA,Sexo.MASCULINO, 40),
    OBESIDADE_MORBIDA_MASCULINO(IMC.Classificacao.OBESIDADE_MORBIDA,Sexo.MASCULINO, 100),
    SEM_CLASSIFICACAO(IMC.Classificacao.SEM_CLASSIFICACAO,Sexo.INDEFINIDO, 0);
    
    private double valorMaximo;
    private IMC.Classificacao id;
    private Sexo sexo;

    private TabelaIdoso(IMC.Classificacao id, Sexo sexo, double valorMaximoIMC) {
        this.valorMaximo = valorMaximoIMC;
        this.id = id;
        this.sexo = sexo;
    }
    static IMC.Classificacao getClassificacao(Sexo sexo, double valorIMC) {
        for (TabelaIdoso t : values()) {
            if ((valorIMC < t.valorMaximo) && (t.sexo == sexo)) {
                return t.id;
            }
        }
        return IMC.Classificacao.SEM_CLASSIFICACAO;
    }

    double getValorMaximo() {
        return valorMaximo;
    }
    
}