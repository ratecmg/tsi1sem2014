package br.edu.ifsp.medidacerta.main.activity;

import java.io.IOException;

import dao.DAO;
import android.app.Activity;
import android.content.Intent;
import android.database.SQLException;
import android.os.Bundle;
import android.os.Handler;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.perfil.P_AutenticacaoActivity;

public class TelaInicialActivity extends Activity {
    private static int SPLASH_TIME_OUT = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_tela_inicial);
	
	DAO myDbHelper;
	myDbHelper = new DAO(this);

	try {
		myDbHelper.createDataBase();
	} catch (IOException ioe) {
		throw new Error("N�o foi poss�vel criar o banco de dados.");
	}

	try {
		myDbHelper.openDataBase();
	} catch (SQLException sqle) {
		sqle.printStackTrace();
	}
	
	new Handler().postDelayed(new Runnable() {
	    @Override
	    public void run() {	
		Intent intent = new Intent(TelaInicialActivity.this, P_AutenticacaoActivity.class);
		startActivity(intent);		
		finish();
	    }
	}, SPLASH_TIME_OUT);
    }

    

}
