package br.edu.ifsp.medidacerta.alimentacao.graphs;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.achartengine.chart.BarChart;

import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.UtilHelper;
import br.edu.ifsp.medidacerta.R.layout;
import br.edu.ifsp.medidacerta.R.menu;
import br.edu.ifsp.medidacerta.shared.chart.BarGraph;
import br.edu.ifsp.medidacerta.shared.chart.LineGraph;
import br.edu.ifsp.medidacerta.shared.chart.PieGraph;
import br.edu.ifsp.medidacerta.shared.chart.ScatterGraph;
import android.os.Bundle;
import android.preference.DialogPreference;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.Toast;

public class AlimentacaoMenuGraphActivity extends Activity {
	
	private static final int DATE_INICIO_ = 0;
	private static final int DATE_FIM_ = 1;
	
	Button btnLineChart = null;
	Button btnBarChart = null;
	Button btnScatterChart = null;
	Button btnPieChart = null;
	
	Button btnInicioData;
	Button btnFimData;
	Button btnViewGraph;
	
	Calendar InicioData;
	Calendar FimData;
	
	private String[] tipoGrafico = { "Linha", "Barra" };
	
	private Spinner spnTipoGrafico;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_alimentacao_menu_graph);
		
		btnInicioData = ( Button ) findViewById( R.id.btnDataInicioGraficoConsumo );
		
		//SETTAR CHAMADA DE FUN��O PARA ALTERAR A DATA DE INICIO DO GR�FICO
		btnInicioData.setOnClickListener( new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				showDialog( DATE_INICIO_ );
			}
		} );
		
		btnFimData = ( Button ) findViewById( R.id.btnDataFimGraficoConsumo );
		
		//SETTAR CHAMADA DE FUN��O PARA ALTERAR A DATA DE INICIO DO GR�FICO
		btnFimData.setOnClickListener( new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				showDialog( DATE_FIM_ );
			}
		} );
		
		/**
		 * CONVERS�O DE DATA PARA CALENDAR
		 */
		InicioData = convertDateToCalendarAndFormmatDate( new Date() );
		
		/**
		 * CONVERS�O DE DATA PARA CALENDAR
		 */
		FimData = convertDateToCalendarAndFormmatDate( new Date() );
		
		//FUN��O PARA COLOCAR A DATA NO BOT�O
		atualizaBtnInicioData();
		//FUN��O PARA COLOCAR A DATA NO BOT�O
		atualizaBtnFimData();
		
		spnTipoGrafico = ( Spinner ) findViewById( R.id.spnTipoGrafico );
		
		setTypesOfGraph();
		
		btnViewGraph = ( Button ) findViewById( R.id.btnViewGraph );
		
		btnViewGraph.setOnClickListener( new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				long diff = InicioData.getTimeInMillis() - FimData.getTimeInMillis();

	            float dayCount = (float) diff / (24 * 60 * 60 * 1000);
				
	            if ( dayCount > 0 )
	            {
	            	Toast.makeText( getApplicationContext(), "A data inicial deve ser menor que a data final", Toast.LENGTH_LONG ).show();
	            }
	            else
	            {
	            	
					String typeGraph = tipoGrafico[ spnTipoGrafico.getSelectedItemPosition() ];
					
					Intent intent = null;
					
					if ( typeGraph.equalsIgnoreCase( "linha" ) )
					{
						LineGraph line = new LineGraph();
						
						line.dataInicio = InicioData;
						line.dataFim = FimData;
						
						intent = line.getIntent( getApplicationContext() );
						
					}
					else if ( typeGraph.equalsIgnoreCase( "barra" ) )
					{
						BarGraph bar = new BarGraph();
						
						bar.dataInicio = InicioData;
						bar.dataFim = FimData;
						
						intent = bar.getIntent( getApplicationContext() );					
						
					}
					
					if ( intent != null )
					{
						startActivity( intent );
					}
					else
					{
						Toast.makeText( getApplicationContext(), "N�o h� dados no per�odo escolhido", Toast.LENGTH_LONG ).show();
					}

	            }
				
			}
		} );
		
	}
	
	private void setTypesOfGraph() {
		try {
			
			ArrayAdapter<String> adapter = new ArrayAdapter<String>( this, android.R.layout.simple_list_item_1, tipoGrafico );
			adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
			spnTipoGrafico.setAdapter( adapter );
			
		} catch (Exception ex) {
			
			Log.d( "Erro", "Erro ao criar o spiner do tipo de gr�fico" + ex.getMessage() );
		}

	}
	
	/**
	 * RECUPERA A DATA DE INICIO DO GR�FICO E SETTA O TEXTO NO BOT�O
	 * */
	public void atualizaBtnInicioData()
	{
		btnInicioData.setText( getDataFormatada ( InicioData ) );
	}
	
	/**
	 * RECUPERA A DATA DE FIM DO GR�FICO E SETTA O TEXTO NO BOT�O
	 * */
	public void atualizaBtnFimData()
	{
		btnFimData.setText( getDataFormatada ( FimData ) );
	}
	
	/**
	 * APLICA FORMATA��O DA DATA DO BANCO PARA DIA/M�S/ANO
	 * @param Calentand�rio com uma data
	 * @return Data formatada no padr�o Dia/M�s/Ano
	 * */
	public String getDataFormatada( Calendar cal )
	{
		
		SimpleDateFormat sdf = new SimpleDateFormat( "dd/MM/yyyy" );
		
		String temp = sdf.format( cal.getTime() );
		
		return temp;
		
	}
	
	public static Calendar convertDateToCalendarAndFormmatDate(Date date){ 
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		return cal;
	}
	
	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DATE_INICIO_:
			return new DatePickerDialog(this, DateInicioSetListener,
					InicioData.get(Calendar.YEAR),
					InicioData.get(Calendar.MONTH),
					InicioData.get(Calendar.DAY_OF_MONTH));
		case DATE_FIM_:
			return new DatePickerDialog(this, DateFimSetListener,
					FimData.get(Calendar.YEAR),
					FimData.get(Calendar.MONTH),
					FimData.get(Calendar.DAY_OF_MONTH));
		}
		return null;

	}
	
	private DatePickerDialog.OnDateSetListener DateInicioSetListener = new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			InicioData.set(Calendar.DAY_OF_MONTH, dayOfMonth);
			InicioData.set(Calendar.MONTH, monthOfYear);
			InicioData.set(Calendar.YEAR, year);
			atualizaBtnInicioData();
		}
	};
	
	private DatePickerDialog.OnDateSetListener DateFimSetListener = new DatePickerDialog.OnDateSetListener() {
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			FimData.set(Calendar.DAY_OF_MONTH, dayOfMonth);
			FimData.set(Calendar.MONTH, monthOfYear);
			FimData.set(Calendar.YEAR, year);
			atualizaBtnFimData();
		}
	};
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return true;
	}

}
