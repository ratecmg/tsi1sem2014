package br.edu.ifsp.medidacerta.shared.chart.linha;

import java.util.ArrayList;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.TimeSeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Paint.Align;
import br.edu.ifsp.medidacerta.shared.chart.Grafico;

public class GraficoLinha extends Grafico {
	private XYMultipleSeriesRenderer renderer = new XYMultipleSeriesRenderer();
	private XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();

	private int xLabels = 0;
	private int yLabels = 15;

	public int getxLabels() {
		return xLabels;
	}

	public void setxLabels(int xLabels) {
		this.xLabels = xLabels;
	}

	public int getyLabels() {
		return yLabels;
	}

	public void setyLabels(int yLabels) {
		this.yLabels = yLabels;
	}

	public GraficoLinha(Context context) {
		super(context);

	}

	public String tituloVertical;
	public String tituloHorizontal;
	public int scale;

	public int getScale() {
		return scale;
	}

	public void setScale(int scale) {
		this.scale = scale;
	}

	public List<Linha> listaLinhas = new ArrayList<Linha>();

	private double maxX;
	private double maxY;

	public List<Linha> getListaLinhas() {
		return listaLinhas;
	}

	public void setListaLinhas(List<Linha> listaLinhas) {
		this.listaLinhas = listaLinhas;
	}

	public void addLinha(Linha n) {
		listaLinhas.add(n);
	}

	public double getMaxX() {
		return maxX;
	}

	public void setMaxX(double maxX) {
		this.maxX = maxX;
	}

	public double getMaxY() {
		return maxY;
	}

	public void setMaxY(double maxY) {
		this.maxY = maxY;
	}

	public String getTituloVertical() {
		return tituloVertical;
	}

	public void setTituloVertical(String tituloVertical) {
		this.tituloVertical = tituloVertical;
	}

	public String getTituloHorizontal() {
		return tituloHorizontal;
	}

	public void setTituloHorizontal(String tituloHorizontal) {
		this.tituloHorizontal = tituloHorizontal;
	}

	public void addXLabel(double x, String text) {
		renderer.addXTextLabel(x, text);
	}

	public void addYLabel(double y, String text) {
		renderer.addYTextLabel(y, text);
	}

	public void addComentario(double x, double y, String comentario) {
		XYSeries series = dataset.getSeriesAt(0);
		series.addAnnotation(comentario, x, y);
	}

	@Override
	public Intent drawChart(Context context) {
		renderer.setAxisTitleTextSize(16);
		renderer.setChartTitleTextSize(20);
		renderer.setLabelsTextSize(15);
		renderer.setLegendTextSize(15);
		renderer.setPointSize(5f);
		renderer.setMargins(new int[] { 20, 30, 15, 20 });
		renderer.setChartTitle(getTitulo());
		renderer.setXTitle(getTituloHorizontal());
		renderer.setYTitle(getTituloVertical());
		renderer.setXAxisMin(0);
		renderer.setXAxisMax(getMaxX());
		renderer.setYAxisMin(0);
		renderer.setYAxisMax(getMaxY());
		renderer.setAxesColor(Color.GRAY);
		renderer.setLabelsColor(Color.GRAY);
		renderer.setXLabels(xLabels);
		renderer.setYLabels(yLabels);
		renderer.setShowGrid(true);
		renderer.setXLabelsAlign(Align.RIGHT);
		renderer.setYLabelsAlign(Align.RIGHT);
		renderer.setXRoundedLabels(false);
		renderer.setZoomButtonsVisible(true);
		renderer.setPanLimits(new double[] { -10, 20, -10, 40 });
		renderer.setZoomLimits(new double[] { -10, 20, -10, 40 });
		renderer.setBackgroundColor(Color.BLACK);
		renderer.setApplyBackgroundColor(true);

		for (Linha linha : getListaLinhas()) {
			XYSeriesRenderer r = new XYSeriesRenderer();
			r.setColor(linha.getCor());
			r.setPointStyle(linha.getTipoPonto());
			r.setFillPoints(true);
			renderer.addSeriesRenderer(r);
			XYSeries series = new XYSeries(linha.getNome(), scale);
			for (Point p : linha.getListaPontos()) {
				series.add(p.x, p.y);
				series.addAnnotation(p.y + "Kg", (double) p.x, (double) p.y + 2);
			}
			dataset.addSeries(series);
		}

		Intent intent = ChartFactory.getLineChartIntent(context, dataset,
				renderer, getTitulo());

		return intent;
	}

}
