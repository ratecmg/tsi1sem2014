package br.edu.ifsp.medidacerta.medida.activity;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.achartengine.chart.PointStyle;

import classe.CadastroBasico;
import classe.Pessoa;
import classe.Sexo;
import classe.Usuario;
import classe.UsuarioLogado;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Toast;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.medida.dao.UsuarioDAO;
import br.edu.ifsp.medidacerta.medida.models.ico.ICO;
import br.edu.ifsp.medidacerta.medida.models.imc.IMC;
import br.edu.ifsp.medidacerta.medida.models.rcq.RCQ;
import br.edu.ifsp.medidacerta.shared.chart.linha.GraficoLinha;
import br.edu.ifsp.medidacerta.shared.chart.linha.Linha;

public class MedidasPrincipalActivity extends Activity {

	public static Usuario usuarioAtualizado;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		usuarioAtualizado = UsuarioLogado.getUsuarioLogado();

		br.edu.ifsp.medidacerta.medida.dao.UsuarioDAO d = new br.edu.ifsp.medidacerta.medida.dao.UsuarioDAO(
				getApplicationContext());

		//usuarioAtualizado = d.obterUsuarioEmDataEspecificada(usuarioAtualizado, new java.util.Date());
	
		try {
			usuarioAtualizado = d.obterAtualizado(usuarioAtualizado);
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(), "Falha ao atualizar usu�rio: " + e.getMessage(), Toast.LENGTH_LONG).show();
		}
		
		if (usuarioAtualizado != null) {
			usuarioAtualizado.incomplete = false;
		}

		setContentView(R.layout.activity_m_principal);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_m_principal, menu);
		return true;
	}

	public void btVisualizarIMC_onClick(View v) {

		Pessoa p = usuarioAtualizado;
		try {
			IMC imc = new IMC(p);
			if (imc != null) {
				Intent intent = new Intent(this.getApplicationContext(),
						CalculoIMCActivity.class);
				intent.putExtra("imc", (Serializable) imc);
				startActivity(intent);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
		}

	}

	public void btVisualizarICO_onClick(View v) {
		Pessoa p = usuarioAtualizado;
		try {
			ICO ico = new ICO(p);
			if (ico != null) {
				Intent intent = new Intent(this.getApplicationContext(),
						CalculoICOActivity.class);
				intent.putExtra("ico", (Serializable) ico);
				startActivity(intent);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
		}

	}

	public void btVisualizarRCQ_onClick(View v) {
		Pessoa p = usuarioAtualizado;
		try {
			RCQ rcq = new RCQ(p);
			if (rcq != null) {
				Intent intent = new Intent(this.getApplicationContext(),
						CalculoRCQActivity.class);
				intent.putExtra("rcq", (Serializable) rcq);
				startActivity(intent);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
		}

	}

	public void btVisualizarTabela_onClick(View v) {
		Intent intent = new Intent(this.getApplicationContext(),
				VisualizarTabela.class);
		startActivity(intent);

	}
	public void btCompartilhar_onClick(View v) {
		Intent intent = new Intent(this.getApplicationContext(),
				CompartilharActivity.class);
		startActivity(intent);

	}

	public void btVisualizarGrafico_onClick(View v) {
		GraficoLinha g = new GraficoLinha(this.getApplicationContext());
		Point p;
		g.setTitulo("Gr�fico do peso");
		g.setTituloHorizontal("Dias");
		g.setTituloVertical("Peso");
		g.setMaxX(5);
		g.setMaxY(100);

		Linha linhaPeso = new Linha();

		linhaPeso.setCor(Color.WHITE);
		linhaPeso.setTipoPonto(PointStyle.CIRCLE);
		linhaPeso.setNome("Peso");

		Date hoje = new Date();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONDAY, -1);
		Date nova_data = cal.getTime();

		dao.BasicoDAO b = new dao.BasicoDAO(getApplicationContext());
		List<classe.CadastroBasico> lst = b.getTodosOrdenadosPelaUltimaInclusao(usuarioAtualizado.getId());
		
		for (int i = lst.size() - 1; i >= 0; i--){
			p = new Point();
			p.x = lst.size() - i;
			p.y = (int)lst.get(i).getPeso();
			System.out.println(this.getClass().getSimpleName() +  " - Peso: " + lst.get(i).getPeso());
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM",Locale.getDefault());
			String sdt = sdf.format(lst.get(i).getData_atualizacao());
			g.addXLabel(i + 1,sdt);
			linhaPeso.addPonto(p);
		}
		
		g.addLinha(linhaPeso);
		Intent it = g.drawChart(this);
		startActivity(it);

	}

}
