package br.edu.ifsp.medidacerta.enciclopedia.activity;

import java.util.List;

import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.enciclopedia.models.Dica;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/** Classe utilizada tratar os dados para adição na lista presente nas

* nas telas de exibição de dicas de nutrição e dicas de atividades físicas.

* @author Ricardo Theodoro

*/


public class DicaListAdapter extends BaseAdapter {

	private Context context;
	private List<Dica> lista;
	
	public DicaListAdapter(Context context, List<Dica> lista) {
		this.context = context;
		this.lista = lista;
	}
	
	@Override
	public int getCount() {
		return lista.size();
		//return 3;
	}

	@Override
	public Object getItem(int position) {
		return lista.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Dica d = lista.get(position);
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View view = inflater.inflate(R.layout.enc_dicas, null);

		TextView dica = (TextView) view.findViewById(R.id.enc_txtDica);
	    dica.setText(d.getDica());
		
		
		return view;
	}
}


