package br.edu.ifsp.medidacerta.medida.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.Context;
import classe.CadastroBasico;
import classe.CadastroComplementar;
import classe.Usuario;
import dao.BasicoDAO;
import dao.MedidasDAO;

/**
 * Classe DAO wrapper de Usuario para a equipe de medidas
 *
 * @author Tiago
 *
 */
public class UsuarioDAO {

    Context context;

    public UsuarioDAO(Context context) {
        this.context = context;
    }
    public List<CadastroBasico> listaRegistroCache = new ArrayList<CadastroBasico>();

    public Usuario obterUsuarioEmDataEspecificada(Usuario usuario, Date date) {
        if (listaRegistroCache.isEmpty()) {
            BasicoDAO b = new BasicoDAO(context);
            listaRegistroCache = b.getTodosOrdenadosPelaUltimaInclusao(usuario.getId());
            b.close();
        }

        for (CadastroBasico c : listaRegistroCache) {
            if (c.getData_atualizacao().equals(date)) {
                usuario.setAltura((double) c.getAltura());
                usuario.setPeso((double) c.getPeso());
            }
        }
        return usuario;
    }

    public Usuario obterAtualizado(Usuario usuario) throws Exception {
        if (usuario != null) {
        	try{
	        	BasicoDAO d = new BasicoDAO(context);
	            CadastroBasico c = d.getByID(usuario.getId());
	            if (c != null) {
	                usuario.setAltura((double) c.getAltura());
	                usuario.setPeso((double) c.getPeso());
	            }
	            d.close();
        	}catch (Exception e){
            	throw new Exception("Falha ao obter cadastro b�sico.");
            }

            MedidasDAO md = new MedidasDAO(context);
            try{
	            CadastroComplementar cc = md.getByID(usuario.getId());
	            if (cc != null) {
	                usuario.setCircunferenciaCintura((double) cc
	                        .getCircunferencia());
	                usuario.setCircunferenciaQuadril((double) cc.getQuadril());
	            }
	            md.close();
            }catch (Exception e){
            	throw new Exception("Falha ao obter cadastro complementar.");
            }
        }
        return usuario;
    }
}
