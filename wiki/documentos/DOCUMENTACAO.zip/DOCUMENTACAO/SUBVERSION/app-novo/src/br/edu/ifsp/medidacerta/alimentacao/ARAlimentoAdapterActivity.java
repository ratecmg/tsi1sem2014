package br.edu.ifsp.medidacerta.alimentacao;

import java.util.List;

import br.edu.ifsp.medidacerta.R;

import classe.Alimento;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;



public class ARAlimentoAdapterActivity extends BaseAdapter {

	private Context context;
	private List<Alimento> listaDeAlimentos;
	
	/**
	 * Contrutor para criar uma lista increment�vel de alimentos
	 */
	public ARAlimentoAdapterActivity( Context _context, List<Alimento> _listaDeAlimentos )
	{
		this.context = _context;
		this.listaDeAlimentos = _listaDeAlimentos;
	}
	
	@Override
	public int getCount()
	{
		return listaDeAlimentos.size();
	}
	
	@Override
	public Object getItem( int _position )
	{
		return listaDeAlimentos.get( _position );
	}
	
	@Override
	public long getItemId( int _position )
	{
		return _position;
	}
	
	@Override
	public View getView( int _position, View convertView, ViewGroup parent )
	{
		
		Alimento a = listaDeAlimentos.get( _position );
		
		LayoutInflater inflater = ( LayoutInflater ) context.getSystemService( Context.LAYOUT_INFLATER_SERVICE );
		
		View view = inflater.inflate( R.layout.a_r_alimento_adapter , null );
		
		TextView nomeAlimento = ( TextView ) view.findViewById( R.id.txtNomeAlimento );
		nomeAlimento.setText( a.getAlimento() );
		
		TextView descAlimento = ( TextView ) view.findViewById( R.id.txtDescAlimento );
		descAlimento.setText( a.getDescricao() );
		
		return view;
		
	}

}
