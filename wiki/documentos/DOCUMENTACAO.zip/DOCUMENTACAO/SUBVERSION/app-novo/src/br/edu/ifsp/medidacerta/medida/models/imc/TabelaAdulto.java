/*
 * Equipe de Medidas
 * 
 */
package br.edu.ifsp.medidacerta.medida.models.imc;

enum TabelaAdulto {

    MAGREZA_SEVERA_ADULTO(IMC.Classificacao.MAGREZA_SEVERA, 16),
    MAGREZA_MODERADA_ADULTO(IMC.Classificacao.MAGREZA_MODERADA, 17),
    MAGREZA_LEVE_ADULTO(IMC.Classificacao.MAGREZA_LEVE, 18.5f),
    SAUDAVEL_ADULTO(IMC.Classificacao.SAUDAVEL, 25),
    SOBREPESO_ADULTO(IMC.Classificacao.SOBREPESO, 30),
    OBESIDADE_ADULTO(IMC.Classificacao.OBESIDADE, 35),
    OBESIDADE_SEVERA_ADULTO(IMC.Classificacao.OBESIDADE_SEVERA, 40),
    OBESIDADE_MORBIDA_ADULTO(IMC.Classificacao.OBESIDADE_MORBIDA, 999999),
    SEM_CLASSIFICACAO_ADULTO(IMC.Classificacao.SEM_CLASSIFICACAO, 0);
    private double valorMaximo;
    private IMC.Classificacao id;

    private TabelaAdulto(IMC.Classificacao id, double valorIMC) {
        this.valorMaximo = valorIMC;
        this.id = id;
    }

    static IMC.Classificacao getClassificacao(double valorIMC) {
        for (TabelaAdulto t : values()) {
            if (valorIMC < t.valorMaximo) {
                return t.id;
            }
        }
        return IMC.Classificacao.SEM_CLASSIFICACAO;
    }

    double getValorMaximo() {
        return valorMaximo;
    }
    
}