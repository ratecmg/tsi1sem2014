package br.edu.ifsp.medidacerta.enciclopedia.models;

public class Classificacao {
	
	private int id_classificacao;
	private String classificacao;
	private Indice indice;
	private Classificacao classificacaoObjetivo;
	
	public int getId_classificacao() {
		return id_classificacao;
	}
	public Classificacao getClassificacaoObjetivo() {
		return classificacaoObjetivo;
	}
	public void setClassificacaoObjetivo(Classificacao classificacaoObjetivo) {
		this.classificacaoObjetivo = classificacaoObjetivo;
	}
	public void setId_classificacao(int id_classificacao) {
		this.id_classificacao = id_classificacao;
	}
	public String getClassificacao() {
		return classificacao;
	}
	public void setClassificacao(String classificacao) {
		this.classificacao = classificacao;
	}
	public Indice getIndice() {
		return indice;
	}
	public void setIndice(Indice indice) {
		this.indice = indice;
	}	

}
