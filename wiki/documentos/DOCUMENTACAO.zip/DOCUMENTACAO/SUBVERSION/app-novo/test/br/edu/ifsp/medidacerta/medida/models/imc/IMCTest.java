package br.edu.ifsp.medidacerta.medida.models.imc;


import junit.framework.TestCase;

import org.junit.Test;

import classe.Sexo;

public class IMCTest extends TestCase {

	

	@Test
	public void testIMCAdultoFeminino() {
		double peso = 60;
		double altura = 1.65d;		
		Sexo sexo = Sexo.FEMININO;
		int idade = 18;
		IMC.Classificacao resultadoEsperado = IMC.Classificacao.SAUDAVEL;		
		IMC imc = new IMC(peso, altura, sexo, idade);
		assertEquals(resultadoEsperado, imc.getClassificacao());		
	}
	@Test
	public void testPesoMaxIMCAdultoFeminino() {
		double peso = 60;
		double altura = 1.65d;		
		Sexo sexo = Sexo.FEMININO;
		int idade = 18;
		double resultadoEsperado = 67.2522d;
		IMC imc = new IMC(peso, altura, sexo, idade);	
		assertEquals(resultadoEsperado, imc.getMaxPesoIdeal(),0.01);		
	}
	@Test
	public void testMaxIMCIdealAdultoMasculino() {
		fail("N�o implementado");	
	}
	@Test
	public void testMinIMCIdealAdultoMasculino() {
		fail("N�o implementado");	
	}
	@Test
	public void testMaxIMCIdealAdultoFeminino() {
		fail("N�o implementado");	
	}
	@Test
	public void testMinIMCIdealAdultoFeminino() {
		fail("N�o implementado");	
	}
	@Test
	public void testMaxIMCIdealIdosoFeminino() {
		fail("N�o implementado");	
	}
	@Test
	public void testMinIMCIdealIdosoFeminino() {
		fail("N�o implementado");	
	}
	@Test
	public void testMaxIMCIdealIdosoMasculino() {
		fail("N�o implementado");	
	}
	@Test
	public void testMinIMCIdealIdosoMasculino() {
		fail("N�o implementado");	
	}
	
	@Test
	public void testMaxIMCIdealInfantilMasculino() {
		fail("N�o implementado");	
	}
	@Test
	public void testMinIMCIdealInfantilMasculino() {
		fail("N�o implementado");	
	}
	

}
