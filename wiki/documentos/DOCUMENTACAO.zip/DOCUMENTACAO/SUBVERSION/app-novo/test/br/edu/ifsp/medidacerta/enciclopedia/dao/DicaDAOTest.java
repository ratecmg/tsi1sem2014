package br.edu.ifsp.medidacerta.enciclopedia.dao;
import org.apache.http.client.methods.HttpUriRequest;
import static org.junit.Assert.*;
import br.edu.ifsp.medidacerta.R;
import br.edu.ifsp.medidacerta.enciclopedia.models.*;
import java.util.List;

import org.junit.Test;

public class DicaDAOTest {

	@Test
	public void testBuscarDicas() {
		DicaDAO dica_dao = new DicaDAO();
		List<Dica>listAll = dica_dao.listAll();
		StringBuilder dica = new StringBuilder();
		assertTrue(listAll.size()>0);
		
	}

}
