package br.edu.ifsp.medidacerta.medida;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import br.edu.ifsp.medidacerta.medida.models.imc.IMCTest;
import br.edu.ifsp.medidacerta.medida.models.ico.ICOTest;
import br.edu.ifsp.medidacerta.medida.models.rcq.RCQTest;

@RunWith(Suite.class)
@SuiteClasses({ IMCTest.class, RCQTest.class, ICOTest.class })
public class MedidaTests {

}
