package br.edu.ifsp.medidacerta.medida.models.ico;


import org.junit.Test;

import junit.framework.TestCase;

public class ICOTest extends TestCase {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
