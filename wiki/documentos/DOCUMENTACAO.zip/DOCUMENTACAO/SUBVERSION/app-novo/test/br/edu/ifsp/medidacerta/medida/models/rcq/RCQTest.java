package br.edu.ifsp.medidacerta.medida.models.rcq;

import static org.junit.Assert.*;

import org.junit.Test;

import classe.Pessoa;
import classe.Sexo;

public class RCQTest {

	@Test
	public void testClassificacao() {
		RCQ rcq = new RCQ(80, 99, Sexo.MASCULINO, 19);
		assertEquals(RCQ.Classificacao.SEM_CLASSIFICACAO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculinoNormal() {
		RCQ rcq = new RCQ(99,99, Sexo.MASCULINO, 25);
		assertEquals(1, rcq.getValor(),0.1);
		
	}
	@Test
	public void testFemininoNormal() {
		RCQ rcq = new RCQ(99,99, Sexo.FEMININO, 25);
		assertEquals(1, rcq.getValor(),0.1);
		
	}

	@Test
	public void testMasculino19Baixo() {		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 19);
	
		assertEquals(RCQ.Classificacao.SEM_CLASSIFICACAO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino20Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 20);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino21Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 21);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino29Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 29);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino30Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 30);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino31Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 31);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino38Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 38);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino39Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 39);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino40Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 40);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino41Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 41);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino48Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 48);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino49Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 49);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino50Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 50);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino51Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 51);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino58Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 58);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino59Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 59);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino60Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 60);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino61Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 61);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino68Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 68);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino69Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 69);
	
		assertEquals(RCQ.Classificacao.RISCO_BAIXO, rcq.getClassificacao());
		
	}
	@Test
	public void testMasculino70Baixo() {
		
		RCQ rcq = new RCQ(80,99, Sexo.MASCULINO, 70);
	
		assertEquals(RCQ.Classificacao.SEM_CLASSIFICACAO, rcq.getClassificacao());
		
	}

}
