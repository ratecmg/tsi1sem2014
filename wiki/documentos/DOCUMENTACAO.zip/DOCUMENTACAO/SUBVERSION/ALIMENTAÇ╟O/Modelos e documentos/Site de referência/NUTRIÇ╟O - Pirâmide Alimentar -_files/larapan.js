//<script>
//nsie4=(document.all||document.layers)
//<//script> 
//<script src="preview.js">
//<//script> 
//<layer id="preview" visibility="hide" onblur="this.visibility='hide'" //onMouseover="drag_drop('preview')"></layer> <img id="preview2" src="spacer.gif" //style="position:absolute;visibility:hidden;cursor:hand"><!--webbot
//    bot="HTMLMarkup" endspan --></td>
// </tr>
// 	<a onClick="if (nsie4){previewit(this.href,event);return false}"
//        href="search_white.gif"><img src="previewjava.gif" width="57" height="15" //	border="0">
/////////////////////////termina
//ns = (navigator.appName == "Netscape");
//win = (navigator.userAgent.indexOf("Win")!=-1)


//ns4 = (document.layers)? true:false;
//ie4 = (document.all)? true:false;

nsie4=true;
//(document.all||document.layers);



var zindex=100

function abrepainel(e, whichone, imgclick){
//setTimeout('hidemenu()',15000);
     write('aqui');
    if (document.all) {                  //Iexplore
		if (window.themenu&&themenu.id!=eval(whichone).id)   
		themenu.style.visibility="hidden"
		themenu=whichone
	if (document.all){
		themenu.style.left=document.body.scrollLeft+event.clientX-event.offsetX
		themenu.style.top=document.body.scrollTop+event.clientY-event.offsetY
	if (themenu.style.visibility=="hidden"){
		themenu.style.visibility="visible"
		themenu.style.zIndex=zindex++
           event.cancelBubble='true'
	}	
	else{
	hidemenu()
		}
	} 				//fim Iexplore
} else if (document.layers) {                       //inicio netscape
             //  function dropit(e,whichone){
				  document.write('aqui layers');
	if (window.themenu&&themenu.id!=eval(whichone).id)
		themenu.visibility="hide"
		themenu=eval(whichone)		
	if (themenu.visibility=="hide"){
	    if (imgclick=="imgdicas"){
	  	themenu.left=document.imgdicas.x  //e.pageX-e.layerX+6
		themenu.top=document.imgdicas.y   //e.pageY-e.layerY+36
		} else if (imgclick=="imgsaiba") {
			themenu.left=document.imgsaiba.x  //e.pageX-e.layerX+6
			themenu.top=document.imgsaiba.y }  
		themenu.visibility="show"
		themenu.zIndex++		
	}
	else {	    
	  	themenu.visibility="hide"
			
	return false
		}
	} 					//fim netscape
	
}

function hidemenu(whichone){
       if (document.themenu){
           themenu.visibility = 'hide';
       }
       else{
          themenu.style.visibility =  'hidden' ;
      }

//if (window.themenu)
//themenu.style.visibility="hidden"
}

function hidemenu2(){
themenu.visibility="hide"
}

//if (document.all)
//document.onclick=hidemenu
//////////////////////////////////////////////////