
// inicia versao
isDOM  = (document.getElementById);
isNS4  = (document.layers);
isIE   = (document.all);
isIE4  = (isIE && !isDOM);
isMac  = (navigator.appVersion.indexOf("Mac") != -1);
isIE4M = (isIE4 && isMac);
isIE5M = isDOM && isIE && isMac;
isIE5W = isDOM && isIE && !isMac;
isNS6 =  isDOM && (navigator.vendor == ("Netscape6") || navigator.product == ("Gecko"));
// fim


<!-- AddThis Smart Layers BEGIN -->
<!-- Go to http://www.addthis.com/get/smart-layers to customize -->
/*<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=weblaranja"></script>*/

(function(d){
  var f = d.getElementsByTagName('SCRIPT')[0], p = d.createElement('SCRIPT');
  p.type = 'text/javascript'; 
  p.async = false;           
  p.src = '//s7.addthis.com/js/300/addthis_widget.js#pubid=weblaranja&domready=1';
  f.parentNode.insertBefore(p, f);
}(document));
  
	
var timerID;
var iteration=0;

function checkAndLoad() {         
		 		 
<!-- AddThis Smart Layers END -->
  addthis.layers({
    'theme' : 'transparent',
    'share' : {
      'position' : 'left',
      'numPreferredServices' : 6,
	  'postShareTitle' : 'Obrigado por compartilhar!',
	   'postShareFollowMsg' : 'Siga Weblaranja',  
	   'postShareRecommendedMsg' : 'Recomendado para voc�'
    }, 
    'follow' : {
      'services' : [
        {'service': 'facebook', 'id': 'weblaranja'},
        {'service': 'twitter', 'id': 'weblaranja'},
        {'service': 'google_follow', 'id': '104129085504254037524'},
        {'service': 'pinterest', 'id': 'weblaranja'}
      ],	 
	  'postFollowTitle' : 'Obrigado por seguir!',
	  'postFollowRecommendedMsg' : 'Recomendado para voc�',
    }   
  });
		<!-- AddThis Smart Layers END --> 
		  clearInterval(timerID);
    }  
timerID = setInterval(checkAndLoad,5000);
	
	
/*</script>*/
<!-- AddThis Smart Layers END -->
 



/************** guia de data *******/

// Today's Date
var now = new Date();
var mName = now.getMonth() + 1;
var dName = now.getDay() + 1;
var dayNr = now.getDate();
var yearNr=now.getYear();
if(dName==1) Day = "domingo";
if(dName==2) Day = "segunda";
if(dName==3) Day = "ter&ccedil;a";
if(dName==4) Day = "quarta";
if(dName==5) Day = "quinta";
if(dName==6) Day = "sexta";
if(dName==7) Day = "s&aacute;bado";
if(yearNr < 2000) Year = 1900 + yearNr;
else Year = yearNr;
// String to display current date.
var todaysDate =(" " + Day + ", " + dayNr + "/" + mName + "/" + Year);




/**cria a lista de menus do card�pio**/

function cria_lista_card() {
  document.write("<script language=JavaScript src=\"../control/lista_menu_card.js\"></script>");
  
}


function janpop()  
     {
     var newWindow = window.open("info.html", "info", "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,copyhistory=no,width=335,height=320");
     }

/**funcao drop**/
function MM_jumpMenu(targ,selObj,restore){ //v3.0
 if (selObj.options[selObj.selectedIndex].value != "0") {
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
 }
}


/****abre/fecha layers funciona melhor com a fun��o onmouseover e onmouseout****/

function MM_showHideLayers() {
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
if ((obj=MM_findObj(args[i]))!=null) { 
	v=args[i+2];
	    if (obj.style) {
 obj=obj.style; v=(v=='show')?'visible':(v='hide')?'hidden':v; 
		}
    obj.visibility=v; 
	}
}

/****carrega imagens *******/

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}


function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v3.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function MM_OpenBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}


//fechar

function fechar(){
      self.close(self);
}

//funcao posiciona busca
 function posbusca() {	
 if (document.layers) {              //inicio netscape         
		
			document.buscadiv.left=document.imgbusca.x+20	//e.pageX-e.layerX+6
			document.buscadiv.top=document.imgbusca.y+28	
	}	
	//fim netscape
} 

//jan

function abrejan(jan) {
 resultado=window.open('',jan,"toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,top=0,left=0,width=639,height=459,resizable=no");
  //versao 3.0
 if ( (navigator.appName != "Microsoft Internet Explorer") && (navigator.appVersion.substring(0,1) >= "3") )
  resultado.focus();
}

//pop
function popuva(ende)  
     {
     //var newWindow = 
   win = window.open(ende,"Tipouva","toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=800,height=460");
     win.focus();
}



function popene(jan) {
 resultado=window.open('',jan,"toolbar=no,location=no,status=no,menubar=no,scrollbars=no,top=0,left=0,width=310,height=210,resizable=no");
  //versao 3.0
 if ( (navigator.appName != "Microsoft Internet Explorer") && (navigator.appVersion.substring(0,1) >= "3") )
  resultado.focus();
}

function popzoom(url, tit, largura, altura)    {
	var abrejanela = null; 
    abrejanela = window.open(url, tit, 'top=10,left=10,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,menubar=no,width=' + largura + ',height=' + altura);
}

function poprec(url, tit, largura, altura)    {
	var abrejanela = null; 
    abrejanela = window.open(url, tit, 'top=10,left=10,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,menubar=no,width=' + largura + ',height=' + altura);
}

