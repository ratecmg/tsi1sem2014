package br.edu.ifsp.sbv.medidacerta.enciclopediaws.modelo;


public class Enciclopedia  {

}
