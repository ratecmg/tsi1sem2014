package br.edu.ifsp.sbv.medidacerta.enciclopediaws.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



import br.edu.ifsp.sbv.medidacerta.enciclopediaws.modelo.Dica;
import br.edu.ifsp.sbv.medidacerta.enciclopediaws.modelo.Tipo;

public class DicaDAO extends ConnectionFactory{
	/**
	 * M�todo para buscar dicas
	 * @return Retorna as dicas cadastradas no banco
	 */
	public ArrayList<Dica> buscarTodos() {

		Connection conn = null;
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		conn = getConnection();
		ArrayList<Dica> listaDicas = new ArrayList<Dica>();

		try {

			stmt = conn
					.prepareStatement("SELECT * FROM dica;");
			resultSet = stmt.executeQuery();
			listaDicas = new ArrayList<Dica>();

			while (resultSet.next()) {
				Tipo t = new Tipo();
				t.setId_tipo(resultSet.getInt("id_tipo"));
				t.setTipo("");
				
				Dica d = new Dica();
				d.setId_dica(resultSet.getInt("id_dica"));
				d.setTipo(t);
				d.setDica(resultSet.getString("dica"));
				
				
				listaDicas.add(d);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			//listaDicas = null;
			Dica dicapadrao = new Dica();
			dicapadrao.setId_dica(1);
			dicapadrao.setDica("Estamos com dificuldades para exibir as dicas.\n Tente Novamente.");
			listaDicas.add(dicapadrao);
		} finally {
			closeConnection(conn, stmt, resultSet);
		}
		return listaDicas;
	}

	/**
	 * M�todo para buscar dicas
	 * @param id_objetivo - identifica��o do objetivo
	 * @return Retorna as dicas de atividades f�sicas por objetivo
	 */
	public ArrayList<Dica> buscarDicasAtividadesFisicas(int id_objetivo) {
		
		Connection conn = null;
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		conn = getConnection();
		ArrayList<Dica> listaDicas = null;

		try {
			// Dicas de Atividades F�sicas
			// Listar dicas de atividades f�sicas (id_tipo = 2) por objetivo "perder peso" (id_objetivo = 1)
			stmt = conn
					.prepareStatement("SELECT d.id_dica, d.id_tipo, d.dica "+
									  "FROM dica_objetivo dobj, dica d "+
									  "WHERE dobj.id_dica = d.id_dica AND "+ 
									  "dobj.id_objetivo = ? AND "+
									  "d.id_tipo = 2 "+
								      "ORDER BY d.id_dica;");
			stmt.setInt(1, id_objetivo);
			resultSet = stmt.executeQuery();
			listaDicas = new ArrayList<Dica>();

			while (resultSet.next()) {
				Tipo t = new Tipo();
				t.setId_tipo(resultSet.getInt("id_tipo"));
				t.setTipo("");
				
				Dica d = new Dica();
				d.setId_dica(resultSet.getInt("id_dica"));
				d.setTipo(t);
				d.setDica(resultSet.getString("dica"));
				
				listaDicas.add(d);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			listaDicas = new ArrayList<Dica>();
			Dica dicapadrao = new Dica();
			dicapadrao.setId_dica(1);
			dicapadrao.setDica("Estamos com dificuldades para exibir as dicas.\n Tente Novamente.");
			listaDicas.add(dicapadrao);
		} finally {
			closeConnection(conn, stmt, resultSet);
		}
		return listaDicas;
	}
	/**
	 * M�todo para buscar dicas
	 * @param id_objetivo - identifica��o do objetivo
	 * @return Retorna as dicas nutricionais por objetivo
	 */
	public ArrayList<Dica> buscarDicasNutricionais(int id_objetivo) {
		Connection conn = null;
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		conn = getConnection();
		ArrayList<Dica> listaDicas = null;

		try {
			// Dicas de Atividades F�sicas
			// Listar dicas de atividades f�sicas (id_tipo = 1) por objetivo "perder peso" (id_objetivo = 1)
			stmt = conn
					.prepareStatement("SELECT d.id_dica, d.id_tipo, d.dica "+
									  "FROM dica_objetivo dobj, dica d "+
									  "WHERE dobj.id_dica = d.id_dica AND "+ 
									  "dobj.id_objetivo = ? AND "+
									  "d.id_tipo = 1 "+
								      "ORDER BY d.id_dica;");
			stmt.setInt(1, id_objetivo);
			resultSet = stmt.executeQuery();
			listaDicas = new ArrayList<Dica>();

			while (resultSet.next()) {
				Tipo t = new Tipo();
				t.setId_tipo(resultSet.getInt("id_tipo"));
				t.setTipo("");
				
				Dica d = new Dica();
				d.setId_dica(resultSet.getInt("id_dica"));
				d.setTipo(t);
				d.setDica(resultSet.getString("dica"));
				
				listaDicas.add(d);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			listaDicas = new ArrayList<Dica>();
			Dica dicapadrao = new Dica();
			dicapadrao.setId_dica(1);
			dicapadrao.setDica("Estamos com dificuldades para exibir as dicas.\n Tente Novamente.");
			listaDicas.add(dicapadrao);
		} finally {
			closeConnection(conn, stmt, resultSet);
		}
		return listaDicas;
	}

	/**
	 * M�todo para buscar dicas
	 * @param id_objetivo - identifica��o do objetivo
	 * @param id_classificacao - identifica��o da classifica��o
	 * @return Retorna as dicas por classifica��o dos �ndices
	 */
	public ArrayList<Dica> buscarDicasPorClassificacao(int id_objetivo,
			int id_classificacao) {
		Connection conn = null;
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		conn = getConnection();
		ArrayList<Dica> listaDicas = null;

		try {
			
			stmt = conn
					.prepareStatement("SELECT d.id_dica, d.id_tipo, d.dica "+
									  "FROM dica_objetivo dobj, dica d, classificacao c, objetivo o "+
									  "WHERE dobj.id_dica = d.id_dica AND "+ 
									  "dobj.id_objetivo = ? AND "+
									  "dobj.id_objetivo = o.id_objetivo AND "+
									  "o.id_objetivo = c.id_objetivo AND "+
									  "c.id_classificacao = ? "+
								      "ORDER BY d.id_dica;");
			stmt.setInt(1, id_objetivo);
			stmt.setInt(2, id_classificacao);
			resultSet = stmt.executeQuery();
			listaDicas = new ArrayList<Dica>();

			while (resultSet.next()) {
				Tipo t = new Tipo();
				t.setId_tipo(resultSet.getInt("id_tipo"));
				t.setTipo("");
				
				Dica d = new Dica();
				d.setId_dica(resultSet.getInt("id_dica"));
				d.setTipo(t);
				d.setDica(resultSet.getString("dica"));
				
				listaDicas.add(d);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			listaDicas = new ArrayList<Dica>();
			Dica dicapadrao = new Dica();
			dicapadrao.setId_dica(1);
			dicapadrao.setDica("Estamos com dificuldades para exibir as dicas.\n Tente Novamente.");
			listaDicas.add(dicapadrao);
		} finally {
			closeConnection(conn, stmt, resultSet);
		}
		return listaDicas;
	}
		
}