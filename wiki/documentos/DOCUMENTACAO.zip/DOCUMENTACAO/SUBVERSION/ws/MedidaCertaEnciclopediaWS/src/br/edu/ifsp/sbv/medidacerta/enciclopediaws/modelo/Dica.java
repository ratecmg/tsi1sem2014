package br.edu.ifsp.sbv.medidacerta.enciclopediaws.modelo;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * @author Enciclopedia
 * 
 *
 */
@XmlRootElement
public class Dica {
	
	private int id_dica;
	private String dica;
	private Tipo tipo;
	
	public int getId_dica() {
		return id_dica;
	}
	public void setId_dica(int id_dica) {
		this.id_dica = id_dica;
	}
	public String getDica() {
		return dica;
	}
	public void setDica(String dica) {
		this.dica = dica;
	}
	public Tipo getTipo() {
		return tipo;
	}
	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}


}
