package br.edu.ifsp.sbv.medidacerta.enciclopediaws.modelo;

public class DicaObjetivo {
	
	public int id_dica_objetivo;
	public Objetivo objetivo;
	public Dica dica;
	
	public int getId_dica_objetivo() {
		return id_dica_objetivo;
	}
	public void setId_dica_objetivo(int id_dica_objetivo) {
		this.id_dica_objetivo = id_dica_objetivo;
	}
	public Objetivo getObjetivo() {
		return objetivo;
	}
	public void setObjetivo(Objetivo objetivo) {
		this.objetivo = objetivo;
	}
	public Dica getDica() {
		return dica;
	}
	public void setDica(Dica dica) {
		this.dica = dica;
	}

}
