package br.edu.ifsp.sbv.medidacerta.enciclopediaws.modelo;

public class Objetivo {
	
	public int id_objetivo;
	public String objetivo;
	
	public int getId_objetivo() {
		return id_objetivo;
	}
	public void setId_objetivo(int id_objetivo) {
		this.id_objetivo = id_objetivo;
	}
	public String getObjetivo() {
		return objetivo;
	}
	public void setObjetivo(String objetivo) {
		this.objetivo = objetivo;
	}	

}
