package br.edu.ifsp.sbv.medidacerta.enciclopediaws.resources;



import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import br.edu.ifsp.sbv.medidacerta.enciclopediaws.dao.DicaDAO;
import br.edu.ifsp.sbv.medidacerta.enciclopediaws.modelo.Dica;

import com.google.gson.Gson;

@Path("/dica")
public class DicaResource {

	/**
	 * 
	 * @return Retorna todas as dicas cadastradas no banco
	 * @deprecated
	 */
	@GET
	@Path("/buscarTodos")
	@Produces("application/json")
	public ArrayList<Dica> selTodos() {
		return new DicaDAO().buscarTodos();
	}

	/**
	 * 
	 * @return Retorna todas as dicas em JSON
	 */
	@GET
	@Path("/buscarTodosGSON")
	@Produces("application/json")
	public String selTodosGSON() {
		return new Gson().toJson(new DicaDAO().buscarTodos());
	}

	/**
	 * 
	 * @param id_objetivo - identifica��o do objetivo
	 * @return Retorna as dicas de atividades f�sicas pelo id do objetivo
	 */
	@GET
	@Path("/buscarDicasAtividadesFisicas/{id_objetivo}")
	@Produces("application/json")
	public String selDicasAtividadesFisicas(@PathParam("id_objetivo") int id_objetivo) {
		return new Gson().toJson(new DicaDAO().buscarDicasAtividadesFisicas(id_objetivo));
	}
	
	/**
	 * 
	 * @param id_objetivo - identifica��o do objetivo
	 * @return Retorna as dicas nutricionais pelo id do objetivo
	 */
	@GET
	@Path("/buscarDicasNutricionais/{id_objetivo}")
	@Produces("application/json")
	public String selDicasNutricionais(@PathParam("id_objetivo") int id_objetivo) {
		return new Gson().toJson(new DicaDAO().buscarDicasNutricionais(id_objetivo));
	}
	
	/**
	 * 
	 * @param id_objetivo - identifica��o do objetivo
	 * @param id_classificacao - identifica��o da classifica��o
	 * @return Retorna as dicas pela classifica��o dos �ndices
	 */
	@GET
	@Path("/buscarDicasPorClassificacao/{id_objetivo}/{id_classificacao}")
	@Produces("application/json")
	public String selDicasPorClassificacao(@PathParam("id_objetivo") int id_objetivo,@PathParam("id_classificacao") int id_classificacao) {
		return new Gson().toJson(new DicaDAO().buscarDicasPorClassificacao(id_objetivo,id_classificacao));
	}
	
}
