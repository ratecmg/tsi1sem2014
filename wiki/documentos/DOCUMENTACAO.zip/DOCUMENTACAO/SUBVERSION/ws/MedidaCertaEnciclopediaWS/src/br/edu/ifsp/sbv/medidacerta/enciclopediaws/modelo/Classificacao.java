package br.edu.ifsp.sbv.medidacerta.enciclopediaws.modelo;

public class Classificacao {
	
	public int id_classificacao;
	public String classificacao;
	public Indice indice;
	public Classificacao classificacaoObjetivo;
	
	public int getId_classificacao() {
		return id_classificacao;
	}
	public Classificacao getClassificacaoObjetivo() {
		return classificacaoObjetivo;
	}
	public void setClassificacaoObjetivo(Classificacao classificacaoObjetivo) {
		this.classificacaoObjetivo = classificacaoObjetivo;
	}
	public void setId_classificacao(int id_classificacao) {
		this.id_classificacao = id_classificacao;
	}
	public String getClassificacao() {
		return classificacao;
	}
	public void setClassificacao(String classificacao) {
		this.classificacao = classificacao;
	}
	public Indice getIndice() {
		return indice;
	}
	public void setIndice(Indice indice) {
		this.indice = indice;
	}	

}
